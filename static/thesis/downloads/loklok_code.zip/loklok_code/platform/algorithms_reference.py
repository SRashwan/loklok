"""
LOKLOK platform algorithm reference (pure Python/NumPy).

These are compact reference implementations of the mechanisms described in
the thesis and implemented in the Go backend and the calibrated pipeline:

  * Beta-Bayesian Broadcaster Reputation Score (BRS)
  * Evidence-anchored DeGroot update with a Lyapunov-style cap
  * Multi-Objective Recommendation Engine (MORE) with a diversity term
  * Echo Meter and Algorithmic Cooling
  * ERIC percolation/propaganda moderation penalty
  * Zewail-inspired pump-probe attentional gate
  * Riemann-Zeta power-law engagement density
  * Dirichlet/Thompson scheduling sketch

They are intentionally dependency-light and are not a replacement for the
production Go services.  Run `python algorithms_reference.py` for a demo.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Dict, Iterable, List, Sequence, Tuple

import numpy as np


# ---------------------------------------------------------------------------
# BRS
# ---------------------------------------------------------------------------


@dataclass
class BetaBRS:
    """Beta posterior over a broadcaster's latent quality."""

    alpha: float = 2.0
    beta: float = 2.0

    def update(self, rating: float, weight: float = 1.0) -> None:
        rating = float(np.clip(rating, 0.0, 1.0))
        self.alpha += weight * rating
        self.beta += weight * (1.0 - rating)

    @property
    def score(self) -> float:
        return self.alpha / (self.alpha + self.beta)

    @property
    def variance(self) -> float:
        a, b = self.alpha, self.beta
        return (a * b) / ((a + b) ** 2 * (a + b + 1.0))

    def interval(self, level: float = 0.95) -> Tuple[float, float]:
        from scipy.stats import beta

        tail = (1.0 - level) / 2.0
        return (
            float(beta.ppf(tail, self.alpha, self.beta)),
            float(beta.ppf(1.0 - tail, self.alpha, self.beta)),
        )


# ---------------------------------------------------------------------------
# DeGroot + Lyapunov cap
# ---------------------------------------------------------------------------


def degroot_update(
    B: np.ndarray,
    X: np.ndarray,
    W: np.ndarray,
    lam: float = 0.24,
    beta_cap: float = 0.35,
    eps_self: float = 0.05,
) -> np.ndarray:
    """One evidence-anchored DeGroot update with a status cap.

    B : current reputation scores, shape (n,)
    X : evidence anchors, shape (n,)
    W : endorsement matrix, shape (n, n)
    """
    B = np.asarray(B, dtype=float)
    X = np.asarray(X, dtype=float)
    W = np.asarray(W, dtype=float)
    n = len(B)
    pos = W[W > 0]
    w_bar = float(np.mean(pos)) if pos.size else 1.0
    cap = w_bar / (1.0 + beta_cap * B)
    W_eff = np.minimum(W, cap[None, :])
    W_safe = W_eff + eps_self * np.eye(n)
    A = W_safe / (np.sum(W_safe, axis=1, keepdims=True) + 1e-12)
    return np.clip((1.0 - lam) * (A @ B) + lam * X, 0.0, 1.0)


# ---------------------------------------------------------------------------
# MORE
# ---------------------------------------------------------------------------


def more_rank(
    uvs: Sequence[float],
    diversity: np.ndarray,
    sai: Sequence[float],
    w1: float = 0.62,
    w2: float = 0.38,
    mu: float = 1.8,
    budget: float = 0.22,
) -> List[int]:
    """Rank candidates by w1*UVS + w2*DBI - mu*max(0, |SAI|-budget)."""
    uvs = np.asarray(uvs, dtype=float)
    diversity = np.asarray(diversity, dtype=float)
    sai = np.asarray(sai, dtype=float)
    penalty = np.maximum(0.0, np.abs(sai) - budget)
    score = w1 * uvs + w2 * diversity - mu * penalty
    return list(np.argsort(score)[::-1])


# ---------------------------------------------------------------------------
# Echo meter and cooling
# ---------------------------------------------------------------------------


def echo_update(r_prev: float, similarity: float, alpha_r: float = 0.25) -> float:
    """R_t = (1-a) R_{t-1} + a (1 - DBI)."""
    return float(np.clip((1.0 - alpha_r) * r_prev + alpha_r * (1.0 - similarity), 0.0, 1.0))


def cooling_active(r: float, threshold: float = 0.75) -> bool:
    return bool(r >= threshold)


# ---------------------------------------------------------------------------
# ERIC moderation
# ---------------------------------------------------------------------------


def eric_penalty(p_prop: float, tau_mod: float = 0.70, lambda_1: float = 1.4) -> float:
    """Visibility penalty for high-velocity propaganda probability."""
    return float(lambda_1 * max(0.0, p_prop - tau_mod))


def eric_escalate(p_prop: float, review_threshold: float = 0.85) -> bool:
    return bool(p_prop > review_threshold)


# ---------------------------------------------------------------------------
# Zewail gate
# ---------------------------------------------------------------------------


def zewail_gate(
    dt: float,
    tau_dephase: float = 28.0,
    e_distract: float = 0.45,
    t_cog: float = 1.0,
    phase: float = 0.0,
) -> float:
    """P_DTS = exp(-dt/tau) * exp(-E/T) * 0.5*(1+cos(phase))."""
    return float(
        np.clip(
            math.exp(-dt / max(tau_dephase, 1e-9))
            * math.exp(-e_distract / max(t_cog, 1e-9))
            * 0.5
            * (1.0 + math.cos(phase)),
            0.0,
            1.0,
        )
    )


# ---------------------------------------------------------------------------
# Zeta power law
# ---------------------------------------------------------------------------


def zeta_pmf(k: int, s: float = 1.8) -> float:
    """P(X=k) = 1/(zeta(s) k^s), k >= 1."""
    from scipy.special import zeta

    if k < 1:
        raise ValueError("k must be >= 1")
    return float(1.0 / (zeta(s) * (k**s)))


def zeta_mode(s: float) -> str:
    if s <= 1.3:
        return "mass_broadcast_convergence"
    if s >= 2.5:
        return "niche_long_tail"
    return "mixed"


# ---------------------------------------------------------------------------
# Dirichlet/Thompson scheduling sketch
# ---------------------------------------------------------------------------


def thompson_schedule(alpha: Sequence[float], rng: np.random.Generator | None = None) -> int:
    """Draw one Dirichlet category weight vector and return its argmax."""
    rng = rng or np.random.default_rng(42)
    weights = rng.dirichlet(np.asarray(alpha, dtype=float))
    return int(np.argmax(weights))


if __name__ == "__main__":
    rng = np.random.default_rng(42)
    brs = BetaBRS()
    for r in [0.8, 0.7, 0.9, 0.6]:
        brs.update(r)
    print("BRS:", round(brs.score, 3), "CI:", tuple(round(x, 3) for x in brs.interval()))

    n = 6
    W = rng.uniform(0, 1, (n, n))
    np.fill_diagonal(W, 0)
    B = np.full(n, 0.5)
    X = rng.uniform(0.4, 0.9, n)
    print("DeGroot:", np.round(degroot_update(B, X, W), 3))

    uvs = rng.uniform(0.2, 0.9, 8)
    dbi = rng.uniform(0.0, 0.8, 8)
    sai = rng.uniform(-0.3, 0.3, 8)
    print("MORE top-3:", more_rank(uvs, dbi, sai)[:3])

    print("Echo:", round(echo_update(0.4, 0.2), 3), "cooling:", cooling_active(0.8))
    print("ERIC penalty:", round(eric_penalty(0.9), 3))
    print("Zewail gate (12 s):", round(zewail_gate(12), 3), " (180 s):", round(zewail_gate(180), 5))
    print("Zeta pmf k=1:", round(zeta_pmf(1, 1.8), 3), zeta_mode(1.8))
    print("Thompson draw:", thompson_schedule([2.5, 4.0, 1.5, 3.0], rng))
