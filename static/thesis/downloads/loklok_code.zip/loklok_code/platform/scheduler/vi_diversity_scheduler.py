"""
vi_diversity_scheduler.py — Variational Inference Diversity Scheduler

THESIS ALIGNMENT: v29 §sec:vi-diversity-scheduler (Stage 14)

Mathematical grounding:
  Uses mean-field variational inference (same BBVI framework as VI_StudentRating.js)
  to model the LATENT DIVERSITY STATE of the broadcast as a Dirichlet-distributed
  random variable over content categories.

  Latent state:
    z ~ Dirichlet(α)   where α = learned concentration parameters
    α is updated after each scheduling decision (variational EM step)

  Objective:
    Maximise ELBO = E_q[log p(x|z)] + E_q[log p(z)] - E_q[log q(z)]
    subject to: BRS governance constraints (B_u ≥ threshold)
                Media target distribution (audio 40%, video 25%, etc.)

  Unpredictability via Thompson Sampling:
    Instead of argmax E[z], we SAMPLE from the posterior q(z|α) at each step.
    This means the scheduler is "legally" unpredictable (posterior samples differ)
    while being "structurally" grounded (the posterior reflects diversity history).

    P(select content type c at step t) ∝ sample from Dir(α_c(t)) × BRS_weight × E(t)

  Pattern integration:
    The Dirichlet concentration α is initialised from the merged Egyptian radio
    stream patterns (stream_analyzer.py): talk/music ratio, jingles/hour, etc.

Why VI and not softmax/greedy:
  - Greedy argmax always picks the same content type given the same inputs →
    predictable, stale-feeling radio
  - Thompson Sampling from VI posterior → each draw is statistically different
    while the posterior mean converges to the target diversity distribution
  - The posterior narrows as more scheduling decisions are made, preventing
    erratic jumps while maintaining genuine unpredictability

References:
  Dirichlet-Multinomial VI: Blei et al. (2017) — already in thesis bibliography
  Thompson Sampling: Thompson (1933); Russo et al. (2018) for theoretical grounding
"""

import json
import math
import random
import time
from dataclasses import dataclass, field
from typing import Optional

import numpy as np

# ── Content categories (must match MEDIA_TARGETS in Realm.js) ─────────────────
CATEGORIES = ['brs_broadcast', 'rj_break', 'station_id',
              'news_capsule', 'loklok_promo', 'sfx_stinger']

# Target distribution priors (thesis §tab:media-targets, adapted for radio clock)
# These become the Dirichlet α_0 (prior concentration parameters)
PRIOR_ALPHA = {
    'brs_broadcast': 6.0,   # dominant: UGC content
    'rj_break':      2.0,
    'station_id':    1.5,
    'news_capsule':  1.0,
    'loklok_promo':  0.8,
    'sfx_stinger':   1.5,   # frequent in Egyptian radio (Nogoum FM pattern)
}

# Energy-boosted concentrations for peak hours (06:00–14:00 NRJ-style)
PEAK_ALPHA_BOOST = {
    'brs_broadcast': 2.0,   # more content
    'sfx_stinger':   1.5,   # more stingers
    'rj_break':      0.5,   # fewer talk breaks (peak hours are music-heavy)
}

# ── Item-level repetition constants (Doc 16 audit spec, March 2026) ───────────
# λ_cat: back-to-back same-category penalty (strong — nearly prohibits repeat)
# λ_item: item played within last 60 minutes — hard filter preferred
# REPEATABLE_CATEGORIES: jingles/SFX repeat freely (standard radio format)
LAMBDA_CAT          = 8.0     # category back-to-back penalty
LAMBDA_ITEM         = 25.0    # item 60-minute soft ban (used as fallback)
ITEM_BAN_SECONDS    = 3600    # hard filter window (60 min)
REPEATABLE_CATEGORIES = {'sfx_stinger'}   # stingers/SFX may repeat freely
LAMBDA_IMMEDIATE_REPEAT = 30.0  # even repeatable categories cannot play the SAME FILE twice in a row


@dataclass
class BRSItem:
    """
    A playable content item in the VI scheduler pool.
    Tracks last-played timestamp for the 60-minute rotation ban.
    """
    id:              str
    category:        str       # 'brs_broadcast'|'rj_break'|'station_id'|
                               # 'news_capsule'|'loklok_promo'|'sfx_stinger'
    brs_score:       float     # 0.0–1.0
    e_score:         float = 0.95
    duration_sec:    int   = 180
    bpm:             float = 0.0
    prop_score:      float = 0.0
    last_played_unix: float = None   # updated after each selection


@dataclass
class SchedulerState:
    """VI posterior state — updated after each scheduling decision."""
    alpha:          dict        # current Dirichlet α per category
    history:        list        # last 30 selections (sliding window)
    elbo_history:   list        # ELBO per step (monitors convergence)
    step:           int = 0
    session_start:  float = field(default_factory=time.time)


# ── Dirichlet VI update ────────────────────────────────────────────────────────

def dirichlet_sample(alpha: dict) -> dict:
    """
    Sample from Dirichlet(α) via Gamma sampling.
    Returns a probability vector over categories.
    Thompson Sampling: each call produces a DIFFERENT draw → unpredictability.
    """
    gammas = {c: np.random.gamma(alpha[c], 1.0) for c in alpha}
    total  = sum(gammas.values()) + 1e-8
    return {c: gammas[c] / total for c in gammas}


def vi_update(state: SchedulerState, selected_category: str,
              brs_weight: float, e_score: float) -> SchedulerState:
    """
    Variational EM update step:
      α_c(t+1) = α_c(t) + w(t) · 1[c = selected]
      where w(t) = BRS_weight × E_score (goodness of the selection)

    This is the closed-form update for the Dirichlet posterior
    (natural parameter conjugate update in the exponential family).
    Higher-quality selections (high BRS, high E(t)) have more weight,
    making good content more likely to be repeated.

    Anti-repetition: count recent history and REDUCE α for over-represented types.
    """
    import copy
    new_alpha = copy.deepcopy(state.alpha)

    # Positive update for selected category
    update_weight = max(0.1, brs_weight) * max(0.1, e_score)
    new_alpha[selected_category] = (new_alpha.get(selected_category, 1.0)
                                    + update_weight)

    # Anti-repetition: if a category appears > 3 times in last 10 steps, decay its α
    recent = state.history[-10:] if len(state.history) >= 10 else state.history
    for cat in CATEGORIES:
        count = sum(1 for h in recent if h == cat)
        if count > 3:
            # Reduce concentration — makes it less likely next step
            decay = 0.85 ** (count - 3)
            new_alpha[cat] = max(0.5, new_alpha[cat] * decay)

    # ELBO estimate (negative KL divergence proxy — monitor convergence)
    # For Dirichlet: KL(q||p) ≈ Σ (α_q - α_p) × (ψ(α_q) - ψ(Σα_q))
    # where ψ is the digamma function
    kl = 0.0
    for cat in CATEGORIES:
        aq = new_alpha.get(cat, 1.0)
        ap = PRIOR_ALPHA.get(cat, 1.0)
        kl += (aq - ap) * (_digamma(aq) - _digamma(sum(new_alpha.values())))
    elbo = -kl

    new_history = state.history + [selected_category]
    new_history = new_history[-30:]   # sliding window

    return SchedulerState(
        alpha        = new_alpha,
        history      = new_history,
        elbo_history = state.elbo_history + [elbo],
        step         = state.step + 1,
        session_start= state.session_start,
    )


def _digamma(x: float) -> float:
    """Digamma function approximation (Stirling series)."""
    if x <= 0: return -1e6
    result = 0.0
    while x < 6:
        result -= 1.0 / x
        x += 1
    result += math.log(x) - 1.0/(2*x) - 1.0/(12*x*x) + 1.0/(120*x**4)
    return result


# ── Pattern-informed prior ────────────────────────────────────────────────────

def build_prior_from_patterns(merged_pattern: dict) -> dict:
    """
    Override PRIOR_ALPHA with learned Egyptian radio patterns.
    Maps talk_music_ratio and jingles_per_hour to Dirichlet concentrations.
    """
    alpha = dict(PRIOR_ALPHA)   # start from defaults

    talk_ratio     = merged_pattern.get('talk_music_ratio', 0.25)
    jingles_per_hr = merged_pattern.get('jingles_per_hour', 12.0)
    seg_interval_s = merged_pattern.get('mean_segment_interval_s', 210.0)

    # Adjust concentrations from learned patterns
    # More talk in pattern → higher α for rj_break and news_capsule
    alpha['rj_break']    = max(0.5, alpha['rj_break']    * (1 + talk_ratio))
    alpha['news_capsule']= max(0.5, alpha['news_capsule'] * (1 + talk_ratio * 0.5))
    # More jingles in pattern → higher α for sfx_stinger
    alpha['sfx_stinger'] = max(0.5, alpha['sfx_stinger'] * (jingles_per_hr / 12.0))
    # Shorter segment interval → more frequent stingers
    if seg_interval_s < 180:
        alpha['sfx_stinger'] *= 1.5

    return alpha


def adjust_for_hour(alpha: dict, hour: int) -> dict:
    """Apply peak-hour or off-peak adjustments to Dirichlet concentration."""
    import copy
    adj = copy.deepcopy(alpha)
    is_peak = 6 <= hour < 14
    if is_peak:
        for cat, boost in PEAK_ALPHA_BOOST.items():
            adj[cat] = adj.get(cat, 1.0) + boost
    return adj


# ── Main scheduler ────────────────────────────────────────────────────────────

class VIDiversityScheduler:
    """
    VI-based diversity scheduler for the LOKLOK Global Station.

    Replaces the fixed-template broadcast clock with a Thompson Sampling
    draw from the Dirichlet posterior at each scheduling decision.

    Properties:
      1. GROUNDED: posterior mean converges toward target diversity distribution
      2. UNPREDICTABLE: each Thompson Sample is statistically different
      3. ANTI-REPETITION: recent history decays α for over-represented types
      4. PATTERN-INFORMED: priors from Egyptian radio stream analysis
      5. BRS-GOVERNED: only BRS-qualified content is eligible for selection
    """

    def __init__(self, merged_pattern: Optional[dict] = None, seed: int = None):
        if seed:
            np.random.seed(seed)
            random.seed(seed)
        hour = time.localtime().tm_hour
        base_alpha = (build_prior_from_patterns(merged_pattern)
                      if merged_pattern else dict(PRIOR_ALPHA))
        adjusted  = adjust_for_hour(base_alpha, hour)
        self.state = SchedulerState(alpha=adjusted, history=[], elbo_history=[])
        self.merged_pattern = merged_pattern or {}
        # Item-level tracking (Doc 16 audit spec)
        self.last_category:    Optional[str] = None   # category of last played item
        self.category_history: list          = []     # last 10 categories for overuse
        self.last_item_id:     Optional[str] = None   # id of last played file (Doc 17)

    def select_next(self, brs_pool: list,
                    sfx_pool: list,
                    hour: int) -> dict:
        """
        Select the next segment via Thompson Sampling with item-level protection.

        Updated scoring equation (Doc 16 audit spec, March 2026):
          score_i = p[c_i] × BRS_i × E(t)_i
                    − overuse_penalty_i
                    − λ_cat × I(c_i = last_category AND c_i ∉ REPEATABLE)
                    − λ_item × I(item played < 60 min AND c_i ∉ REPEATABLE)  [soft fallback]
                    + Gumbel(0, 0.02)

        Hard filter: non-repeatable items played within 60 min are removed
        from candidates before scoring (preferred over soft penalty).
        λ_cat = 8.0, λ_item = 25.0 (effective no-op after hard filter).

        Unchanged from original: Thompson draw, VI posterior update, peak-hour α,
        ELBO monitoring, deterministic fallback.
        """
        # Adjust α for current hour (unchanged)
        hour_alpha = adjust_for_hour(self.state.alpha, hour)

        # Thompson Sample — source of unpredictability (unchanged)
        p_sample = dirichlet_sample(hour_alpha)

        # Build unified content pool (BRS + SFX items)
        now = time.time()
        all_items = []
        for item in brs_pool:
            all_items.append({**item,
                '_ctype':       'brs_broadcast',
                '_brs':         item.get('brs_score', 0.5),
                '_e':           item.get('e_score', 0.9),
                '_last_played': item.get('last_played_unix'),
            })
        for item in sfx_pool:
            all_items.append({**item,
                '_ctype':       item.get('asset_type', 'sfx_stinger'),
                '_brs':         1.0,   # SFX always "qualify"
                '_e':           1.0,
                '_last_played': item.get('last_played_unix'),
            })

        if not all_items:
            return {'_ctype': 'backup', '_vi_score': 0}

        # ── HARD FILTER: remove non-repeatable items played < 60 min ago ──────
        # Standard radio rotation rule (NRJ / Nogoum FM format).
        # sfx_stinger is exempt — jingles repeat freely.
        qualified = []
        for item in all_items:
            cat        = item['_ctype']
            last_p     = item['_last_played']
            in_ban     = (cat not in REPEATABLE_CATEGORIES
                          and last_p is not None
                          and (now - last_p) < ITEM_BAN_SECONDS)
            if in_ban:
                continue

            # ── IMMEDIATE REPEAT FILTER (Doc 17 spec) ────────────────────────
            # Never play the exact same file twice in a row, even for stingers.
            # Hard filter is primary; soft penalty (λ_immediate) is safety net.
            if item.get('id') and item['id'] == self.last_item_id:
                continue   # hard ban on consecutive identical file

            qualified.append(item)

        # If every item is banned (tiny pool — shouldn't happen in production),
        # relax the filter and allow oldest items through
        if not qualified:
            qualified = sorted(
                all_items,
                key=lambda x: x['_last_played'] or 0
            )[:max(1, len(all_items) // 3)]

        # ── SCORING (new equation, Doc 16 spec) ───────────────────────────────
        recent_10 = self.category_history[-10:]

        candidates = []
        for item in qualified:
            cat = item['_ctype']

            # Overuse penalty (category level, last 10 slots — unchanged logic)
            count_recent = recent_10.count(cat)
            overuse_pen  = 0.15 * max(0, count_recent - 2)

            # Back-to-back same-category penalty (λ_cat)
            # Zero for REPEATABLE_CATEGORIES
            cat_rep_pen  = (LAMBDA_CAT
                            if cat == self.last_category
                            and cat not in REPEATABLE_CATEGORIES
                            else 0.0)

            # Item-level soft penalty (λ_item) — safety net if hard filter missed
            last_p      = item['_last_played']
            item_rep_pen = (LAMBDA_ITEM
                            if cat not in REPEATABLE_CATEGORIES
                            and last_p is not None
                            and (now - last_p) < ITEM_BAN_SECONDS
                            else 0.0)

            # Immediate-repeat soft penalty — safety net for same-file check
            # (hard filter already blocked this; 30.0 catches edge cases)
            immediate_pen = (LAMBDA_IMMEDIATE_REPEAT
                             if item.get('id') and item['id'] == self.last_item_id
                             else 0.0)

            # Full score (Doc 16 + Doc 17 Equation)
            score = (p_sample.get(cat, 0)
                     * item['_brs']
                     * item['_e']
                     - overuse_pen
                     - cat_rep_pen
                     - item_rep_pen
                     - immediate_pen
                     + np.random.gumbel(0, 0.02))   # Gumbel noise (Maddison et al., 2017)

            candidates.append({**item, '_vi_score': score})

        # Pick winner
        selected = max(candidates, key=lambda x: x['_vi_score'])

        # ── POST-SELECTION UPDATES ─────────────────────────────────────────────
        # A. VI posterior update (unchanged)
        self.state = vi_update(
            self.state,
            selected['_ctype'],
            brs_weight=selected.get('_brs', 0.5),
            e_score=selected.get('_e', 0.9),
        )

        # B. Item-level tracking (Doc 16 + Doc 17 spec)
        selected['last_played_unix'] = now   # caller should write this back to pool item
        self.last_category = selected['_ctype']
        self.last_item_id  = selected.get('id')   # Doc 17: track exact file id
        self.category_history.append(selected['_ctype'])
        if len(self.category_history) > 10:
            self.category_history.pop(0)

        selected['_thompson_probs'] = p_sample
        selected['_elbo']           = self.state.elbo_history[-1] if self.state.elbo_history else 0
        return selected

    def get_diversity_report(self) -> dict:
        """Return posterior state summary for the monitoring dashboard."""
        return {
            'step':          self.state.step,
            'alpha':         self.state.alpha,
            'elbo_latest':   self.state.elbo_history[-1] if self.state.elbo_history else 0,
            'history':       self.state.history[-10:],
            'type_fractions': {cat: self.state.history.count(cat) / max(1, len(self.state.history))
                               for cat in CATEGORIES},
        }

    def simulate(self, n_steps: int = 60, brs_pool: list = None,
                 hour: int = 10) -> list:
        """Simulate n_steps scheduling decisions (for dry-run/testing)."""
        if brs_pool is None:
            np.random.seed(2026)
            # Include last_played_unix=None (not yet played) — Doc 16 format
            brs_pool = [
                {'id': f'bc{i:03d}', 'brs_score': np.random.uniform(0.55, 0.92),
                 'prop_score': np.random.uniform(0, 0.15),
                 'duration_sec': int(np.random.uniform(90, 300)),
                 'bpm': float(np.random.uniform(85, 130)),
                 'e_score': float(np.random.uniform(0.85, 1.15)),
                 'last_played_unix': None}  # NEW: item-level tracking
                for i in range(20)
            ]
        sfx_pool = [
            {'id': f'sfx_{i}', 'asset_type': 'sfx_stinger',
             'last_played_unix': None} for i in range(5)
        ] + [
            {'id': f'sid_{i}', 'asset_type': 'station_id',
             'last_played_unix': None} for i in range(3)
        ]

        # Build a mutable pool dict for tracking last_played_unix across steps
        pool_by_id = {item['id']: item for item in brs_pool + sfx_pool}

        schedule = []
        for step in range(n_steps):
            item = self.select_next(brs_pool, sfx_pool, hour)

            # Write last_played_unix back to pool item (Doc 16 spec §5B)
            item_id = item.get('id')
            if item_id and item_id in pool_by_id:
                pool_by_id[item_id]['last_played_unix'] = item.get('last_played_unix')

            schedule.append({
                'step':   step,
                'ctype':  item.get('_ctype'),
                'id':     item.get('id', '-'),
                'brs':    item.get('_brs', item.get('brs_score', 0)),
                'e':      item.get('_e', item.get('e_score', 0)),
                'elbo':   item.get('_elbo', 0),
                'last_cat': self.last_category,
                'p_draw': {k: round(v, 3) for k, v in
                           item.get('_thompson_probs', {}).items()},
            })
        return schedule


# ── CLI demo ──────────────────────────────────────────────────────────────────

if __name__ == '__main__':
    print("\nVI Diversity Scheduler — Thompson Sampling Demo")
    print("=" * 60)

    # Load merged patterns if available
    merged = None
    try:
        import os, glob
        files = sorted(glob.glob('/tmp/radio_patterns/*.json'))
        if files:
            patterns = {}
            for f in files:
                with open(f) as fh:
                    d = json.load(fh)
                    patterns[d['stream_id']] = type('P', (), d)
            from stream_analyzer import merge_patterns
            merged = merge_patterns(patterns)
            print(f"Loaded {len(patterns)} stream patterns")
    except Exception:
        print("No stream patterns loaded — using default Egyptian radio priors")

    sched = VIDiversityScheduler(merged_pattern=merged, seed=2026)
    schedule = sched.simulate(n_steps=20, hour=10)

    print(f"\n{'Step':>4}  {'Type':<18}  {'BRS':>5}  {'E(t)':>6}  {'ELBO':>7}")
    print("-" * 50)
    for s in schedule:
        print(f"{s['step']:>4}  {s['ctype']:<18}  "
              f"{s['brs']:>5.2f}  {s['e']:>6.3f}  {s['elbo']:>7.4f}")

    report = sched.get_diversity_report()
    print(f"\nDiversity report after 20 steps:")
    for cat, frac in report['type_fractions'].items():
        bar = '█' * int(frac * 20)
        print(f"  {cat:<18} {frac:.2f} {bar}")
