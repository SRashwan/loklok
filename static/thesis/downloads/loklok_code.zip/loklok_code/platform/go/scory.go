package services

import (
	"context"
	"crypto/rand"
	"encoding/json"
	"errors"
	"math"
	"math/big"
	"time"

	"loklok-backend/cpvl"
	"loklok-backend/epistemic"
	"loklok-backend/metrics"

	"github.com/nats-io/nats.go"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/bson/primitive"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

// ─── Research Scoring Service (Stage27 "Scory") ───
// Implements the ACU thesis experiment protocol:
//   - Arm A/B assignment (RCT, 50/50) — stable per user in Mongo.
//   - BRS (Broadcast Reach Score) update rule from thesis §BRS:
//         delta  = alpha * ((0.4*bRig + 0.35*bInf + 0.25*bSoc) - bUPrev)
//         newBRS = clamp(bUPrev + delta, 0, 1)

type ScoreResult struct {
	BroadcasterID string  `json:"broadcasterId"`
	SessionID     string  `json:"sessionId,omitempty"`
	BRS           float64 `json:"bRS"`
	Delta         float64 `json:"delta"`
	BUPrev        float64 `json:"bUPrev"`
	BRig          float64 `json:"bRig"`
	BInf          float64 `json:"bInf"`
	BSoc          float64 `json:"bSoc"`
}

// stateDoc is the per-user research state: beta-BRS + echo meter.
type stateDoc struct {
	UserID    primitive.ObjectID `bson:"_id"`
	Arm       string             `bson:"arm"`
	BrsAlpha  float64            `bson:"brsAlpha"`
	BrsBeta   float64            `bson:"brsBeta"`
	EchoR     float64            `bson:"echoR"`
	LastTags  []string           `bson:"lastTags"`
	UpdatedAt time.Time          `bson:"updatedAt"`
}

// EchoResult summarises one consumption observation (GENOME v3 Echo Meter).
type EchoResult struct {
	R        float64 `json:"r"`
	Amber    bool    `json:"amber"`
	Cooling  bool    `json:"cooling"`
	RecallL2 bool    `json:"recallL2"` // echo meter ≥0.60 → EMA layer 2 recall
}

// BRSState is the beta-Bayesian broadcaster score + credibility interval.
type BRSState struct {
	Score    float64 `json:"bRS"`
	CI_Lo    float64 `json:"ciLow"`
	CI_Hi    float64 `json:"ciHigh"`
	Evidence float64 `json:"evidence"`
	SE       float64 `json:"se"`
}

// EMADecision is the DTS-gated result of an EMA layer request.
type EMADecision struct {
	Layer    string  `json:"layer"`
	Trigger  bool    `json:"trigger"`
	Deferred bool    `json:"deferred"`
	PRead    float64 `json:"pReadiness"`
}

type ScoryService struct {
	arms   *mongo.Collection
	scores *mongo.Collection
	state  *mongo.Collection
	ema    *mongo.Collection
	nc     *nats.Conn
	cvl    cpvl.Client
}

type armDoc struct {
	UserID     primitive.ObjectID `bson:"_id"`
	Arm        string             `bson:"arm"`
	AssignedAt time.Time          `bson:"assignedAt"`
}

type scoreDoc struct {
	BroadcasterID string    `bson:"_id"`
	BRS           float64   `bson:"bRS"`
	Delta         float64   `bson:"delta"`
	BUPrev        float64   `bson:"bUPrev"`
	BRig          float64   `bson:"bRig"`
	BInf          float64   `bson:"bInf"`
	BSoc          float64   `bson:"bSoc"`
	UpdatedAt     time.Time `bson:"updatedAt"`
}

func NewScoryService(db *mongo.Database) *ScoryService {
	return &ScoryService{
		arms:   db.Collection("experiment_arms"),
		scores: db.Collection("research_scores"),
		state:  db.Collection("research_state"),
		ema:    db.Collection("ema_sessions"),
	}
}

// WithNATS attaches a NATS publisher so research events (echo meter updates,
// EMA decisions) are broadcast to the governance ledger agent (T2-03).
func (s *ScoryService) WithNATS(nc *nats.Conn) *ScoryService {
	s.nc = nc
	return s
}

// WithCPVL attaches the swappable psychometrics backend (CONFIG: CPVL_URL).
// When attached it answers the DTS gate for capital EMA layers; when the URL is
// unset the backend keeps its deterministic offline gate (cpvl.NewClient(""))
// and never dials the network. Providers are swappable: mock vs live REST.
func (s *ScoryService) WithCPVL(cl cpvl.Client) *ScoryService {
	s.cvl = cl
	return s
}

// publish broadcasts a governance event if a NATS connection is attached.
// These are fire-and-forget; failures are swallowed so the research path never
// blocks on the ledger sidecar being unavailable.
func (s *ScoryService) publish(subject string, data interface{}) {
	if s.nc == nil {
		return
	}
	payload, err := json.Marshal(data)
	if err != nil {
		return
	}
	s.nc.Publish(subject, payload)
}

// AssignArm returns the user's experiment arm, assigning one (50/50 RCT) on
// first request. Assignment is persisted so it stays stable across sessions.
func (s *ScoryService) AssignArm(userID primitive.ObjectID) (string, error) {
	if userID.IsZero() {
		return "A", nil
	}
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	var d armDoc
	err := s.arms.FindOne(ctx, bson.M{"_id": userID}).Decode(&d)
	if err == nil {
		return d.Arm, nil
	}
	if err != mongo.ErrNoDocuments {
		return "A", err
	}
	n, perr := rand.Int(rand.Reader, big.NewInt(2))
	if perr != nil {
		return "A", perr
	}
	arm := "A"
	if n.Int64() == 1 {
		arm = "B"
	}
	_, err = s.arms.UpdateOne(ctx, bson.M{"_id": userID}, bson.M{"$setOnInsert": bson.M{"arm": arm, "assignedAt": time.Now()}}, options.Update().SetUpsert(true))
	return arm, err
}

// Score applies the BRS update rule and persists the latest broadcaster score.
func (s *ScoryService) Score(broadcasterID, sessionID string, bRig, bInf, bSoc, bUPrev, alpha float64) (*ScoreResult, error) {
	if broadcasterID == "" {
		return nil, errors.New("broadcasterId required")
	}
	bRig = bias(bRig)
	bInf = bias(bInf)
	bSoc = bias(bSoc)
	bUPrev = bias(bUPrev)
	if alpha <= 0 {
		alpha = 0.1
	}
	delta := alpha * ((0.4*bRig + 0.35*bInf + 0.25*bSoc) - bUPrev)
	newBRS := clamp(bUPrev+delta, 0, 1)

	res := &ScoreResult{
		BroadcasterID: broadcasterID,
		SessionID:     sessionID,
		BRS:           newBRS,
		Delta:         delta,
		BUPrev:        bUPrev,
		BRig:          bRig,
		BInf:          bInf,
		BSoc:          bSoc,
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	doc := scoreDoc{
		BroadcasterID: broadcasterID,
		BRS:           newBRS, Delta: delta, BUPrev: bUPrev,
		BRig: bRig, BInf: bInf, BSoc: bSoc,
		UpdatedAt: time.Now(),
	}
	_, err := s.scores.UpdateOne(ctx, bson.M{"_id": broadcasterID}, bson.M{"$set": doc}, options.Update().SetUpsert(true))
	if err != nil {
		return res, err
	}
	return res, nil
}

// Batch applies the BRS rule to a list of entries without persisting (lightweight).
func (s *ScoryService) Batch(entries []BatchEntry) []BatchResult {
	out := make([]BatchResult, 0, len(entries))
	for _, e := range entries {
		var rg, inf, soc, uprev, alpha = bias(e.BRig), bias(e.BInf), bias(e.BSoc), bias(e.BUPrev), e.Alpha
		if alpha <= 0 {
			alpha = 0.1
		}
		delta := alpha * ((0.4*rg + 0.35*inf + 0.25*soc) - uprev)
		out = append(out, BatchResult{
			BroadcasterID: e.BroadcasterID,
			BRS:           clamp(uprev+delta, 0, 1),
		})
	}
	return out
}

// LatestScore returns the most recent persisted BRS for a broadcaster (0.5 if none).
func (s *ScoryService) LatestScore(broadcasterID string) (float64, error) {
	var d scoreDoc
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	err := s.scores.FindOne(ctx, bson.M{"_id": broadcasterID}).Decode(&d)
	if err == mongo.ErrNoDocuments {
		return 0.5, nil
	}
	if err != nil {
		return 0.5, err
	}
	return d.BRS, nil
}

// BRS algorithm label per arm (research protocol metadata).
func ArmAlgorithm(arm string) string {
	if arm == "B" {
		return "popular_BRS"
	}
	return "diverse_MORE"
}

// ─── Beta-Bayesian BRS + Echo Meter + EMA/DTS (GENOME v3 A1/A5, Echo Meter) ───

const (
	echoAlpha = 0.25 // a_R EMA memory factor
	dtsBeta   = 2.0  // readiness sigmoid slope
	dtsDelta  = 0.5  // δ_Ea midpoint
	emaPMin   = 0.6  // P_min: below this, critical EMA layers defer
)

func (s *ScoryService) loadState(userID primitive.ObjectID) (stateDoc, error) {
	var d stateDoc
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	err := s.state.FindOne(ctx, bson.M{"_id": userID}).Decode(&d)
	if err == mongo.ErrNoDocuments {
		return stateDoc{UserID: userID, BrsAlpha: 2, BrsBeta: 2}, nil
	}
	return d, err
}

func (s *ScoryService) saveState(d stateDoc) error {
	d.UpdatedAt = time.Now()
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	_, err := s.state.UpdateOne(ctx, bson.M{"_id": d.UserID},
		bson.M{"$set": d}, options.Update().SetUpsert(true))
	return err
}

// State returns a read-model of one user's whole research state (arm + BRS + echo).
func (s *ScoryService) State(userID primitive.ObjectID) (map[string]interface{}, error) {
	if userID.IsZero() {
		return nil, errors.New("user required")
	}
	arm, err := s.AssignArm(userID)
	if err != nil {
		return nil, err
	}
	d, err := s.loadState(userID)
	if err != nil {
		return nil, err
	}
	brs := &epistemic.BRS{Alpha: maxF(d.BrsAlpha, 2), Beta: maxF(d.BrsBeta, 2)}
	lo, hi := brs.CI()
	return map[string]interface{}{
		"ok":  true,
		"arm": arm,
		"brs": BRSState{
			Score:    brs.Score(),
			CI_Lo:    lo,
			CI_Hi:    hi,
			Evidence: brs.Evidence(),
			SE:       brs.SE(),
		},
		"echo": EchoResult{
			R:        d.EchoR,
			Amber:    epistemic.IsEchoAmber(d.EchoR),
			Cooling:  epistemic.IsEchoCooling(d.EchoR),
			RecallL2: epistemic.IsEchoAmber(d.EchoR),
		},
	}, nil
}

// Feedback applies one weighted quality rating to a broadcaster's beta BRS.
func (s *ScoryService) Feedback(broadcasterID primitive.ObjectID, rating, weight float64) (*BRSState, error) {
	if broadcasterID.IsZero() {
		return nil, errors.New("broadcasterId required")
	}
	d, err := s.loadState(broadcasterID)
	if err != nil {
		return nil, err
	}
	brs := &epistemic.BRS{Alpha: maxF(d.BrsAlpha, 2), Beta: maxF(d.BrsBeta, 2)}
	if weight <= 0 {
		weight = 1
	}
	brs.Update(rating, weight)
	d.BrsAlpha, d.BrsBeta = brs.Alpha, brs.Beta
	if err := s.saveState(d); err != nil {
		return nil, err
	}
	lo, hi := brs.CI()
	s.publish("loklok.governance.decision", map[string]interface{}{
		"kind":        "feedback",
		"broadcaster": broadcasterID.Hex(),
		"rating":      rating,
		"brs":         brs.Score(),
		"ts":          time.Now().UnixMilli(),
	})
	return &BRSState{Score: brs.Score(), CI_Lo: lo, CI_Hi: hi, Evidence: brs.Evidence(), SE: brs.SE()}, nil
}

// ObserveEcho records a consumption event (tag set) and updates Echo R_t.
func (s *ScoryService) ObserveEcho(userID primitive.ObjectID, tags []string) (*EchoResult, error) {
	if userID.IsZero() {
		return nil, errors.New("user required")
	}
	d, err := s.loadState(userID)
	if err != nil {
		return nil, err
	}
	newVec := tagsToVec(tags)
	prevVec := tagsToVec(d.LastTags)
	d.EchoR = epistemic.UpdateEcho(d.EchoR, echoAlpha, prevVec, newVec)
	d.LastTags = tags
	if err := s.saveState(d); err != nil {
		return nil, err
	}
	s.publish("loklok.echo_meter.update", map[string]interface{}{
		"user":  userID.Hex(),
		"echoR": d.EchoR,
		"amber": epistemic.IsEchoAmber(d.EchoR),
		"tags":  tags,
		"ts":    time.Now().UnixMilli(),
	})
	metrics.ObserveEcho(d.EchoR)
	return &EchoResult{
		R:        d.EchoR,
		Amber:    epistemic.IsEchoAmber(d.EchoR),
		Cooling:  epistemic.IsEchoCooling(d.EchoR),
		RecallL2: epistemic.IsEchoAmber(d.EchoR),
	}, nil
}

// EvalEMA answers one EMA layer request under the DTS gate (GENOME v3 A5).
// Layers: 1=post-broadcast, 2=echo-triggered, 3=weekly, 4=pre-broadcast.
func (s *ScoryService) EvalEMA(userID primitive.ObjectID, layer int, iD float64) (*EMADecision, error) {
	if userID.IsZero() {
		return nil, errors.New("user required")
	}
	d, err := s.loadState(userID)
	if err != nil {
		return nil, err
	}
	dts := &epistemic.DTS{Beta: dtsBeta, Delta: dtsDelta}
	// Layers 1 & 4 are "capital" prompts gated by DTS; layer 2 is echo-triggered.
	// When a CPVL client is attached it answers the capital gate (config opt-in);
	// an unreachable provider degrades gracefully to the offline gate.
	var trigger, deferLater bool
	pRead := dts.ProbReadiness(iD)
	psyc := ""
	switch {
	case layer == 2:
		trigger = epistemic.IsEchoAmber(d.EchoR)
	case s.cvl != nil:
		if dec, cerr := s.cvl.EMA(context.Background(), layer, iD); cerr != nil {
			trigger, deferLater = dts.ShouldTrigger(iD, layer, emaPMin)
			pRead = dts.ProbReadiness(iD)
			psyc = "mock:fallback"
		} else {
			trigger, pRead = dec.Trigger, dec.PRead
			psyc = s.cvl.Name()
		}
	default:
		trigger, deferLater = dts.ShouldTrigger(iD, layer, emaPMin)
	}
	if trigger {
		metrics.ObserveDecision()
		ev := map[string]interface{}{
			"user":    userID.Hex(),
			"layer":   layer,
			"echoR":   d.EchoR,
			"pRead":   pRead,
			"trigger": true,
			"ts":      time.Now().UnixMilli(),
		}
		if psyc != "" {
			ev["provider"] = psyc
		}
		s.publish("loklok.ema.trigger", ev)
	}
	return &EMADecision{Layer: emaLayerName(layer), Trigger: trigger, Deferred: deferLater, PRead: pRead}, nil
}

func tagsToVec(tags []string) epistemic.TagVec {
	v := epistemic.TagVec{}
	for _, t := range tags {
		if t != "" {
			v[t] += 1
		}
	}
	return v
}

func emaLayerName(layer int) string {
	switch layer {
	case 1:
		return "post_broadcast"
	case 2:
		return "echo"
	case 3:
		return "weekly"
	case 4:
		return "pre_broadcast"
	}
	return "unknown"
}

func maxF(a, b float64) float64 {
	if a > b {
		return a
	}
	return b
}

type BatchEntry struct {
	BroadcasterID string  `json:"broadcasterId"`
	BRig          float64 `json:"bRig"`
	BInf          float64 `json:"bInf"`
	BSoc          float64 `json:"bSoc"`
	BUPrev        float64 `json:"bUPrev"`
	Alpha         float64 `json:"alpha"`
}

type BatchResult struct {
	BroadcasterID string  `json:"broadcasterId"`
	BRS           float64 `json:"bRS"`
}

func bias(v float64) float64 {
	if math.IsNaN(v) || v < 0 {
		return 0.5
	}
	if v > 1 {
		return 1
	}
	return v
}

func clamp(v, lo, hi float64) float64 {
	if v < lo {
		return lo
	}
	if v > hi {
		return hi
	}
	return v
}
