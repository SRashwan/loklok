// Package epistemic implements the LOKLOK research algorithms from GENOME v3
// (A1-A7, Echo Meter, DTS, Algorithmic Cooling, Propaganda, MORE, DeGroot).
// All functions are pure (randomness injected, no DB/NATS deps) so they can be
// unit-tested and reused by services, workers and the ABM runner alike.
package epistemic

import (
	"math"
	"sort"
	"time"
)

// ─── A1 · Broadcaster Reputation Score (Beta-Bayesian) ───

// BRS tracks a Beta(posterior) over a broadcaster's latent quality.
// Default flat prior a0=b0=2 keeps score=0.5 with zero evidence.
type BRS struct {
	Alpha float64 `json:"alpha"`
	Beta  float64 `json:"beta"`
}

func NewBRS(a0, b0 float64) *BRS {
	if a0 < 1 {
		a0 = 1
	}
	if b0 < 1 {
		b0 = 1
	}
	return &BRS{Alpha: a0, Beta: b0}
}

// Update applies one weighted rating r in [0,1] via the conjugate update:
// alpha += w*r, beta += w*(1-r).
func (b *BRS) Update(r float64, w float64) {
	if r < 0 || r > 1 {
		return
	}
	if w < 0 {
		w = -w
	}
	b.Alpha += w * r
	b.Beta += w * (1 - r)
}

func (b *BRS) Score() float64 {
	n := b.Alpha + b.Beta
	if n == 0 {
		return 0.5
	}
	return b.Alpha / n
}

// Evidence is the total strength (alpha+beta).
func (b *BRS) Evidence() float64 { return b.Alpha + b.Beta }

// Variance returns Var[Beta(alpha,beta)].
func (b *BRS) Variance() float64 {
	n := b.Alpha + b.Beta
	if n <= 0 {
		return 0.25
	}
	num := b.Alpha * b.Beta
	den := n * n * (n + 1)
	if den == 0 {
		return 0.25
	}
	return num / den
}

func (b *BRS) SE() float64 { return math.Sqrt(b.Variance()) }

// CI returns the approximate 95% credibility interval (normal approx. on the
// posterior mean), matching the engine's `score ± 1.96·se` display.
func (b *BRS) CI() (lo, hi float64) {
	s := b.Score()
	se := b.SE()
	return clamp(s-1.96*se, 0, 1), clamp(s+1.96*se, 0, 1)
}

// Blended combines this BRS with a naive 0.5 prior when evidence is thin
// (privacy-weighted credibility w_i = 1/(1+theta·se_i) is used elsewhere).
func (b *BRS) Blended(fallback float64) float64 {
	e := b.Evidence()
	if e < 1 {
		return fallback
	}
	return (b.Score()*e + fallback) / (e + 1)
}

// ─── Echo Meter (consumption echo) ───

type TagVec map[string]float64

// Cosine similarity between two tag vectors (bag-of-tags / TF-IDF style).
func Cosine(a, b TagVec) float64 {
	num, da, db := 0.0, 0.0, 0.0
	for k, v := range a {
		num += v * b[k]
		da += v * v
	}
	for _, v := range b {
		db += v * v
	}
	if da == 0 || db == 0 {
		return 0
	}
	return num / (math.Sqrt(da) * math.Sqrt(db))
}

const (
	EchoAmber   = 0.60 // R_t ≥ 0.60 → EMA layer 2 (EM1-3)
	EchoCooling = 0.75 // R_t ≥ 0.75 → Algorithmic Cooling intervention
)

// UpdateEcho applies the EMA recursion: R_t = (1-a)·R_{t-1} + a·cos_sim(prev, new).
func UpdateEcho(rPrev, aR float64, prev, new TagVec) float64 {
	if aR <= 0 || aR > 1 {
		aR = 0.25
	}
	return (1-aR)*rPrev + aR*Cosine(prev, new)
}

func IsEchoAmber(r float64) bool   { return r >= EchoAmber }
func IsEchoCooling(r float64) bool { return r >= EchoCooling }

// ─── DTS (Demand for Truth Seeking) readiness gate ───

type DTS struct {
	Beta  float64 `json:"beta"`
	Delta float64 `json:"delta"` // δ_Ea: midpoint of the readiness sigmoid
}

// ProbReadiness: P_DTS(c,u,t) = 1/(1+e^(−β·(I_D,inst − δ_Ea))).
func (d *DTS) ProbReadiness(iD float64) float64 {
	return 1 / (1 + math.Exp(-d.Beta*(iD-d.Delta)))
}

// ShouldTrigger decides when an EMA prompt fires. For "capital" layers (1=post-
// broadcast, 4=pre-broadcast) a low DTS defers 5 minutes instead of dropping;
// weekly (2) / echo-triggered (3) layers fire regardless of DTS.
func (d *DTS) ShouldTrigger(iD float64, layer int, pMin float64) (trigger, deferToLater bool) {
	p := d.ProbReadiness(iD)
	if layer == 1 || layer == 4 {
		if p < pMin {
			return false, true
		}
		return true, false
	}
	return true, false
}

// ─── A3 · Propaganda Detection ───

type PropagandaFeatures struct {
	HHI        float64 // source-citation concentration (Herfindahl)
	Sensational float64
	Velocity   float64 // posting-rate anomaly
}

type Propaganda struct {
	Theta [3]float64   // weights for [HHI, sensational, velocity]
	TiS   float64      // φ_TIS trust-in-source penalty (0..1)
}

func (p *Propaganda) Score(f PropagandaFeatures) float64 {
	tf := p.Theta[0]*f.HHI + p.Theta[1]*f.Sensational + p.Theta[2]*f.Velocity
	return 0.7*sigmoid(tf) + 0.3*p.TiS
}

// HHIFromCounts computes source-concentration in [0,1] (1 = single source).
func HHIFromCounts(counts map[string]int) float64 {
	var total int
	for _, c := range counts {
		total += c
	}
	if total == 0 {
		return 0
	}
	var hhi float64
	for _, c := range counts {
		s := float64(c) / float64(total)
		hhi += s * s
	}
	return hhi
}

// ModerationCost returns λ·max(0, P_prop−0.70) subtracted from MORE scores.
func ModerationCost(lambda, pProp float64) float64 {
	return lambda * math.Max(0, pProp-0.70)
}

// Escalate reports whether ERIC should open a human-review case (≥0.85).
func Escalate(pProp float64) bool { return pProp >= 0.85 }

// ─── A2 · MORE (Multi-Objective Recommendation Engine) ───

type MOREConfig struct {
	W1        float64 // UVS weight
	W2        float64 // DBI (diversity) weight
	Lambda1   float64 // moderation cost scale
	BiasMax   float64 // SAI budget B_max
}

type Candidate struct {
	ID    string
	UVS   float64 // user-value score (quality × fit)
	DBI   float64 // diversity benefit (echo-reducing)
	PProp float64 // propaganda score (0..1)
	SAI   float64 // selection-advantage index, [-1,1] (0 neutral)
}

type Ranked struct {
	ID     string  `json:"id"`
	Score  float64 `json:"score"`
	PProp  float64 `json:"pProp"`
	Cooled bool    `json:"cooled"`
}

// Rank scores every candidate as argmax(w1·UVS + w2·DBI − λ·max(0,P−0.70))
// and returns them in descending order.
func (m *MOREConfig) Rank(cands []Candidate) []Ranked {
	out := make([]Ranked, 0, len(cands))
	for _, c := range cands {
		s := m.W1*c.UVS + m.W2*c.DBI - ModerationCost(m.Lambda1, c.PProp)
		out = append(out, Ranked{ID: c.ID, Score: s, PProp: c.PProp})
	}
	sort.SliceStable(out, func(i, j int) bool { return out[i].Score > out[j].Score })
	return out
}

// RankBounded ranks candidates while enforcing the demographic-parity bias
// budget |SAI_t| ≤ BiasMax per-genome §A2: any candidate whose selection-
// advantage index exceeds the budget is hard-gated out before scoring.
func (m *MOREConfig) RankBounded(cands []Candidate) []Ranked {
	var filtered []Candidate
	for _, c := range cands {
		if math.Abs(c.SAI) > m.BiasMax {
			continue
		}
		filtered = append(filtered, c)
	}
	return m.Rank(filtered)
}

// ─── A6 · DeGroot-BRS Convergence (expertise-weighted opinions) ───

type DeGrootAgent struct {
	Belief   float64
	Expertise float64 // e.g. BRS score
}

// DeGroot iterates b_i(t) = (1−a)·b_i(t−1) + a·Σ_j W_ij·b_j(t−1) with softmax
// expertise weights, until ‖Δ‖∞ < tol or maxIter. W is row-stochastic.
func DeGroot(agents []DeGrootAgent, a, tol float64, maxIter int) []float64 {
	n := len(agents)
	if n == 0 {
		return nil
	}
	beliefs := make([]float64, n)
	exps := make([]float64, n)
	for i := range agents {
		beliefs[i] = clamp(agents[i].Belief, 0, 1)
		exps[i] = math.Pow(math.Max(0, agents[i].Expertise), 2)
	}
	if a <= 0 || a > 1 {
		a = 0.1
	}
	if tol <= 0 {
		tol = 1e-4
	}
	if maxIter <= 0 {
		maxIter = 1000
	}
	for it := 0; it < maxIter; it++ {
		next := make([]float64, n)
		var maxDelta float64
		for i := 0; i < n; i++ {
			var nb, sw float64
			for j := 0; j < n; j++ {
				if j == i {
					continue
				}
				nb += exps[j] * beliefs[j]
				sw += exps[j]
			}
			var w float64
			if sw > 0 {
				w = a * (nb / sw)
			}
			next[i] = (1-a)*beliefs[i] + w
			if d := math.Abs(next[i] - beliefs[i]); d > maxDelta {
				maxDelta = d
			}
		}
		beliefs = next
		if maxDelta < tol {
			break
		}
	}
	return beliefs
}

// ─── A7 · E(t) Golden-Ratio Scheduler ───

// Et computes E(t) = H·Ψ·Y(S) + 0.10, clamped to [0.70, 1.60].
func Et(harmonicity, psi, y float64) float64 {
	return clamp(0.10+harmonicity*psi*y, 0.70, 1.60)
}

// DayPartFatigue returns 1.0 normally and tapers toward 0.4 across the classic
// afternoon fatigue trapezoid (13:30-15:00), per-genome A7 gate.
func DayPartFatigue(t time.Time) float64 {
	start := time.Date(t.Year(), t.Month(), t.Day(), 13, 30, 0, 0, t.Location())
	end := start.Add(90 * time.Minute)
	if t.Before(start) || t.After(end) {
		return 1.0
	}
	fade := t.Sub(start).Minutes() / 90
	// 0 → 1.0 ; 45min → 0.4 floor ; 90min → 1.0
	if fade <= 0.5 {
		return 1.0 - 1.2*fade
	}
	return 0.4 + 1.2*(fade-0.5)
}

// ─── helpers ───

func sigmoid(x float64) float64 { return 1 / (1 + math.Exp(-x)) }

func clamp(v, lo, hi float64) float64 {
	if v < lo {
		return lo
	}
	if v > hi {
		return hi
	}
	return v
}