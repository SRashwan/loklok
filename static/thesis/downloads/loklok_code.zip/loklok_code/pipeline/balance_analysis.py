"""Balanced multi-source analysis for the LOKLOK v8 thesis.

Parts:
  1. 52-row primary vs 60-row all-questionnaire sensitivity (descriptive + simulator).
  2. Held-out predictive comparison: context / psychometrics / semantic features.
  3. Structured qualitative coding of FGD, self-report, and PO streams.
  4. Content-supply calibration from the Uber-review corpus.
  5. Representativeness audit of the measured anchors and persona overlay.

This is a model-internal and data-based balance analysis, not a human trial.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "02_code" / "pipeline"))

import loklok_pipeline_v8 as v8  # noqa: E402
import loklok_pipeline as v7  # noqa: E402

SEED = 20261105
N_PERSONAS = 500
N_SESSIONS = 18
OUT = ROOT / "03_data" / "model_outputs"


def paired(d: np.ndarray) -> dict:
    d = np.asarray(d, dtype=float)
    se = float(np.std(d, ddof=1) / np.sqrt(len(d)))
    return {
        "mean": float(np.mean(d)),
        "sd": float(np.std(d, ddof=1)),
        "ci_low": float(np.mean(d) - 1.96 * se),
        "ci_high": float(np.mean(d) + 1.96 * se),
    }


def load_core():
    measured = v8.load_raw_measured(ROOT / "03_data" / "raw")
    docs, _ = v8.build_text_documents(ROOT / "03_data" / "raw", ROOT / "03_data" / "qualitative")
    emb = np.load(
        ROOT / "03_data" / "model_outputs" / "embeddings" / "embeddings_0f6c66e54fb6ca2c.npy"
    )
    return measured, docs, emb


def run_sim(measured, docs, emb, labels):
    text = v8.build_llm_features(measured, docs, emb)
    quant = v8.build_quant_block(measured)
    X = np.hstack([quant["X_quant"], text["X_text"]])
    debiased = v7.dml_ipw_debias(
        X, quant["B_nuisance"], quant["high_interaction"], B_names=quant["B_names"]
    )
    manifold = v7.spectral_manifold(debiased["Z_clean"], n_components=6)
    res = v7.run_factorial_experiment(
        manifold["Theta"],
        n_personas=N_PERSONAS,
        n_sessions=N_SESSIONS,
        seed=SEED,
        university_labels=labels,
        state_mediated_outcomes=True,
    )
    return v7.factorial_analysis(res), res


def part1_60(measured, docs, emb):
    print("[1] 52 vs 60 questionnaires ...", flush=True)
    m52 = measured
    m60 = dict(measured)
    m60["df"] = measured["df60"]
    m60["n"] = len(measured["df60"])
    s52 = v7.measured_wave_stats(m52)
    s60 = v7.measured_wave_stats(m60)
    fa52, _ = run_sim(m52, docs, emb, m52["df"]["university"].to_numpy())
    fa60, _ = run_sim(m60, docs, emb, m60["df"]["university"].to_numpy())
    out = {
        "n52": 52,
        "n60": 60,
        "measured52": {
            "PB": s52["PB"],
            "BRS": s52["BRS"],
            "correlations": s52["correlations"],
        },
        "measured60": {
            "PB": s60["PB"],
            "BRS": s60["BRS"],
            "correlations": s60["correlations"],
        },
        "sim52": {"delta_sr_eval": fa52["delta_sr_eval"], "delta_sr_comp": fa52["delta_sr_comp"], "delta_engagement": fa52["delta_engagement"]},
        "sim60": {"delta_sr_eval": fa60["delta_sr_eval"], "delta_sr_comp": fa60["delta_sr_comp"], "delta_engagement": fa60["delta_engagement"]},
        "note": "60-row version keeps the 8 duplicate-vector records; it is a sensitivity analysis, not the primary sample.",
    }
    (OUT / "balance_60_vs_52.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
    return out


def part2_predictive(measured, docs, emb):
    print("[2] held-out predictive comparison ...", flush=True)
    from sklearn.linear_model import RidgeCV
    from sklearn.model_selection import RepeatedKFold
    from sklearn.pipeline import make_pipeline
    from sklearn.preprocessing import StandardScaler
    from sklearn.metrics import r2_score, mean_squared_error

    df = measured["df"]
    quant = v8.build_quant_block(measured)
    text = v8.build_llm_features(measured, docs, emb)["X_text"]
    context = np.column_stack(
        [
            df["age"].to_numpy(float),
            (df["gender"].astype(str).str.upper() == "M").to_numpy(float),
            pd.get_dummies(df["academic_year"].astype(int), drop_first=True).to_numpy(float),
            pd.get_dummies(df["faculty_group"], drop_first=True).to_numpy(float),
            pd.get_dummies(df["university"], drop_first=True).to_numpy(float),
            df["ride_duration_minutes"].to_numpy(float),
            df["interaction_ordinal"].to_numpy(float),
        ]
    )
    psych = df[["BR_mean", "SV_mean", "IQ_mean"]].to_numpy(float)
    designs = {
        "context": context,
        "psych": psych,
        "context+psych": np.hstack([context, psych]),
        "context+psych+semantic": np.hstack([context, psych, text]),
        "semantic_only": text,
    }
    targets = {"PB_mean": df["PB_mean"].to_numpy(float), "star_rating": df["star_rating"].to_numpy(float)}
    rkf = RepeatedKFold(n_splits=5, n_repeats=20, random_state=SEED)
    rows = []
    for tname, y in targets.items():
        for dname, X in designs.items():
            r2s, rmses = [], []
            for tr, te in rkf.split(X):
                model = make_pipeline(
                    StandardScaler(),
                    RidgeCV(alphas=np.logspace(-2, 4, 25)),
                )
                model.fit(X[tr], y[tr])
                pred = model.predict(X[te])
                r2s.append(r2_score(y[te], pred))
                rmses.append(float(np.sqrt(mean_squared_error(y[te], pred))))
            rows.append(
                {
                    "target": tname,
                    "design": dname,
                    "r2_mean": float(np.mean(r2s)),
                    "r2_sd": float(np.std(r2s, ddof=1)),
                    "rmse_mean": float(np.mean(rmses)),
                    "rmse_sd": float(np.std(rmses, ddof=1)),
                }
            )
    pd.DataFrame(rows).to_csv(OUT / "balance_predictive.csv", index=False)
    (OUT / "balance_predictive.json").write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8")
    return rows


def part3_qualitative():
    print("[3] qualitative coding ...", flush=True)
    fgd = pd.read_csv(ROOT / "03_data" / "raw" / "FGD_transcription.csv")
    fgd_text = " ".join(str(x) for x in fgd["text"].fillna(""))
    self_text = (ROOT / "03_data" / "qualitative" / "selfreport" / "selfreport_transcript.txt").read_text(encoding="utf-8", errors="replace")
    po_text = (ROOT / "03_data" / "qualitative" / "po_profiles_pseudonymized.txt").read_text(encoding="utf-8", errors="replace")
    lex = {
        "publication": ["نشر", "تقديم", "تسجيل", "ميكروفون", "بودكاست", "إنتاج"],
        "cohosting": ["استضافة", "مشاركة", "تعاون", "ثنائي", "ضيف"],
        "access": ["وصول", "جامعة", "مؤسسة", "تصريح", "انضمام", "عضوية"],
        "interface": ["واجهة", "تطبيق", "زر", "شاشة", "تصميم", "إشعار"],
        "trust": ["ثقة", "مصداقية", "مصدر", "مصادر", "تحقق"],
        "misinfo": ["تضليل", "شائعة", "خطأ", "تصحيح", "معلومات مضللة"],
        "diversity": ["تنوع", "اختلاف", "رأي", "آراء", "فلاتر"],
        "attention": ["انتباه", "تركيز", "تفاعل", "استماع", "تشتت"],
    }
    out = {"fgd": {}, "selfreport": {}, "po": {}}
    for name, txt in [("fgd", fgd_text), ("selfreport", self_text), ("po", po_text)]:
        for domain, words in lex.items():
            count = sum(1 for w in words if w and w in txt)
            hits = sum(txt.count(w) for w in words if w)
            out[name][domain] = {"keywords_present": count, "total_hits": hits}
    out["note"] = "Keyword incidence is a structured design/face-validity audit, not a measured outcome or a substitute for human coding."
    (OUT / "balance_qualitative.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
    return out


def part4_content(measured, docs, emb):
    print("[4] content-supply calibration ...", flush=True)
    reviews = ROOT / "03_data" / "qualitative" / "corpora" / "uber-reviews-hf" / "reviews.ndjson"
    labels = []
    with open(reviews, "r", encoding="utf-8", errors="replace") as fh:
        for line in fh:
            try:
                row = json.loads(line)
                lab = float(row.get("label", row.get("score", np.nan)))
                if np.isfinite(lab):
                    labels.append(lab)
            except Exception:
                continue
    labels = np.asarray(labels, float)
    labels = labels[np.isfinite(labels)]
    p_prop = np.clip(1.0 - (labels - 1.0) / 4.0, 0.10, 0.90)
    rng = np.random.default_rng(SEED + 404)
    empirical16 = rng.choice(p_prop, size=16, replace=True)
    m52 = measured
    fa_base, res_base = run_sim(m52, docs, emb, m52["df"]["university"].to_numpy())
    text = v8.build_llm_features(m52, docs, emb)
    quant = v8.build_quant_block(m52)
    X = np.hstack([quant["X_quant"], text["X_text"]])
    debiased = v7.dml_ipw_debias(X, quant["B_nuisance"], quant["high_interaction"], B_names=quant["B_names"])
    manifold = v7.spectral_manifold(debiased["Z_clean"], n_components=6)
    res = v7.run_factorial_experiment(
        manifold["Theta"],
        n_personas=N_PERSONAS,
        n_sessions=N_SESSIONS,
        seed=SEED,
        university_labels=m52["df"]["university"].to_numpy(),
        state_mediated_outcomes=True,
        cand_p_prop_override=empirical16,
    )
    fa_emp = v7.factorial_analysis(res)
    d = res["sr_eval"][:, 7] - res["sr_eval"][:, 0]
    d_base = res_base["sr_eval"][:, 7] - res_base["sr_eval"][:, 0]
    out = {
        "n_reviews": int(len(labels)),
        "star_mean": float(np.mean(labels)),
        "p_prop_mean": float(np.mean(p_prop)),
        "baseline_delta_sr": fa_base["delta_sr_eval"],
        "empirical_delta_sr": fa_emp["delta_sr_eval"],
        "paired_difference": paired(d - d_base),
        "note": "Uber-review star labels are a content-quality proxy, not radio propaganda; this is a stress test of content-supply calibration.",
    }
    (OUT / "balance_content.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
    return out


def part5_representativeness(measured):
    print("[5] representativeness audit ...", flush=True)
    df = measured["df"]
    out = {
        "measured": {
            "n": int(len(df)),
            "age_mean": float(df["age"].mean()),
            "age_min": float(df["age"].min()),
            "age_max": float(df["age"].max()),
            "gender": df["gender"].value_counts().to_dict(),
            "year": df["academic_year"].value_counts().to_dict(),
            "faculty": df["faculty"].value_counts().to_dict(),
            "university": df["university"].value_counts().to_dict(),
        },
        "note": "Convenience sample of university Uber riders in October 6th City; no external population benchmark is included, so representativeness is not claimed.",
    }
    (OUT / "balance_representativeness.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
    return out


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    measured, docs, emb = load_core()
    p1 = part1_60(measured, docs, emb)
    p2 = part2_predictive(measured, docs, emb)
    p3 = part3_qualitative()
    p4 = part4_content(measured, docs, emb)
    p5 = part5_representativeness(measured)
    print("\n=== 52 vs 60 ===")
    print("52 dSR", round(p1["sim52"]["delta_sr_eval"]["mean"], 3))
    print("60 dSR", round(p1["sim60"]["delta_sr_eval"]["mean"], 3))
    print("\n=== predictive (R2) ===")
    for row in p2:
        if row["target"] == "PB_mean":
            print(row["design"], round(row["r2_mean"], 3))
    print("\n=== content ===")
    print("baseline", round(p4["baseline_delta_sr"]["mean"], 3), "empirical", round(p4["empirical_delta_sr"]["mean"], 3), "paired", round(p4["paired_difference"]["mean"], 3), [round(p4["paired_difference"]["ci_low"], 3), round(p4["paired_difference"]["ci_high"], 3)])
    print("\nSaved balance outputs in", OUT, flush=True)


if __name__ == "__main__":
    main()
