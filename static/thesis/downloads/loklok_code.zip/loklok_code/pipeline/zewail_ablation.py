"""Zewail pump-probe gate ablation on the main state-mediated simulator.

Modes:
  zewail            full pump-probe gate (default)
  off               gate = 1 (no attention modulation)
  simple_decay      exp(-dt/tau) only, no distraction/phase terms
  zewail_tau_0.5    full gate with half the dephasing time
  zewail_tau_2.0    full gate with double the dephasing time

The same personas and seed are used across modes, so differences are paired
within persona.  This is still a model-internal ablation, not a human test.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "02_code" / "pipeline"))

import loklok_pipeline_v8 as v8  # noqa: E402
import loklok_pipeline as v7  # noqa: E402

SEED = 20261105
N_PERSONAS = 500
N_SESSIONS = 18

MODES = [
    ("zewail", "zewail", 1.0),
    ("off", "off", 1.0),
    ("simple_decay", "simple_decay", 1.0),
    ("zewail_tau_0.5", "zewail", 0.5),
    ("zewail_tau_2.0", "zewail", 2.0),
]


def paired(d: np.ndarray) -> dict:
    d = np.asarray(d, dtype=float)
    se = float(np.std(d, ddof=1) / np.sqrt(len(d)))
    return {
        "mean": float(np.mean(d)),
        "sd": float(np.std(d, ddof=1)),
        "ci_low": float(np.mean(d) - 1.96 * se),
        "ci_high": float(np.mean(d) + 1.96 * se),
    }


def main() -> None:
    measured = v8.load_raw_measured(ROOT / "03_data" / "raw")
    docs, _ = v8.build_text_documents(ROOT / "03_data" / "raw", ROOT / "03_data" / "qualitative")
    emb = np.load(
        ROOT
        / "03_data"
        / "model_outputs"
        / "embeddings"
        / "embeddings_0f6c66e54fb6ca2c.npy"
    )
    text_feat = v8.build_llm_features(measured, docs, emb)
    quant = v8.build_quant_block(measured)
    X = np.hstack([quant["X_quant"], text_feat["X_text"]])
    debiased = v7.dml_ipw_debias(
        X,
        quant["B_nuisance"],
        quant["high_interaction"],
        B_names=quant["B_names"],
    )
    manifold = v7.spectral_manifold(debiased["Z_clean"], n_components=6)
    theta = manifold["Theta"]
    labels = measured["df"]["university"].to_numpy()

    results = {}
    per_persona = {}
    for label, mode, tau_scale in MODES:
        print(f"[{label}] running ...", flush=True)
        res = v7.run_factorial_experiment(
            theta,
            n_personas=N_PERSONAS,
            n_sessions=N_SESSIONS,
            seed=SEED,
            university_labels=labels,
            state_mediated_outcomes=True,
            gate_mode=mode,
            gate_tau_scale=tau_scale,
        )
        fa = v7.factorial_analysis(res)
        gate = res["tensor"][:, :, 6, :].mean()
        dn = res["sr_eval"][:, 7] - res["sr_eval"][:, 0]
        per_persona[label] = dn
        results[label] = {
            "mode": mode,
            "tau_scale": tau_scale,
            "gate_mean": float(gate),
            "sr_g0": float(fa["sr_eval_g0"]),
            "sr_g1": float(fa["sr_eval_g1"]),
            "delta_sr_eval": fa["delta_sr_eval"],
            "delta_sr_comp": fa["delta_sr_comp"],
            "delta_engagement": fa["delta_engagement"],
            "echo_g0": float(fa["echo_g0"]),
            "echo_g1": float(fa["echo_g1"]),
            "brs_g0": float(fa["brs_g0"]),
            "brs_g1": float(fa["brs_g1"]),
        }
        print(
            f"  gate={gate:.3f}  dSR={fa['delta_sr_eval']['mean']:+.3f} "
            f"dComp={fa['delta_sr_comp']['mean']:+.3f} "
            f"dEng={fa['delta_engagement']['mean']:+.3f}",
            flush=True,
        )

    reference = per_persona["zewail"]
    comparisons = {}
    for label, arr in per_persona.items():
        if label == "zewail":
            continue
        comparisons[label] = paired(arr - reference)

    out = {
        "seed": SEED,
        "n_personas": N_PERSONAS,
        "n_sessions": N_SESSIONS,
        "modes": results,
        "paired_difference_vs_zewail": comparisons,
        "note": "Model-internal gate ablation; not a human attention experiment.",
    }
    out_dir = ROOT / "03_data" / "model_outputs"
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "zewail_ablation.json").write_text(
        json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    pd.DataFrame(
        [
            {
                "mode": label,
                "gate_mean": v["gate_mean"],
                "delta_sr_eval": v["delta_sr_eval"]["mean"],
                "delta_sr_comp": v["delta_sr_comp"]["mean"],
                "delta_engagement": v["delta_engagement"]["mean"],
                "sr_g0": v["sr_g0"],
                "sr_g1": v["sr_g1"],
                "echo_g0": v["echo_g0"],
                "echo_g1": v["echo_g1"],
            }
            for label, v in results.items()
        ]
    ).to_csv(out_dir / "zewail_ablation.csv", index=False)
    print("\nSaved:", out_dir / "zewail_ablation.json", flush=True)


if __name__ == "__main__":
    main()
