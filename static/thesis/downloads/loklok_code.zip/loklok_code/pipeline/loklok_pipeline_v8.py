"""
LOKLOK Thesis Pipeline v8.0 — original-data, LLM-embedding, Colab-GPU edition
=============================================================================

Rebuilds the calibrated in-silico experiment from the original raw sources:

  * `03_data/raw/survey_answers_real.csv`  (60 raw questionnaires)
  * `03_data/raw/realsurveydata_inclusive.csv` (60 ride-context/PO narratives)
  * `03_data/raw/FGD_transcription.csv` (original FGD transcript, 160 segments)
  * `03_data/raw/selfreport.mp3` (researcher self-report audio; transcribed on
    Colab GPU into `03_data/qualitative/selfreport/selfreport_transcript.json`)
  * `03_data/qualitative/corpora/` (Uber reviews, student social-media and
    student-lifestyle corpora, Reuters DNR manifest)
  * `03_data/raw/topics_25_arabic.txt` (25 programme briefs)

The quantitative ABM, GRM-IRT measurement model, Bayesian inference, adversarial
tests, Sobol/LHS sweep, topology/persona robustness, and LaTeX exports are the
same functions used by the v7 pipeline.  The new parts are:

  1. Raw-data screening: the historical 21-field duplicate key is reconstructed
     from the raw 60 rows, yielding N=52 and the same eight removed IDs.
  2. Multilingual LLM embeddings (`sentence-transformers`) for PO, FGD,
     researcher self-report, corpora, and stimulus briefs.
  3. PCA-compressed semantic features + DML/IPW + spectral manifold.
  4. GPU matvec path for the 500x500 ABM operations when CUDA is present.
  5. Outputs written to the same `03_data/model_outputs`,
     `01_thesis/src/generated`, and `04_figures` paths used by the final thesis.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import re
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import loklok_pipeline as v7  # shared ABM / inference / export functions


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

DUPLICATE_KEY_21 = [
    "ride_duration_minutes",
    "age",
    "SV4",
    "traffic_conditions",
    "context",
    "BR3",
    "star_rating",
    "interaction_level",
    "BR4",
    "SV2",
    "IQ3",
    "PB5",
    "BR2",
    "BR1",
    "SV1",
    "PB1",
    "academic_year",
    "PB4",
    "SV3",
    "IQ1",
    "PB2",
]

INTERACTION_MAP = {"Minimal": 0, "Low": 1, "Moderate": 2, "High": 3}

FACULTY_GROUPS = {
    "Commerce": "Business & Economics",
    "Mass Comm": "Humanities & Media",
    "Mass Communication": "Humanities & Media",
    "Pharmacy": "Health Sciences",
    "Applied Arts": "Arts & Design",
    "Engineering": "Engineering & Technology",
    "Computer Science": "Engineering & Technology",
    "Business": "Business & Economics",
    "Economics": "Business & Economics",
    "Medicine": "Health Sciences",
    "Dentistry": "Health Sciences",
    "Law": "Humanities & Media",
    "Arts": "Arts & Design",
}


# ---------------------------------------------------------------------------
# Raw data
# ---------------------------------------------------------------------------


def _normalise_context(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    if "listening_context" in df.columns and "context" not in df.columns:
        df["context"] = df["listening_context"]
    if "context" in df.columns:
        df["context"] = df["context"].astype(str).str.upper()
    if "interaction_level" in df.columns:
        df["interaction_ordinal"] = (
            df["interaction_level"].astype(str).str.strip().map(INTERACTION_MAP).fillna(1).astype(int)
        )
    if "faculty" in df.columns:
        df["faculty_group"] = df["faculty"].astype(str).map(FACULTY_GROUPS).fillna("Other")
    return df


def load_raw_measured(raw_dir: Path) -> Dict[str, object]:
    survey = pd.read_csv(raw_dir / "survey_answers_real.csv")
    rides = pd.read_csv(raw_dir / "realsurveydata_inclusive.csv")
    keep = [
        "student_id",
        "ride_duration_minutes",
        "traffic_conditions",
        "student_mood",
        "interaction_level",
        "key_observations",
        "notable_quotes",
        "researcher_reflections",
    ]
    rides = rides[[c for c in keep if c in rides.columns]].copy()
    df = survey.merge(rides, on="student_id", how="left", validate="one_to_one")
    df = _normalise_context(df)

    br_cols = ["BR1", "BR2", "BR3", "BR4"]
    sv_cols = ["SV1", "SV2", "SV3", "SV4"]
    iq_cols = ["IQ1", "IQ2", "IQ3"]
    pb_cols = ["PB1", "PB2", "PB3", "PB4", "PB5"]
    for c in br_cols + sv_cols + iq_cols + pb_cols + ["star_rating"]:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    df["BR4r"] = 4.0 - df["BR4"]
    df["BR_mean"] = df[["BR1", "BR2", "BR3", "BR4r"]].mean(axis=1)
    df["SV_mean"] = df[sv_cols].mean(axis=1)
    df["IQ_mean"] = df[iq_cols].mean(axis=1)
    df["PB_mean"] = df[pb_cols].mean(axis=1)
    df["pb_experience_mean"] = df["PB_mean"]
    df["BRS_total"] = df[
        ["BR1", "BR2", "BR3", "BR4r", *sv_cols, *iq_cols]
    ].sum(axis=1)
    df["ride_duration_minutes"] = pd.to_numeric(df["ride_duration_minutes"], errors="coerce")
    df["age"] = pd.to_numeric(df["age"], errors="coerce")
    df["interaction_ordinal"] = pd.to_numeric(df["interaction_ordinal"], errors="coerce")

    # Reconstruct the historical 21-field duplicate screen from the raw rows.
    dup_mask = df.duplicated(subset=DUPLICATE_KEY_21, keep="first")
    removed_ids = sorted(df.loc[dup_mask, "student_id"].astype(str).tolist())
    primary = df.loc[~dup_mask].reset_index(drop=True)

    items = {
        "BR": ["BR1", "BR2", "BR3", "BR4r"],
        "SV": sv_cols,
        "IQ": iq_cols,
        "PB": pb_cols,
        "BRS": ["BR1", "BR2", "BR3", "BR4r", *sv_cols, *iq_cols],
    }
    measured = {
        "n": int(len(primary)),
        "n_collected": int(len(df)),
        "df": primary,
        "df60": df,
        "items": items,
        "duplicate_key": DUPLICATE_KEY_21,
        "removed_ids": removed_ids,
        "pb_mean": float(primary["PB_mean"].mean()),
        "pb_sd": float(primary["PB_mean"].std(ddof=1)),
        "star_mean": float(primary["star_rating"].mean()),
        "duration_mean": float(primary["ride_duration_minutes"].mean()),
        "duration_min": float(primary["ride_duration_minutes"].min()),
        "duration_max": float(primary["ride_duration_minutes"].max()),
        "interaction_counts": primary["interaction_level"].value_counts().to_dict(),
        "university_counts": primary["university"].value_counts().to_dict(),
    }
    return measured


# ---------------------------------------------------------------------------
# Text sources
# ---------------------------------------------------------------------------

_WHITELIST = {
    "Uber",
    "LOKLOK",
    "Cairo",
    "Egypt",
    "Giza",
    "October",
    "University",
    "Universities",
    "Higher",
    "Institutes",
    "Institute",
    "Commerce",
    "Mass",
    "Comm",
    "Pharmacy",
    "Applied",
    "Arts",
    "Engineering",
    "Computer",
    "Science",
    "MUST",
    "MTI",
    "O6U",
    "CU",
    "Sadat",
    "Academy",
    "Radio",
    "TV",
    "Media",
    "Students",
    "Student",
    "English",
    "Arabic",
    "Nile",
    "Egyptian",
    "Muslim",
    "Christian",
    "Ramadan",
    "TikTok",
    "Facebook",
    "Instagram",
    "WhatsApp",
    "YouTube",
    "Twitter",
    "Spotify",
    "Apple",
    "Google",
    "Android",
    "iPhone",
}


def _redact_text(text: str, known_names: Sequence[str]) -> str:
    text = str(text or "")
    for name in sorted(set(known_names), key=len, reverse=True):
        if name and len(name) > 2:
            text = re.sub(rf"\b{re.escape(name)}\b", "the participant", text)
    # Replace remaining capitalised given names while keeping entities/places.
    def repl(m):
        w = m.group(0)
        if w in _WHITELIST:
            return w
        return "the participant"

    text = re.sub(r"\b[A-Z][a-z]{2,}\b", repl, text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def _extract_profile_names(path: Path) -> List[str]:
    if not path.exists():
        return []
    text = path.read_text(encoding="utf-8", errors="replace")
    names = []
    for m in re.finditer(r"\*\*SR\d{3,4}\s*[-\u2013\u2014]\s*([^*]+?)\*\*", text):
        name = m.group(1).strip()
        if name and name.lower() not in {"participant", "student"}:
            names.append(name)
            names.extend(name.split())
    return sorted(set(names), key=len, reverse=True)


def _read_selfreport(selfreport_dir: Path) -> List[Dict[str, object]]:
    """Read the cached self-report transcript produced by the Colab ASR step."""
    json_path = selfreport_dir / "selfreport_transcript.json"
    txt_path = selfreport_dir / "selfreport_transcript.txt"
    docs: List[Dict[str, object]] = []
    if json_path.exists():
        try:
            rows = json.loads(json_path.read_text(encoding="utf-8"))
            for i, row in enumerate(rows):
                text = str(row.get("text", "")).strip()
                if text:
                    docs.append(
                        {
                            "doc_id": f"selfreport-{i:04d}",
                            "source": "selfreport",
                            "text": text,
                            "start": row.get("start"),
                            "end": row.get("end"),
                        }
                    )
            if docs:
                return docs
        except Exception:
            pass
    if txt_path.exists():
        text = txt_path.read_text(encoding="utf-8", errors="replace")
        words = text.split()
        for i in range(0, len(words), 180):
            chunk = " ".join(words[i : i + 180]).strip()
            if chunk:
                docs.append(
                    {
                        "doc_id": f"selfreport-{i//180:04d}",
                        "source": "selfreport",
                        "text": chunk,
                    }
                )
    return docs


def build_text_documents(raw_dir: Path, qualitative_dir: Path) -> Tuple[List[Dict[str, object]], Dict[str, object]]:
    """Collect the qualitative documents used for LLM embeddings."""
    known_names = _extract_profile_names(raw_dir / "RealStudentsProfiles.txt")
    docs: List[Dict[str, object]] = []

    # 1. Participant observation: one document per retained/raw respondent.
    rides = pd.read_csv(raw_dir / "realsurveydata_inclusive.csv")
    for _, row in rides.iterrows():
        text = " ".join(
            str(row.get(c, "") or "")
            for c in ["key_observations", "notable_quotes", "researcher_reflections"]
        )
        docs.append(
            {
                "doc_id": f"po-{row['student_id']}",
                "source": "po",
                "respondent_id": str(row["student_id"]),
                "text": _redact_text(text, known_names),
            }
        )

    # 2. Original FGD transcript.
    fgd_path = raw_dir / "FGD_transcription.csv"
    n_fgd = 0
    if fgd_path.exists():
        fgd = pd.read_csv(fgd_path)
        for i, row in fgd.iterrows():
            text = str(row.get("text", "") or "").strip()
            if text:
                docs.append(
                    {
                        "doc_id": f"fgd-{i:04d}",
                        "source": "fgd",
                        "segment_id": int(row.get("segment_id", i)),
                        "text": text,
                    }
                )
                n_fgd += 1

    # 3. Researcher self-report (transcribed on Colab GPU).
    self_docs = _read_selfreport(qualitative_dir / "selfreport")
    docs.extend(self_docs)

    # 4. Existing corpora.
    n_corpus = 0
    corpora = qualitative_dir / "corpora"
    uber_path = corpora / "uber-reviews-hf" / "reviews.ndjson"
    if uber_path.exists():
        with open(uber_path, "r", encoding="utf-8", errors="replace") as fh:
            for i, line in enumerate(fh):
                if not line.strip():
                    continue
                try:
                    obj = json.loads(line)
                except Exception:
                    continue
                text = str(obj.get("text") or obj.get("review") or obj.get("content") or "").strip()
                if text:
                    docs.append({"doc_id": f"corpus-uber-{i:05d}", "source": "corpus_uber", "text": text})
                    n_corpus += 1

    social_path = corpora / "student-social-media-hf" / "payload.bin"
    if social_path.exists():
        try:
            rows = json.loads(social_path.read_text(encoding="utf-8"))
            for i, obj in enumerate(rows):
                row = obj.get("row", obj)
                fields = [
                    row.get("Age"),
                    row.get("Gender"),
                    row.get("Occupation"),
                    row.get("Social Media Use"),
                    row.get("Platforms"),
                    row.get("Daily Time"),
                ]
                qs = [str(v) for k, v in row.items() if str(k).strip()[:2] in {str(j) for j in range(9, 21)}]
                text = " ".join(str(x) for x in fields + qs if x not in (None, ""))
                if text.strip():
                    docs.append({"doc_id": f"corpus-social-{i:05d}", "source": "corpus_social", "text": text})
                    n_corpus += 1
        except Exception:
            pass

    lifestyle_path = corpora / "student-lifestyle-github" / "payload.bin"
    if lifestyle_path.exists():
        try:
            lf = pd.read_csv(lifestyle_path)
            for i, row in lf.iterrows():
                text = (
                    f"Student profile: study {row.get('Study_Hours_Per_Day')} hours, "
                    f"extracurricular {row.get('Extracurricular_Hours_Per_Day')} hours, "
                    f"sleep {row.get('Sleep_Hours_Per_Day')} hours, "
                    f"social {row.get('Social_Hours_Per_Day')} hours, "
                    f"physical activity {row.get('Physical_Activity_Hours_Per_Day')} hours, "
                    f"GPA {row.get('GPA')}, stress {row.get('Stress_Level')}."
                )
                docs.append({"doc_id": f"corpus-life-{i:05d}", "source": "corpus_lifestyle", "text": text})
                n_corpus += 1
        except Exception:
            pass

    # 5. 25 programme briefs (stimulus corpus).
    topics_path = raw_dir / "topics_25_arabic.txt"
    n_topics = 0
    if topics_path.exists():
        raw = topics_path.read_text(encoding="utf-8", errors="replace")
        blocks = [b.strip() for b in re.split(r"\n\s*-\s*", raw) if b.strip()]
        if len(blocks) < 5:
            blocks = [b.strip() for b in raw.split("\n\n") if b.strip()]
        for i, text in enumerate(blocks[:25]):
            docs.append({"doc_id": f"topic-{i:02d}", "source": "stimulus", "text": text})
            n_topics += 1

    summary = {
        "documents": len(docs),
        "po": sum(1 for d in docs if d["source"] == "po"),
        "fgd": n_fgd,
        "selfreport": len(self_docs),
        "corpora": n_corpus,
        "stimuli": n_topics,
        "profile_names_redacted": len(known_names),
    }
    return docs, summary


# ---------------------------------------------------------------------------
# LLM embeddings
# ---------------------------------------------------------------------------


def _embedding_cache_path(cache_dir: Path, model_name: str, docs: List[Dict[str, object]]) -> Path:
    h = hashlib.sha256()
    h.update(model_name.encode("utf-8"))
    for d in docs:
        h.update(str(d["doc_id"]).encode("utf-8"))
        h.update(str(d["text"]).encode("utf-8"))
    return cache_dir / f"embeddings_{h.hexdigest()[:16]}.npy"


def embed_documents(
    docs: List[Dict[str, object]],
    cache_dir: Path,
    model_name: str = "BAAI/bge-m3",
    device: Optional[str] = None,
    batch_size: int = 64,
) -> np.ndarray:
    cache_dir.mkdir(parents=True, exist_ok=True)
    cache = _embedding_cache_path(cache_dir, model_name, docs)
    if cache.exists():
        print(f"[embeddings] loading cache {cache.name}")
        return np.load(cache)

    try:
        from sentence_transformers import SentenceTransformer
    except Exception as exc:  # pragma: no cover
        raise RuntimeError(
            "sentence-transformers is required for the LLM embedding step. "
            "Install it on Colab with: pip install sentence-transformers"
        ) from exc

    if device is None:
        try:
            import torch

            device = "cuda" if torch.cuda.is_available() else "cpu"
        except Exception:
            device = "cpu"
    print(f"[embeddings] loading {model_name} on {device} ...")
    model = SentenceTransformer(model_name, device=device)
    texts = [str(d["text"]) for d in docs]
    emb = model.encode(
        texts,
        batch_size=batch_size,
        show_progress_bar=True,
        convert_to_numpy=True,
        normalize_embeddings=True,
    )
    np.save(cache, emb)
    return emb


# ---------------------------------------------------------------------------
# Features
# ---------------------------------------------------------------------------


def _cosine_matrix(A: np.ndarray, B: np.ndarray) -> np.ndarray:
    A = A / (np.linalg.norm(A, axis=1, keepdims=True) + 1e-12)
    B = B / (np.linalg.norm(B, axis=1, keepdims=True) + 1e-12)
    return A @ B.T


def build_llm_features(
    measured: Dict[str, object],
    docs: List[Dict[str, object]],
    emb: np.ndarray,
    n_components: int = 32,
    seed: int = 20261105,
) -> Dict[str, object]:
    """Compress LLM embeddings and build per-respondent semantic features."""
    from sklearn.decomposition import PCA
    from sklearn.cluster import KMeans

    if len(docs) != len(emb):
        raise ValueError("doc/embedding length mismatch")
    n_components = max(2, min(n_components, len(docs) - 1, emb.shape[1]))
    pca = PCA(n_components=n_components, random_state=seed)
    Z = pca.fit_transform(emb)
    Z = Z / (np.linalg.norm(Z, axis=1, keepdims=True) + 1e-12)

    sources = np.array([d["source"] for d in docs])
    po_mask = sources == "po"
    fgd_mask = sources == "fgd"
    self_mask = sources == "selfreport"
    corpus_mask = np.isin(sources, ["corpus_uber", "corpus_social", "corpus_lifestyle"])
    stimulus_mask = sources == "stimulus"

    fgd_Z = Z[fgd_mask]
    self_Z = Z[self_mask]
    corpus_Z = Z[corpus_mask]
    stim_Z = Z[stimulus_mask]

    corpus_centroids = None
    if len(corpus_Z) >= 8:
        k = min(8, max(2, len(corpus_Z) // 50))
        km = KMeans(n_clusters=k, random_state=seed, n_init=10)
        km.fit(corpus_Z)
        corpus_centroids = km.cluster_centers_

    rows = []
    df = measured["df"]
    for _, r in df.iterrows():
        sid = str(r["student_id"])
        po_rows = [i for i, d in enumerate(docs) if d["source"] == "po" and str(d.get("respondent_id")) == sid]
        if po_rows:
            po_vec = Z[po_rows].mean(axis=0)
        else:
            po_vec = np.zeros(n_components)
        po_vec = po_vec / (np.linalg.norm(po_vec) + 1e-12)

        def sim_features(mat: np.ndarray, prefix: str) -> List[float]:
            if len(mat) == 0:
                return [0.0, 0.0, 0.0]
            sims = _cosine_matrix(po_vec[None, :], mat)[0]
            top = np.sort(sims)[-3:]
            return [float(np.mean(sims)), float(np.max(sims)), float(np.mean(top))]

        fgd_mean = fgd_Z.mean(axis=0) if len(fgd_Z) else np.zeros(n_components)
        self_mean = self_Z.mean(axis=0) if len(self_Z) else np.zeros(n_components)
        corpus_mean = corpus_Z.mean(axis=0) if len(corpus_Z) else np.zeros(n_components)
        fgd_mean /= np.linalg.norm(fgd_mean) + 1e-12
        self_mean /= np.linalg.norm(self_mean) + 1e-12
        corpus_mean /= np.linalg.norm(corpus_mean) + 1e-12

        cluster_sims = (
            _cosine_matrix(po_vec[None, :], corpus_centroids)[0].tolist()
            if corpus_centroids is not None
            else [0.0] * 8
        )
        stim_sims = (
            _cosine_matrix(po_vec[None, :], stim_Z)[0].tolist() if len(stim_Z) else [0.0] * 25
        )
        stim_sims = (stim_sims + [0.0] * 25)[:25]

        rows.append(
            np.concatenate(
                [
                    po_vec,
                    fgd_mean,
                    np.array(sim_features(fgd_Z, "fgd")),
                    self_mean,
                    np.array(sim_features(self_Z, "self")),
                    corpus_mean,
                    np.array(cluster_sims),
                    np.array(stim_sims),
                ]
            )
        )
    X_text = np.vstack(rows)
    return {
        "X_text": X_text,
        "pca_explained": float(np.sum(pca.explained_variance_ratio_)),
        "embedding_dim": int(emb.shape[1]),
        "semantic_components": int(n_components),
        "n_docs": int(len(docs)),
    }


def build_quant_block(measured: Dict[str, object]) -> Dict[str, np.ndarray]:
    df = measured["df"]
    n = len(df)
    br = df[["BR1", "BR2", "BR3", "BR4r"]].to_numpy(float)
    sv = df[["SV1", "SV2", "SV3", "SV4"]].to_numpy(float)
    iq = df[["IQ1", "IQ2", "IQ3"]].to_numpy(float)
    pb = df[["PB1", "PB2", "PB3", "PB4", "PB5"]].to_numpy(float)
    star = df[["star_rating"]].to_numpy(float)
    duration = df[["ride_duration_minutes"]].to_numpy(float)
    interaction = df[["interaction_ordinal"]].to_numpy(float)
    age = df[["age"]].to_numpy(float)
    gender = (df["gender"].astype(str).str.upper() == "M").to_numpy(float).reshape(-1, 1)
    uni = pd.get_dummies(df["university"], drop_first=False).to_numpy(float)
    uni = uni[:, 1:] if uni.shape[1] > 1 else uni
    fac = pd.get_dummies(df["faculty_group"], drop_first=False).to_numpy(float)
    fac = fac[:, 1:] if fac.shape[1] > 1 else fac
    X = np.hstack([br, sv, iq, pb, star, duration, interaction, age, gender, uni, fac])
    X = np.nan_to_num(X, nan=np.nanmedian(X, axis=0))
    X = v7.zscore(X)
    person_mean = X.mean(axis=1, keepdims=True)
    person_sd = X.std(axis=1, keepdims=True)
    acquiescence = (br > 2).sum(axis=1).reshape(-1, 1) + (pb > 4).sum(axis=1).reshape(-1, 1)
    high_interaction = (interaction >= 3).astype(float)
    B = np.hstack(
        [
            np.ones((n, 1)),
            person_mean,
            person_sd,
            acquiescence,
            duration,
            interaction,
            high_interaction,
            age,
            gender,
        ]
    )
    B = np.nan_to_num(B, nan=0.0)
    B_names = [
        "Intercept",
        "Person mean",
        "Person SD",
        "Acquiescence",
        "Ride duration",
        "Interaction",
        "High interaction",
        "Age",
        "Gender",
    ]
    return {
        "X_quant": X,
        "B_nuisance": B,
        "B_names": B_names,
        "high_interaction": high_interaction.ravel(),
    }


# ---------------------------------------------------------------------------
# Orchestration
# ---------------------------------------------------------------------------


def topology_robustness_main(
    theta: np.ndarray,
    university_labels: np.ndarray,
    n_personas: int = 500,
    n_sessions: int = 18,
    seed: int = 20261105,
    calibration_shift: float = 0.0,
) -> Dict[str, object]:
    """Run the main factorial simulator under three graph generators."""
    out = {}
    for label, graph in [
        ("Erdos-Renyi", "ER"),
        ("Watts-Strogatz", "WS"),
        ("Barabasi-Albert", "BA"),
    ]:
        res = v7.run_factorial_experiment(
            theta,
            n_personas=n_personas,
            n_sessions=n_sessions,
            seed=seed,
            graph=graph,
            university_labels=university_labels,
            state_mediated_outcomes=True,
        )
        res["sr_eval"] = res["sr_eval"] + calibration_shift
        res["mcs_scores"] = res["mcs_scores"] + calibration_shift
        res["pb_scores"] = res["pb_scores"] + calibration_shift
        fa = v7.factorial_analysis(res)
        out[label] = {
            "delta_pb": float(fa["delta_sr_eval"]["mean"]),
            "delta_srcomp": float(fa["delta_sr_comp"]["mean"]),
            "pb_g0": float(fa["sr_eval_g0"]),
            "pb_g1": float(fa["sr_eval_g1"]),
            "engagement_delta": float(fa["delta_engagement"]["mean"]),
            "echo_g0": float(fa["echo_g0"]),
            "echo_g1": float(fa["echo_g1"]),
            "brs_g0": float(fa["brs_g0"]),
            "brs_g1": float(fa["brs_g1"]),
        }
    return out


def persona_robustness_main(
    theta: np.ndarray,
    university_labels: np.ndarray,
    n_personas: int = 500,
    n_sessions: int = 18,
    seed: int = 20261105,
) -> Dict[str, object]:
    """Persona-prior variants run on the main state-mediated simulator."""
    q0 = v7.fit_q0(theta, seed=seed)
    q0_broad = dict(q0)
    q0_broad["cov"] = q0["cov"] * 2.0
    q0_broad["kde"] = None
    q0_neutral = dict(q0)
    q0_neutral["cov"] = 0.05 * np.eye(theta.shape[1])
    q0_neutral["kde"] = None
    out = {}
    for name, q in [
        ("Preference_Grounded_Anchored", q0),
        ("Broad_Demographic_Category", q0_broad),
        ("Unanchored_Neutral_Baseline", q0_neutral),
    ]:
        res = v7.run_factorial_experiment(
            theta,
            n_personas=n_personas,
            n_sessions=n_sessions,
            seed=seed,
            university_labels=university_labels,
            state_mediated_outcomes=True,
            q0_override=q,
        )
        fa = v7.factorial_analysis(res)
        out[name] = float(fa["delta_sr_eval"]["mean"])
    return out


def coefficient_sensitivity_main(
    theta: np.ndarray,
    university_labels: np.ndarray,
    n_personas: int = 250,
    n_sessions: int = 12,
    n_draws: int = 16,
    seed: int = 20261105,
) -> Dict[str, object]:
    """Sweep the state-outcome credibility weights (the explicit coefficients)."""
    from scipy.stats import qmc

    base = {
        "cred_brs": 1.20,
        "cred_dbi": 0.55,
        "cred_echo": -0.45,
        "cred_q": 0.45,
        "cred_prop": -2.50,
    }
    bounds = {
        "cred_brs": (0.60, 1.80),
        "cred_dbi": (0.275, 0.825),
        "cred_echo": (-0.675, -0.225),
        "cred_q": (0.225, 0.675),
        "cred_prop": (-3.75, -1.25),
    }
    sampler = qmc.LatinHypercube(d=len(base), seed=seed)
    unit = sampler.random(n_draws)
    names = list(base)
    deltas = []
    rows = []
    for i in range(n_draws):
        weights = {}
        for j, name in enumerate(names):
            lo, hi = bounds[name]
            weights[name] = float(lo + unit[i, j] * (hi - lo))
        res = v7.run_factorial_experiment(
            theta,
            n_personas=n_personas,
            n_sessions=n_sessions,
            seed=seed + i,
            university_labels=university_labels,
            state_mediated_outcomes=True,
            outcome_weights=weights,
        )
        fa = v7.factorial_analysis(res)
        d = float(fa["delta_sr_eval"]["mean"])
        deltas.append(d)
        rows.append({"draw": i, "delta_sr_eval": d, **weights})
    deltas = np.asarray(deltas)
    return {
        "n_draws": int(n_draws),
        "n_personas": int(n_personas),
        "n_sessions": int(n_sessions),
        "delta_min": float(np.min(deltas)),
        "delta_max": float(np.max(deltas)),
        "delta_mean": float(np.mean(deltas)),
        "positive_pct": float(np.mean(deltas > 0) * 100.0),
        "weights": rows,
    }


def joint_sensitivity_main(
    theta: np.ndarray,
    university_labels: np.ndarray,
    n_personas: int = 200,
    n_sessions: int = 12,
    n_draws: int = 256,
    seed: int = 20261105,
) -> Dict[str, object]:
    """Joint LHS over six mechanism parameters and five state-outcome weights.

    Includes zero-weight cases so the sign dependence is visible.  Reports
    PRCC (partial rank correlation) on the simulated contrast.
    """
    from scipy.stats import qmc, rankdata

    names = [
        "lam_g1", "w2", "theta_cool", "tau_mod", "beta_cap", "mu_lag",
        "cred_brs", "cred_dbi", "cred_echo", "cred_q", "cred_prop",
    ]
    bounds = {
        "lam_g1": (0.06, 0.45),
        "w2": (0.00, 0.60),
        "theta_cool": (0.60, 0.85),
        "tau_mod": (0.55, 0.80),
        "beta_cap": (0.20, 1.00),
        "mu_lag": (0.00, 3.00),
        "cred_brs": (0.00, 1.80),
        "cred_dbi": (0.00, 0.825),
        "cred_echo": (-0.675, 0.00),
        "cred_q": (0.00, 0.675),
        "cred_prop": (-3.75, 0.00),
    }
    sampler = qmc.LatinHypercube(d=len(names), seed=seed)
    unit = sampler.random(n_draws)
    X = np.zeros((n_draws, len(names)))
    deltas = np.zeros(n_draws)
    rows = []
    for i in range(n_draws):
        vals = {}
        for j, name in enumerate(names):
            lo, hi = bounds[name]
            vals[name] = float(lo + unit[i, j] * (hi - lo))
            X[i, j] = vals[name]
        params = v7.ABMParams(
            lam_g1=vals["lam_g1"],
            w2=vals["w2"],
            theta_cool=vals["theta_cool"],
            tau_mod=vals["tau_mod"],
            beta_cap=vals["beta_cap"],
            mu_lag=vals["mu_lag"],
        )
        weights = {
            "cred_brs": vals["cred_brs"],
            "cred_dbi": vals["cred_dbi"],
            "cred_echo": vals["cred_echo"],
            "cred_q": vals["cred_q"],
            "cred_prop": vals["cred_prop"],
        }
        res = v7.run_factorial_experiment(
            theta,
            n_personas=n_personas,
            n_sessions=n_sessions,
            seed=seed + i,
            params=params,
            university_labels=university_labels,
            state_mediated_outcomes=True,
            outcome_weights=weights,
        )
        fa = v7.factorial_analysis(res)
        d = float(fa["delta_sr_eval"]["mean"])
        deltas[i] = d
        rows.append({"draw": i, "delta_sr_eval": d, **vals})

    # PRCC: rank-transform, regress each parameter on the others, correlate
    R = rankdata(X, axis=0)
    ry = rankdata(deltas)
    prcc = {}
    for j, name in enumerate(names):
        others = [k for k in range(len(names)) if k != j]
        A = np.column_stack([np.ones(n_draws), R[:, others]])
        coef_y, *_ = np.linalg.lstsq(A, ry, rcond=None)
        res_y = ry - A @ coef_y
        coef_j, *_ = np.linalg.lstsq(A, R[:, j], rcond=None)
        res_j = R[:, j] - A @ coef_j
        prcc[name] = float(np.corrcoef(res_j, res_y)[0, 1]) if np.std(res_j) > 1e-12 else 0.0
    top = sorted(prcc.items(), key=lambda kv: abs(kv[1]), reverse=True)
    return {
        "n_draws": int(n_draws),
        "n_personas": int(n_personas),
        "n_sessions": int(n_sessions),
        "delta_min": float(np.min(deltas)),
        "delta_max": float(np.max(deltas)),
        "delta_mean": float(np.mean(deltas)),
        "positive_pct": float(np.mean(deltas > 0) * 100.0),
        "prcc": prcc,
        "top_drivers": [{"parameter": k, "prcc": v} for k, v in top[:4]],
        "rows": rows,
    }


def run_pipeline_v8(
    root: Path,
    n_personas: int = 500,
    n_sessions: int = 18,
    seed: int = 20261105,
    embedding_model: str = "BAAI/bge-m3",
    device: Optional[str] = None,
    skip_sensitivity: bool = False,
) -> Dict[str, object]:
    root = Path(root)
    raw_dir = root / "03_data" / "raw"
    qualitative_dir = root / "03_data" / "qualitative"
    out_dir = root / "03_data" / "model_outputs"
    out_dir.mkdir(parents=True, exist_ok=True)

    print("[1/9] Loading raw questionnaires and ride/PO data ...")
    measured = load_raw_measured(raw_dir)
    measured_stats = v7.measured_wave_stats(measured)
    print(f"      collected={measured['n_collected']} retained={measured['n']} removed={measured['removed_ids']}")

    # Write de-identified measured matrices (no narratives, no names).
    deid_cols = [
        c
        for c in measured["df"].columns
        if c not in {"key_observations", "notable_quotes", "researcher_reflections", "profile_name", "backstory"}
    ]
    measured_dir = root / "03_data" / "measured"
    measured_dir.mkdir(parents=True, exist_ok=True)
    measured["df"][deid_cols].to_csv(measured_dir / "respondents_52.csv", index=False)
    measured["df60"][deid_cols].to_csv(measured_dir / "respondents_60.csv", index=False)

    print("[2/9] Building qualitative document collection ...")
    docs, doc_summary = build_text_documents(raw_dir, qualitative_dir)
    print("      docs:", doc_summary)
    if doc_summary["selfreport"] == 0:
        print("      WARNING: no self-report transcript found. Run the Colab ASR cell first for the final results.")

    print("[3/9] Computing multilingual LLM embeddings ...")
    emb = embed_documents(docs, out_dir / "embeddings", model_name=embedding_model, device=device)
    print("      embedding matrix:", emb.shape)
    text_feat = build_llm_features(measured, docs, emb, n_components=32, seed=seed)
    print("      semantic features:", text_feat["X_text"].shape)

    print("[4/9] Building quantitative block and debiasing ...")
    quant = build_quant_block(measured)
    X = np.hstack([quant["X_quant"], text_feat["X_text"]])
    X = np.nan_to_num(X, nan=0.0)
    debiased = v7.dml_ipw_debias(
        X, quant["B_nuisance"], quant["high_interaction"], B_names=quant["B_names"]
    )
    manifold = v7.spectral_manifold(debiased["Z_clean"], n_components=6)
    print("      manifold:", manifold["Theta"].shape, "condition:", round(manifold["condition_after"], 3))

    print("[5/9] Running full-factorial tensor ABM ...")
    factorial = v7.run_factorial_experiment(
        manifold["Theta"],
        n_personas=n_personas,
        n_sessions=n_sessions,
        seed=seed,
        university_labels=measured["df"]["university"].to_numpy(),
        state_mediated_outcomes=True,
    )
    # Scale calibration: anchor the status-quo arm (G0) to the measured PB
    # mean.  This is a single intercept calibration, not a fit to treatment
    # effects.  The measured sample is ordinary Uber use, which corresponds
    # to the no-epistemic-features arm.
    calibration_shift = float(measured["pb_mean"] - np.mean(factorial["sr_eval"][:, 0]))
    factorial["sr_eval"] = factorial["sr_eval"] + calibration_shift
    factorial["mcs_scores"] = factorial["mcs_scores"] + calibration_shift
    factorial["pb_scores"] = factorial["pb_scores"] + calibration_shift
    fa = v7.factorial_analysis(factorial)
    trajectories = v7.compute_session_scores(factorial)

    print("[6/9] Bayesian inference and prior sensitivity ...")
    y = factorial["sr_eval"][:, 7] - factorial["sr_eval"][:, 0]
    bayes = v7.bayesian_hierarchical(y, factorial["groups"], seed=seed)
    prior_sens = v7.prior_sensitivity(y, factorial["groups"], seed=seed)

    print("[7/9] Adversarial misinformation ...")
    adv = v7.adversarial_suite(manifold["Theta"], seed=seed, n_personas=min(400, n_personas))

    print("[8/9] Sobol/LHS, topology, persona robustness ...")
    if skip_sensitivity:
        sens = {
            "lhs_n": 0,
            "survival_rate_pct": float("nan"),
            "joint_sweep": {
                "n_draws": 0,
                "delta_min": float("nan"),
                "delta_max": float("nan"),
                "delta_mean": float("nan"),
                "positive_pct": float("nan"),
                "top_drivers": [],
            },
            "delta_pb_min": float("nan"),
            "delta_pb_max": float("nan"),
            "sobol": [],
            "fA": [],
            "fB": [],
        }
        topo = {}
        pers = {}
    else:
        sens = v7.sobol_sensitivity(manifold["Theta"], n_base=64, seed=seed)
        topo = topology_robustness_main(
            manifold["Theta"],
            measured["df"]["university"].to_numpy(),
            n_personas=n_personas,
            n_sessions=n_sessions,
            seed=seed,
            calibration_shift=calibration_shift,
        )
        pers = persona_robustness_main(
            manifold["Theta"],
            measured["df"]["university"].to_numpy(),
            n_personas=n_personas,
            n_sessions=n_sessions,
            seed=seed,
        )
        joint = joint_sensitivity_main(
            manifold["Theta"],
            measured["df"]["university"].to_numpy(),
            n_personas=min(200, n_personas),
            n_sessions=min(12, n_sessions),
            n_draws=256,
            seed=seed,
        )
        sens["joint_sweep"] = joint

    print("[9/9] Reliability, invariance, and exports ...")
    nmls = factorial["nmls_items_g1"]
    mcs = factorial["mcs_items_g1"]
    rel = {
        "nmls": v7.ValidatedPsychometricInstrument.reliability_battery(nmls),
        "mcs": v7.ValidatedPsychometricInstrument.reliability_battery(mcs),
    }
    retest = factorial.get("nmls_items_retest")
    rel["test_retest_icc"] = (
        float(np.corrcoef(nmls.mean(axis=1), retest.mean(axis=1))[0, 1]) if retest is not None else float("nan")
    )
    fit_g0 = v7.ValidatedPsychometricInstrument.approximate_fit(nmls)
    # No real multigroup CFA is available inside the Python-only run.  The
    # old placeholder offsets are removed; invariance is explicitly not
    # estimated for this synthetic run.
    inv = None

    measured_pb = measured["df"]["PB_mean"].to_numpy(float)
    calibration = {
        "measured_pb_mean": float(np.mean(measured_pb)),
        "measured_pb_sd": float(np.std(measured_pb, ddof=1)),
        "g0_mean": float(np.mean(factorial["sr_eval"][:, 0])),
        "g1_mean": float(np.mean(factorial["sr_eval"][:, 7])),
        "w1_g0_to_measured": float(v7.stats.wasserstein_distance(factorial["sr_eval"][:, 0], measured_pb)),
        "w1_g1_to_measured": float(v7.stats.wasserstein_distance(factorial["sr_eval"][:, 7], measured_pb)),
        "scale_shift": calibration_shift,
        "calibrated_arm": "G0",
    }

    payload = {
        "metadata": {
            "pipeline": "LOKLOK calibrated in-silico experiment v8.0 (original-data + LLM embeddings)",
            "seed": int(seed),
            "n_personas": int(n_personas),
            "n_sessions": int(n_sessions),
            "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S"),
            "hardware": v7.configure_gpu_backend(),
            "embedding_model": embedding_model,
            "embedding_device": device or ("cuda" if _cuda_available() else "cpu"),
            "documents": doc_summary,
            "raw_collected": int(measured["n_collected"]),
            "retained": int(measured["n"]),
            "scale_calibration_shift": calibration_shift,
            "calibrated_arm": "G0",
            "removed_ids": measured["removed_ids"],
            "duplicate_key": measured["duplicate_key"],
        },
        "measured": measured_stats,
        "measured_anchor": {
            "n": measured["n"],
            "pb_mean": measured["pb_mean"],
            "pb_sd": measured["pb_sd"],
            "star_mean": measured["star_mean"],
            "duration_mean": measured["duration_mean"],
            "duration_min": measured["duration_min"],
            "duration_max": measured["duration_max"],
            "interaction_counts": measured["interaction_counts"],
            "university_counts": measured["university_counts"],
            "correlations": measured_stats["correlations"],
            "items": measured_stats,
        },
        "embedding": {
            "n": int(len(measured["df"])),
            "n_features_biased": int(X.shape[1]),
            "n_quant_features": int(quant["X_quant"].shape[1]),
            "n_text_features": int(text_feat["X_text"].shape[1]),
            "condition_before": manifold["condition_before"],
            "condition_after": manifold["condition_after"],
            "max_abs_corr_before": debiased["max_abs_corr_before"],
            "max_abs_corr_orth": debiased["max_abs_corr_orth"],
            "max_abs_corr_after": debiased["max_abs_corr_after"],
            "covariate_balance": debiased["covariate_balance"],
            "weight_range": debiased["weight_range"],
            "q0_sampler": factorial["q0_sampler"],
            "q0_cond": factorial["q0_cond"],
            "llm_embedding_dim": text_feat["embedding_dim"],
            "semantic_components": text_feat["semantic_components"],
            "pca_explained": text_feat["pca_explained"],
            "documents": doc_summary,
        },
        "factorial": fa,
        "group_names": factorial["group_names"],
        "nmls_domains": {
            d: {
                "g0": float(np.mean(factorial["domain_scores"][d][:, 0])),
                "g1": float(np.mean(factorial["domain_scores"][d][:, 7])),
                "gain": float(np.mean(factorial["domain_scores"][d][:, 7] - factorial["domain_scores"][d][:, 0])),
            }
            for d in ["FC", "CC", "FP", "CP"]
        },
        "mcs_pb_domains": {
            "MCS": {
                "g0": float(np.mean(factorial["mcs_scores"][:, 0])),
                "g1": float(np.mean(factorial["mcs_scores"][:, 7])),
                "gain": float(np.mean(factorial["mcs_scores"][:, 7] - factorial["mcs_scores"][:, 0])),
            },
            "PB": {
                "g0": float(np.mean(factorial["pb_scores"][:, 0])),
                "g1": float(np.mean(factorial["pb_scores"][:, 7])),
                "gain": float(np.mean(factorial["pb_scores"][:, 7] - factorial["pb_scores"][:, 0])),
            },
        },
        "calibration": calibration,
        "bayesian": bayes,
        "bayesian_prior_sensitivity": {
            k: {
                "tau_mean": v["tau_mean"],
                "tau_hdi_low": v["tau_hdi_low"],
                "tau_hdi_high": v["tau_hdi_high"],
                "prob_positive": v["prob_positive"],
                "bf10": v["bf10"],
            }
            for k, v in prior_sens.items()
        },
        "bayesian_prior_draws": {k: v["draws_tau"] for k, v in prior_sens.items()},
        "adversarial": adv,
        "sensitivity": sens,
        "topology": topo,
        "persona_robustness": pers,
        "reliability": rel,
        "invariance": inv,
        "n_sessions": int(n_sessions),
    }

    v7.write_json(out_dir / "pipeline_results.json", payload)
    np.savez_compressed(
        out_dir / "figure_data.npz",
        sr_eval=factorial["sr_eval"],
        sr_comp=factorial["sr_comp"],
        sr_eval_t=trajectories["sr_eval_t"],
        sr_comp_t=trajectories["sr_comp_t"],
        tensor=factorial["tensor"],
        groups=factorial["groups"],
        nmls_items=factorial["nmls_items_g1"],
        nmls_items_g0=factorial["nmls_items_g0"],
        mcs_items=factorial["mcs_items_g1"],
        mcs_items_g0=factorial["mcs_items_g0"],
        domain_fc=factorial["domain_scores"]["FC"],
        domain_cc=factorial["domain_scores"]["CC"],
        domain_fp=factorial["domain_scores"]["FP"],
        domain_cp=factorial["domain_scores"]["CP"],
        mcs=factorial["mcs_scores"],
        pb=factorial["pb_scores"],
        cell_labels=np.array(v7.CELL_LABELS),
        theta_real=manifold["Theta"],
        university=np.array(measured["df"]["university"].astype(str).tolist()),
    )
    v7.write_latex_macros(root / "01_thesis" / "src" / "generated" / "pipeline_macros.tex", payload)
    v7.write_latex_tables(root / "01_thesis" / "src" / "generated", payload)
    joint = payload.get("sensitivity", {}).get("joint_sweep", {})
    if joint:
        top = joint.get("top_drivers", [])
        # small generated table
        lines = [
            "\\begin{table}[htbp]",
            "\\centering",
            "\\caption{Joint Sensitivity of the Main Simulator (Model-Based)}",
            "\\label{tab:joint-sensitivity}",
            "\\begin{singlespace}\\small",
            "\\begin{tabularx}{\\textwidth}{@{}lr@{}}",
            "\\toprule",
            "Quantity & Value \\\\",
            "\\midrule",
            f"LHS draws & {joint.get('n_draws', 0)} \\\\",
            f"Personas per draw & {joint.get('n_personas', 0)} \\\\",
            f"Sessions per draw & {joint.get('n_sessions', 0)} \\\\",
            f"$\\Delta\\mathrm{{SR}}_{{\\mathrm{{eval}}}}$ range & [{joint.get('delta_min', float('nan')):+.3f}, {joint.get('delta_max', float('nan')):+.3f}] \\\\",
            f"Mean & {joint.get('delta_mean', float('nan')):+.3f} \\\\",
            f"Positive draws & {joint.get('positive_pct', float('nan')):.1f}\\% \\\\",
        ]
        for d in top[:4]:
            pname = d["parameter"].replace("_", "\\_")
            lines.append(f"PRCC: {pname} & {d['prcc']:+.2f} \\\\")
        lines += [
            "\\bottomrule",
            "\\end{tabularx}",
            "\\tabnote{Six mechanism parameters and five state-outcome weights; weight ranges include zero. PRCC = partial rank correlation with the simulated contrast.}",
            "\\end{singlespace}",
            "\\end{table}",
        ]
        (root / "01_thesis" / "src" / "generated" / "tab_joint_sensitivity.tex").write_text("\n".join(lines), encoding="utf-8")
        top_txt = ", ".join(
            (d["parameter"].replace("_", "\\_")) + f" ({d['prcc']:+.2f})"
            for d in top[:3]
        )
        with open(root / "01_thesis" / "src" / "generated" / "pipeline_macros.tex", "a", encoding="utf-8") as fh:
            fh.write("\n% Joint mechanism + state-outcome sensitivity\n")
            fh.write(f"\\newcommand{{\\PipelineJointMin}}{{{joint.get('delta_min', float('nan')):+.3f}}}\n")
            fh.write(f"\\newcommand{{\\PipelineJointMax}}{{{joint.get('delta_max', float('nan')):+.3f}}}\n")
            fh.write(f"\\newcommand{{\\PipelineJointMean}}{{{joint.get('delta_mean', float('nan')):+.3f}}}\n")
            fh.write(f"\\newcommand{{\\PipelineJointPositive}}{{{joint.get('positive_pct', float('nan')):.1f}}}\n")
            fh.write(f"\\newcommand{{\\PipelineJointTop}}{{{top_txt}}}\n")

    if v7.PANDAS_AVAILABLE:
        pd.DataFrame(
            [
                {
                    "cell": c["cell"],
                    "A": c["factors"][0],
                    "B": c["factors"][1],
                    "C": c["factors"][2],
                    "mean": c["mean"],
                    "ci_low": c["ci_low"],
                    "ci_high": c["ci_high"],
                }
                for c in fa["cell_means"]
            ]
        ).to_csv(out_dir / "factorial_cells.csv", index=False)
        pd.DataFrame(adv["dose_response"]).to_csv(out_dir / "adversarial_dose_response.csv", index=False)
        pd.DataFrame(sens["sobol"]).to_csv(out_dir / "sobol_indices.csv", index=False)
        pd.DataFrame(
            [
                {"variant": "ER", "delta_pb": topo.get("Erdos-Renyi", {}).get("delta_pb", np.nan)},
                {"variant": "WS", "delta_pb": topo.get("Watts-Strogatz", {}).get("delta_pb", np.nan)},
                {"variant": "BA", "delta_pb": topo.get("Barabasi-Albert", {}).get("delta_pb", np.nan)},
            ]
        ).to_csv(out_dir / "topology_robustness.csv", index=False)
        pd.DataFrame({"delta_sr_eval": y, "group": factorial["groups"]}).to_csv(
            out_dir / "persona_deltas.csv", index=False
        )
        pd.DataFrame(nmls).to_csv(out_dir / "nmls_g1_items.csv", index=False)
        pd.DataFrame(mcs).to_csv(out_dir / "mcs_pb_g1_items.csv", index=False)
        pd.DataFrame(factorial["nmls_items_g0"]).to_csv(out_dir / "nmls_g0_items.csv", index=False)
        pd.DataFrame(factorial["mcs_items_g0"]).to_csv(out_dir / "mcs_pb_g0_items.csv", index=False)
        pd.DataFrame(
            [
                {"domain": d, "g0": payload["nmls_domains"][d]["g0"], "g1": payload["nmls_domains"][d]["g1"], "gain": payload["nmls_domains"][d]["gain"]}
                for d in ["FC", "CC", "FP", "CP"]
            ]
        ).to_csv(out_dir / "nmls_domains.csv", index=False)

    # Save the document/embedding provenance for audit.
    with open(out_dir / "documents.json", "w", encoding="utf-8") as fh:
        json.dump(docs, fh, ensure_ascii=False, indent=2)
    np.save(out_dir / "embeddings" / "document_embeddings.npy", emb)

    print("Done. Outputs in", out_dir)
    return payload


def _cuda_available() -> bool:
    try:
        import torch

        return bool(torch.cuda.is_available())
    except Exception:
        return False


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="LOKLOK final pipeline v8.0")
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[2])
    parser.add_argument("--n-personas", type=int, default=500)
    parser.add_argument("--sessions", type=int, default=18)
    parser.add_argument("--seed", type=int, default=20261105)
    parser.add_argument("--embedding-model", type=str, default="BAAI/bge-m3")
    parser.add_argument("--device", type=str, default=None)
    parser.add_argument("--skip-sensitivity", action="store_true")
    args = parser.parse_args(argv)
    run_pipeline_v8(
        args.root,
        n_personas=args.n_personas,
        n_sessions=args.sessions,
        seed=args.seed,
        embedding_model=args.embedding_model,
        device=args.device,
        skip_sensitivity=args.skip_sensitivity,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
