"""Leave-one-filter-out ablation for the eight ABM influence filters.

Each variant neutralises one filter while holding personas, seed, outcome
weights, and the Zewail gate fixed.  This is a model-internal test of whether
the named filters are outcome-active; it is not a human experiment.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "02_code" / "pipeline"))

import loklok_pipeline_v8 as v8  # noqa: E402
import loklok_pipeline as v7  # noqa: E402

SEED = 20261105
N_PERSONAS = 500
N_SESSIONS = 18

VARIANTS = {
    "baseline": {},
    "Laplace_off": {"laplace_coef": 0.0},
    "Lyapunov_off": {"beta_cap": 0.0},
    "DeGroot_off": {"lam_g1": 0.0, "lam_g0": 0.0},
    "Lagrange_off": {"w2": 0.0},
    "Hilbert_off": {"hilbert_weight": 0.0},
    "Percolation_off": {"tau_mod": 1.0},
    "Entropy_off": {"theta_cool": 1.1},
}


def paired(d: np.ndarray) -> dict:
    d = np.asarray(d, dtype=float)
    se = float(np.std(d, ddof=1) / np.sqrt(len(d)))
    return {
        "mean": float(np.mean(d)),
        "sd": float(np.std(d, ddof=1)),
        "ci_low": float(np.mean(d) - 1.96 * se),
        "ci_high": float(np.mean(d) + 1.96 * se),
    }


def main() -> None:
    measured = v8.load_raw_measured(ROOT / "03_data" / "raw")
    docs, _ = v8.build_text_documents(ROOT / "03_data" / "raw", ROOT / "03_data" / "qualitative")
    emb = np.load(
        ROOT / "03_data" / "model_outputs" / "embeddings" / "embeddings_0f6c66e54fb6ca2c.npy"
    )
    text_feat = v8.build_llm_features(measured, docs, emb)
    quant = v8.build_quant_block(measured)
    X = np.hstack([quant["X_quant"], text_feat["X_text"]])
    debiased = v7.dml_ipw_debias(
        X, quant["B_nuisance"], quant["high_interaction"], B_names=quant["B_names"]
    )
    manifold = v7.spectral_manifold(debiased["Z_clean"], n_components=6)
    theta = manifold["Theta"]
    labels = measured["df"]["university"].to_numpy()

    results = {}
    per_persona = {}
    for label, overrides in VARIANTS.items():
        print(f"[{label}] running ...", flush=True)
        params = v7.ABMParams(**overrides)
        res = v7.run_factorial_experiment(
            theta,
            n_personas=N_PERSONAS,
            n_sessions=N_SESSIONS,
            seed=SEED,
            params=params,
            university_labels=labels,
            state_mediated_outcomes=True,
        )
        fa = v7.factorial_analysis(res)
        dn = res["sr_eval"][:, 7] - res["sr_eval"][:, 0]
        per_persona[label] = dn
        results[label] = {
            "overrides": overrides,
            "delta_sr_eval": fa["delta_sr_eval"],
            "delta_sr_comp": fa["delta_sr_comp"],
            "delta_engagement": fa["delta_engagement"],
            "sr_g0": float(fa["sr_eval_g0"]),
            "sr_g1": float(fa["sr_eval_g1"]),
            "echo_g0": float(fa["echo_g0"]),
            "echo_g1": float(fa["echo_g1"]),
            "brs_g0": float(fa["brs_g0"]),
            "brs_g1": float(fa["brs_g1"]),
        }
        print(
            f"  dSR={fa['delta_sr_eval']['mean']:+.3f} "
            f"dComp={fa['delta_sr_comp']['mean']:+.3f} "
            f"dEng={fa['delta_engagement']['mean']:+.3f}",
            flush=True,
        )

    base = per_persona["baseline"]
    comparisons = {}
    for label, arr in per_persona.items():
        if label == "baseline":
            continue
        comparisons[label] = paired(arr - base)

    out = {
        "seed": SEED,
        "n_personas": N_PERSONAS,
        "n_sessions": N_SESSIONS,
        "variants": results,
        "paired_difference_vs_baseline": comparisons,
        "note": "Hamiltonian is a diagnostic and does not enter the outcome equations; it has no separate ablation.",
    }
    out_dir = ROOT / "03_data" / "model_outputs"
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "filter_ablation.json").write_text(
        json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    pd.DataFrame(
        [
            {
                "variant": label,
                "delta_sr_eval": v["delta_sr_eval"]["mean"],
                "delta_sr_comp": v["delta_sr_comp"]["mean"],
                "delta_engagement": v["delta_engagement"]["mean"],
                "echo_g0": v["echo_g0"],
                "echo_g1": v["echo_g1"],
                "brs_g0": v["brs_g0"],
                "brs_g1": v["brs_g1"],
            }
            for label, v in results.items()
        ]
    ).to_csv(out_dir / "filter_ablation.csv", index=False)
    print("Saved:", out_dir / "filter_ablation.json", flush=True)


if __name__ == "__main__":
    main()
