"""Write LaTeX macros from the R/lavaan CFA and invariance results."""
import json
from pathlib import Path

root = Path(__file__).resolve().parents[2]
src = root / "03_data" / "model_outputs" / "cfa_r_results.json"
out = root / "01_thesis" / "src" / "generated" / "r_macros.tex"
data = json.loads(src.read_text(encoding="utf-8"))
cfg = data["configural"]
met = data["metric"]
sca = data["scalar"]
lines = [
    "% Auto-generated from 03_data/model_outputs/cfa_r_results.json",
    f"\\newcommand{{\\RInvConfigCFI}}{{{cfg['CFI']:.4f}}}",
    f"\\newcommand{{\\RInvConfigRMSEA}}{{{cfg['RMSEA']:.4f}}}",
    f"\\newcommand{{\\RInvMetricCFI}}{{{met['CFI']:.4f}}}",
    f"\\newcommand{{\\RInvMetricDelta}}{{{met['delta_cfi']:+.4f}}}",
    f"\\newcommand{{\\RInvMetricRMSEA}}{{{met['RMSEA']:.4f}}}",
    f"\\newcommand{{\\RInvScalarCFI}}{{{sca['CFI']:.4f}}}",
    f"\\newcommand{{\\RInvScalarDelta}}{{{sca['delta_cfi']:+.4f}}}",
    f"\\newcommand{{\\RInvScalarRMSEA}}{{{sca['RMSEA']:.4f}}}",
]
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text("\n".join(lines) + "\n", encoding="utf-8")
print(out)
