"""Bootstrap over the 52 measured anchors.

Each replicate resamples the 52 rows with replacement, refits DML/IPW, the
six-axis spectral manifold, and Q0, then reruns the main state-mediated ABM.
This propagates uncertainty in the empirical anchors, which the 500-persona
Monte Carlo does not do.  It is a model-internal uncertainty analysis, not a
human replication.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "02_code" / "pipeline"))

import loklok_pipeline_v8 as v8  # noqa: E402
import loklok_pipeline as v7  # noqa: E402

SEED = 20261105
N_BOOT = 50
N_PERSONAS = 200
N_SESSIONS = 12


def main() -> None:
    measured = v8.load_raw_measured(ROOT / "03_data" / "raw")
    docs, _ = v8.build_text_documents(ROOT / "03_data" / "raw", ROOT / "03_data" / "qualitative")
    emb = np.load(
        ROOT / "03_data" / "model_outputs" / "embeddings" / "embeddings_0f6c66e54fb6ca2c.npy"
    )
    text_feat = v8.build_llm_features(measured, docs, emb)
    quant = v8.build_quant_block(measured)
    X = np.hstack([quant["X_quant"], text_feat["X_text"]])
    B = quant["B_nuisance"]
    high = quant["high_interaction"]
    labels = measured["df"]["university"].to_numpy()
    n = len(labels)

    def run_one(Xb, Bb, hb, labelsb):
        debiased = v7.dml_ipw_debias(Xb, Bb, hb, B_names=quant["B_names"])
        manifold = v7.spectral_manifold(debiased["Z_clean"], n_components=6)
        res = v7.run_factorial_experiment(
            manifold["Theta"],
            n_personas=N_PERSONAS,
            n_sessions=N_SESSIONS,
            seed=SEED,
            university_labels=labelsb,
            state_mediated_outcomes=True,
        )
        fa = v7.factorial_analysis(res)
        return float(fa["delta_sr_eval"]["mean"]), float(fa["delta_sr_comp"]["mean"]), float(fa["delta_engagement"]["mean"])

    print("[baseline_small] running ...", flush=True)
    base = run_one(X, B, high, labels)
    print("  baseline_small", base, flush=True)

    rng = np.random.default_rng(SEED + 2026)
    rows = []
    for b in range(N_BOOT):
        idx = rng.integers(0, n, size=n)
        try:
            d = run_one(X[idx], B[idx], high[idx], labels[idx])
        except Exception as exc:
            print(f"[{b}] failed: {exc}", flush=True)
            continue
        rows.append({"replicate": b, "delta_sr_eval": d[0], "delta_sr_comp": d[1], "delta_engagement": d[2]})
        if (b + 1) % 5 == 0:
            print(f"  {b+1}/{N_BOOT} dSR={d[0]:+.3f}", flush=True)

    arr = np.array([r["delta_sr_eval"] for r in rows])
    out = {
        "seed": SEED,
        "n_boot": len(rows),
        "n_personas": N_PERSONAS,
        "n_sessions": N_SESSIONS,
        "baseline_small": {
            "delta_sr_eval": base[0],
            "delta_sr_comp": base[1],
            "delta_engagement": base[2],
        },
        "bootstrap": {
            "mean": float(np.mean(arr)),
            "sd": float(np.std(arr, ddof=1)),
            "q025": float(np.percentile(arr, 2.5)),
            "q975": float(np.percentile(arr, 97.5)),
            "positive_pct": float(np.mean(arr > 0) * 100.0),
        },
        "replicates": rows,
        "note": "Bootstrap over 52 measured anchors; model-internal uncertainty, not human sampling.",
    }
    out_dir = ROOT / "03_data" / "model_outputs"
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "anchor_bootstrap.json").write_text(
        json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    pd.DataFrame(rows).to_csv(out_dir / "anchor_bootstrap.csv", index=False)
    print("Saved:", out_dir / "anchor_bootstrap.json", flush=True)
    print(json.dumps(out["bootstrap"], indent=2), flush=True)


if __name__ == "__main__":
    main()
