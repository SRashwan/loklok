"""Source and text-feature ablation for the v8 pipeline.

Variants:
  full              full 198-feature matrix
  quant_only        drop all semantic features
  no_corpora        drop Uber/social/lifestyle corpora
  no_fgd            drop FGD documents
  no_selfreport     drop the researcher self-report
  no_po             drop participant-observation documents
  shuffled_text     keep the semantic matrix but shuffle it across respondents

This tests whether the LLM/qualitative contribution is load-bearing.  It is a
model-internal ablation, not a human experiment.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "02_code" / "pipeline"))

import loklok_pipeline_v8 as v8  # noqa: E402
import loklok_pipeline as v7  # noqa: E402

SEED = 20261105
N_PERSONAS = 500
N_SESSIONS = 18


def paired(d: np.ndarray) -> dict:
    d = np.asarray(d, dtype=float)
    se = float(np.std(d, ddof=1) / np.sqrt(len(d)))
    return {
        "mean": float(np.mean(d)),
        "sd": float(np.std(d, ddof=1)),
        "ci_low": float(np.mean(d) - 1.96 * se),
        "ci_high": float(np.mean(d) + 1.96 * se),
    }


def run_variant(measured, quant, docs, emb, variant, labels):
    if variant == "quant_only":
        X = quant["X_quant"]
    else:
        if variant == "full" or variant == "shuffled_text":
            use_docs, use_emb = docs, emb
        elif variant == "no_corpora":
            keep = [i for i, d in enumerate(docs) if not str(d["source"]).startswith("corpus_")]
            use_docs = [docs[i] for i in keep]
            use_emb = emb[keep]
        elif variant == "no_fgd":
            keep = [i for i, d in enumerate(docs) if d["source"] != "fgd"]
            use_docs = [docs[i] for i in keep]
            use_emb = emb[keep]
        elif variant == "no_selfreport":
            keep = [i for i, d in enumerate(docs) if d["source"] != "selfreport"]
            use_docs = [docs[i] for i in keep]
            use_emb = emb[keep]
        elif variant == "no_po":
            keep = [i for i, d in enumerate(docs) if d["source"] != "po"]
            use_docs = [docs[i] for i in keep]
            use_emb = emb[keep]
        else:
            raise ValueError(variant)
        tf = v8.build_llm_features(measured, use_docs, use_emb)
        text = tf["X_text"]
        if variant == "shuffled_text":
            rng = np.random.default_rng(SEED + 99)
            text = text[rng.permutation(len(text))]
        X = np.hstack([quant["X_quant"], text])
    X = np.nan_to_num(X, nan=0.0)
    debiased = v7.dml_ipw_debias(
        X, quant["B_nuisance"], quant["high_interaction"], B_names=quant["B_names"]
    )
    manifold = v7.spectral_manifold(debiased["Z_clean"], n_components=6)
    theta = manifold["Theta"]
    res = v7.run_factorial_experiment(
        theta,
        n_personas=N_PERSONAS,
        n_sessions=N_SESSIONS,
        seed=SEED,
        university_labels=labels,
        state_mediated_outcomes=True,
    )
    fa = v7.factorial_analysis(res)
    return fa, res


def main() -> None:
    measured = v8.load_raw_measured(ROOT / "03_data" / "raw")
    docs, _ = v8.build_text_documents(ROOT / "03_data" / "raw", ROOT / "03_data" / "qualitative")
    emb = np.load(
        ROOT / "03_data" / "model_outputs" / "embeddings" / "embeddings_0f6c66e54fb6ca2c.npy"
    )
    quant = v8.build_quant_block(measured)
    labels = measured["df"]["university"].to_numpy()

    variants = ["full", "quant_only", "no_corpora", "no_fgd", "no_selfreport", "no_po", "shuffled_text"]
    results = {}
    per_persona = {}
    for variant in variants:
        print(f"[{variant}] running ...", flush=True)
        fa, res = run_variant(measured, quant, docs, emb, variant, labels)
        dn = res["sr_eval"][:, 7] - res["sr_eval"][:, 0]
        per_persona[variant] = dn
        results[variant] = {
            "delta_sr_eval": fa["delta_sr_eval"],
            "delta_sr_comp": fa["delta_sr_comp"],
            "delta_engagement": fa["delta_engagement"],
            "sr_g0": float(fa["sr_eval_g0"]),
            "sr_g1": float(fa["sr_eval_g1"]),
            "echo_g0": float(fa["echo_g0"]),
            "echo_g1": float(fa["echo_g1"]),
        }
        print(
            f"  dSR={fa['delta_sr_eval']['mean']:+.3f} "
            f"dComp={fa['delta_sr_comp']['mean']:+.3f} "
            f"dEng={fa['delta_engagement']['mean']:+.3f}",
            flush=True,
        )

    base = per_persona["full"]
    comparisons = {
        v: paired(arr - base) for v, arr in per_persona.items() if v != "full"
    }
    out = {
        "seed": SEED,
        "n_personas": N_PERSONAS,
        "n_sessions": N_SESSIONS,
        "variants": results,
        "paired_difference_vs_full": comparisons,
        "note": "Model-internal source/feature ablation; not a human experiment.",
    }
    out_dir = ROOT / "03_data" / "model_outputs"
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "source_ablation.json").write_text(
        json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    pd.DataFrame(
        [
            {
                "variant": k,
                "delta_sr_eval": v["delta_sr_eval"]["mean"],
                "delta_sr_comp": v["delta_sr_comp"]["mean"],
                "delta_engagement": v["delta_engagement"]["mean"],
                "sr_g0": v["sr_g0"],
                "sr_g1": v["sr_g1"],
                "echo_g0": v["echo_g0"],
                "echo_g1": v["echo_g1"],
            }
            for k, v in results.items()
        ]
    ).to_csv(out_dir / "source_ablation.csv", index=False)
    print("Saved:", out_dir / "source_ablation.json", flush=True)


if __name__ == "__main__":
    main()
