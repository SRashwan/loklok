"""Re-upload the fixed v8 notebook to Colab, set downloads, and Run all."""
import json
import time
import urllib.parse

import requests
import websocket

CDP = "http://127.0.0.1:9222"
NB = r"D:\all_aywa\loklok-thesis-final-upgrade\02_code\colab\LOKLOK_Thesis_v8_Colab_GPU.ipynb"
DL = r"D:\all_aywa\loklok-thesis-final-upgrade\colab_downloads"


def tabs():
    return requests.get(f"{CDP}/json/list", timeout=5).json()


def page_tab():
    for t in tabs():
        if t["type"] == "page":
            return t
    raise RuntimeError("no page")


def ws_for(t):
    return websocket.create_connection(t["webSocketDebuggerUrl"], timeout=20)


def call(ws, method, params, rid):
    ws.send(json.dumps({"id": rid, "method": method, "params": params}))
    while True:
        m = json.loads(ws.recv())
        if m.get("id") == rid:
            return m


def ev(ws, expr, rid):
    r = call(ws, "Runtime.evaluate", {"expression": expr, "returnByValue": True}, rid)
    return r.get("result", {}).get("result", {}).get("value")


t = page_tab()
ws = ws_for(t)
call(ws, "Browser.setDownloadBehavior", {
    "behavior": "allow",
    "downloadPath": DL,
    "eventsEnabled": True,
}, 1)
call(ws, "Page.bringToFront", {}, 2)
call(ws, "Page.navigate", {"url": "https://colab.research.google.com/"}, 3)
print("[driver] waiting for colab home", flush=True)
time.sleep(12)

# click the upload button (leaf text 'upload')
r = ev(ws, r'''
(() => {
  let target=null;
  const walk=(root,depth)=>{ if(depth>20||target) return;
    root.querySelectorAll('*').forEach(el=>{
      if(target) return;
      const txt=(el.childNodes.length && !el.querySelector('*'))?(el.textContent||'').trim():'';
      if(txt==='upload'){ target=el; }
      if(el.shadowRoot) walk(el.shadowRoot,depth+1);
    });
  };
  walk(document,0);
  if(target){ (target.closest('button')||target.parentElement).click(); return 'clicked'; }
  return 'not found';
})()
''', 4)
print("[driver] upload click:", r, flush=True)
time.sleep(3)

doc = call(ws, "DOM.getDocument", {"pierce": True, "depth": -1}, 5)
root = doc["result"]["root"]["nodeId"]
q = call(ws, "DOM.querySelector", {"nodeId": root, "selector": "input[type=file]"}, 6)
nid = q.get("result", {}).get("nodeId")
print("[driver] file input nodeId:", nid, flush=True)
if nid:
    call(ws, "DOM.setFileInputFiles", {"files": [NB], "nodeId": nid}, 7)
    print("[driver] notebook file set", flush=True)

time.sleep(18)
for t in tabs():
    if t["type"] == "page":
        print("[driver] page:", t["title"][:60], t["url"][:80], flush=True)

# switch websocket to the notebook tab
nb_tab = None
for t in tabs():
    if t["type"] == "page" and "/drive/" in t["url"] and "colab.research.google.com" in t["url"]:
        nb_tab = t
        break
if nb_tab:
    ws.close()
    ws = ws_for(nb_tab)
    call(ws, "Page.bringToFront", {}, 8)
    time.sleep(10)
    call(ws, "Input.dispatchKeyEvent", {"type": "keyDown", "modifiers": 2, "windowsVirtualKeyCode": 120, "nativeVirtualKeyCode": 120, "code": "F9", "key": "F9"}, 9)
    call(ws, "Input.dispatchKeyEvent", {"type": "keyUp", "modifiers": 2, "windowsVirtualKeyCode": 120, "nativeVirtualKeyCode": 120, "code": "F9", "key": "F9"}, 10)
    print("[driver] Ctrl+F9 dispatched", flush=True)
    time.sleep(25)
    txt = ev(ws, "document.body.innerText.slice(0,2500)", 11) or ""
    print(txt[:2000], flush=True)
ws.close()
