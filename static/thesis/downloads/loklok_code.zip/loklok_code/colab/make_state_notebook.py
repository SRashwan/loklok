import json
from pathlib import Path

out = Path(r"D:\all_aywa\loklok-thesis-final-upgrade\02_code\colab\LOKLOK_v8_State_Colab_GPU.ipynb")
cells = []

def md(s):
    cells.append({"cell_type": "markdown", "metadata": {}, "source": s.splitlines(True)})

def code(s):
    cells.append({"cell_type": "code", "execution_count": None, "metadata": {}, "outputs": [], "source": s.splitlines(True)})

md("""# LOKLOK v8 — State-Mediated ABM Rerun on T4

This notebook reruns the v8 pipeline using the **cached BGE-M3 embeddings** and the **existing 185-segment self-report transcript**. It does **not** re-run Whisper and does **not** need `sentence-transformers`, so the previous CUDA/PyAV/OOM errors cannot occur.

Upload `colab_bundle_v8.zip` from the package root when prompted.
""")

code("""!nvidia-smi
import torch
print("torch", torch.__version__)
print("cuda", torch.cuda.is_available())
if torch.cuda.is_available():
    print(torch.cuda.get_device_name(0))
""")

code("""from google.colab import files
import glob, shutil, os
print("Upload colab_bundle_v8.zip")
up = files.upload()
zips = glob.glob("/content/*bundle_v8*.zip")
if not zips:
    raise FileNotFoundError("No colab_bundle_v8.zip uploaded")
shutil.copy(zips[0], "/content/colab_bundle_v8.zip")
print("using", zips[0], "->", os.path.getsize("/content/colab_bundle_v8.zip"), "bytes")
""")

code("""!cd /content && rm -rf loklok_v8 && unzip -q -o colab_bundle_v8.zip -d /content
from pathlib import Path
ROOT = Path("/content/loklok_v8")
print(ROOT, ROOT.exists())
print("selfreport:", (ROOT/"03_data/qualitative/selfreport/selfreport_transcript.json").exists())
print("embedding cache:", (ROOT/"03_data/model_outputs/embeddings/embeddings_0f6c66e54fb6ca2c.npy").exists())
print(sorted(p.name for p in ROOT.iterdir()))
""")

code("""import sys
from pathlib import Path
ROOT = Path("/content/loklok_v8")
sys.path.insert(0, str(ROOT/"02_code/pipeline"))
import loklok_pipeline_v8 as v8
docs, summary = v8.build_text_documents(ROOT/"03_data/raw", ROOT/"03_data/qualitative")
cache = v8._embedding_cache_path(ROOT/"03_data/model_outputs/embeddings", "BAAI/bge-m3", docs)
print(summary)
print("cache:", cache.name, cache.exists())
assert cache.exists(), "Embedding cache hash mismatch; do not continue"
""")

code("""!cd /content/loklok_v8 && PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True python 02_code/pipeline/loklok_pipeline_v8.py --root /content/loklok_v8 --n-personas 500 --sessions 18 --seed 20261105 --embedding-model BAAI/bge-m3 --device cuda
""")

code("""!cd /content/loklok_v8 && python 02_code/pipeline/generate_figures.py --root /content/loklok_v8
""")

code("""import json
from pathlib import Path
ROOT = Path("/content/loklok_v8")
r = json.loads((ROOT/"03_data/model_outputs/pipeline_results.json").read_text(encoding="utf-8"))
print("delta:", r["factorial"]["delta_sr_eval"]["mean"], r["factorial"]["delta_sr_comp"]["mean"], r["factorial"]["delta_engagement"]["mean"])
print("main:", {k: v["mean"] for k, v in r["factorial"]["main_effects"].items()})
print("attribution:", r["factorial"].get("attribution_pct"))
print("calibration:", r["calibration"])
print("bayes:", {k: r["bayesian"][k] for k in ["tau_mean", "tau_hdi_low", "tau_hdi_high", "ess_tau", "lag1_autocorr"]})
print("topology:", r["topology"])
print("embedding:", {k: r["embedding"][k] for k in ["n_features_biased", "n_quant_features", "n_text_features", "condition_after", "documents"]})
""")

code("""!cd /content && rm -f loklok_v8_state_results.zip && zip -q -r loklok_v8_state_results.zip loklok_v8/03_data/model_outputs loklok_v8/03_data/measured loklok_v8/03_data/qualitative/selfreport loklok_v8/01_thesis/src/generated loklok_v8/01_thesis/src/figures loklok_v8/04_figures
!ls -lh /content/loklok_v8_state_results.zip
""")

code("""from google.colab import files
files.download("/content/loklok_v8_state_results.zip")
""")

nb = {
    "nbformat": 4,
    "nbformat_minor": 0,
    "metadata": {
        "colab": {"provenance": [], "gpuType": "T4"},
        "accelerator": "GPU",
        "kernelspec": {"name": "python3", "display_name": "Python 3"},
        "language_info": {"name": "python"},
    },
    "cells": cells,
}
out.write_text(json.dumps(nb, ensure_ascii=False, indent=1), encoding="utf-8")
print(out, out.stat().st_size)
