﻿import time
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
opts = Options()
opts.debugger_address = "127.0.0.1:9222"
opts.add_experimental_option("prefs", {"download.default_directory": r"D:\all_aywa\loklok-thesis-final-upgrade\colab_downloads", "download.prompt_for_download": False, "download.directory_upgrade": True, "safebrowsing.enabled": True})
d = webdriver.Chrome(options=opts)
d.get("https://colab.research.google.com/")
time.sleep(8)
print("URL", d.current_url)
print("TITLE", d.title)
print("TEXT", d.find_element(By.TAG_NAME,"body").text[:3000])
print("INPUTS", len(d.find_elements(By.CSS_SELECTOR,"input[type=file]")))
d.save_screenshot(r"D:\all_aywa\loklok-thesis-final-upgrade\07_validation\colab_home.png")
