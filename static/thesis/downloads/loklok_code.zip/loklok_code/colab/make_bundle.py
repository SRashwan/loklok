"""Create colab_bundle.zip with the code/data needed by the notebooks."""
from pathlib import Path
import zipfile

root = Path(__file__).resolve().parents[2]
out = root / "colab_bundle.zip"
include = [
    "README.md",
    "START_HERE.md",
    "02_code",
    "03_data",
    "01_thesis/src/generated",
    "01_thesis/src/figures",
]
with zipfile.ZipFile(out, "w", compression=zipfile.ZIP_DEFLATED) as z:
    for rel in include:
        p = root / rel
        if p.is_file():
            z.write(p, arcname=f"loklok-thesis-final-upgrade/{rel}")
        elif p.is_dir():
            for f in p.rglob("*"):
                if f.is_file():
                    z.write(f, arcname=f"loklok-thesis-final-upgrade/{f.relative_to(root).as_posix()}")
print(out, out.stat().st_size)
