"""Sign in to Colab through the open Chrome session (CDP)."""
import json
import time

import requests
import websocket

CDP = "http://127.0.0.1:9222"


def tabs():
    return requests.get(f"{CDP}/json/list", timeout=5).json()


def page_tab():
    for t in tabs():
        if t["type"] == "page":
            return t
    raise RuntimeError("no page")


def ws_for(t):
    return websocket.create_connection(t["webSocketDebuggerUrl"], timeout=10)


def ev(ws, expr, rid):
    ws.send(json.dumps({"id": rid, "method": "Runtime.evaluate",
                        "params": {"expression": expr, "returnByValue": True}}))
    while True:
        m = json.loads(ws.recv())
        if m.get("id") == rid:
            return m.get("result", {}).get("result", {}).get("value")


def leaves(ws):
    expr = r'''
(() => {
  const out = [];
  const walk = (root, depth) => {
    if (depth > 20) return;
    root.querySelectorAll('*').forEach(el => {
      const txt = (el.childNodes.length && !el.querySelector('*')) ? (el.textContent||'').trim() : '';
      if (txt.length && txt.length < 80) out.push(txt);
      if (el.shadowRoot) walk(el.shadowRoot, depth+1);
    });
  };
  walk(document, 0);
  return out;
})()
'''
    return ev(ws, expr, 1) or []


def main():
    t = page_tab()
    ws = ws_for(t)
    ws.send(json.dumps({"id": 1, "method": "Page.navigate",
                        "params": {"url": "https://colab.research.google.com/"}}))
    time.sleep(10)

    # click Sign in
    r = ev(ws, "var el=document.querySelector('span.gb_ne'); if(el){el.click();'clicked'}else{'missing'}", 2)
    print("[driver] signin click:", r, flush=True)

    for i in range(24):
        time.sleep(5)
        ls = leaves(ws)
        emails = [x for x in ls if "@" in x and len(x) < 60]
        print(f"[driver] {i*5}s leaves={len(ls)} emails={emails[:4]}", flush=True)
        if emails:
            # click the account email in the chooser
            ev(ws, f'''
(() => {{
  const t = {json.dumps(emails[0])};
  let target = null;
  const walk = (root, depth) => {{
    if (depth > 20 || target) return;
    root.querySelectorAll('*').forEach(el => {{
      if (target) return;
      const txt = (el.childNodes.length && !el.querySelector('*')) ? (el.textContent||'').trim() : '';
      if (txt === t) target = el;
      if (el.shadowRoot) walk(el.shadowRoot, depth+1);
    }});
  }};
  walk(document, 0);
  if (target) {{ target.click(); 'clicked account' }} else {{ 'account element not found' }}
}})()
''', 3)
            print("[driver] account click result:", r, flush=True)
            break
        # if we are already on the signed-in home, break
        if any(x in ("New notebook", "Upload notebook", "Recent", "Google Drive", "Upload") for x in ls):
            print("[driver] colab home visible", flush=True)
            break

    time.sleep(10)
    ls = leaves(ws)
    print("[driver] final leaves:", ls[:60], flush=True)
    ws.close()


if __name__ == "__main__":
    main()
