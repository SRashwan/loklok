"""Windows side of the Colab CLI auth: open the URL, scrape the code, feed it."""
from __future__ import annotations

import subprocess
import time
import urllib.parse
from pathlib import Path

import requests

ROOT = Path(__file__).resolve().parents[2]
VDIR = ROOT / "07_validation"
URL_FILE = VDIR / "oauth_url.txt"
CODE_FILE = VDIR / "oauth_code.txt"
CLI_LOG = VDIR / "colab_new.log"
DRIVER_LOG = VDIR / "wsl_auth_driver.log"
CDP = "http://127.0.0.1:9222"

for p in (URL_FILE, CODE_FILE, CLI_LOG, DRIVER_LOG):
    p.unlink(missing_ok=True)

wsl_script = "/mnt/d/all_aywa/loklok-thesis-final-upgrade/02_code/colab/wsl_auth.py"
driver = open(DRIVER_LOG, "w", encoding="utf-8", buffering=1)
proc = subprocess.Popen(
    ["wsl", "-d", "Ubuntu", "--", "python3", wsl_script],
    stdout=driver,
    stderr=subprocess.STDOUT,
)
print("[driver] WSL auth process started", flush=True)


def tabs():
    try:
        return requests.get(f"{CDP}/json/list", timeout=5).json()
    except Exception:
        return []


def log_tail(path: Path, n: int = 40) -> str:
    try:
        return "\n".join(path.read_text(encoding="utf-8", errors="replace").splitlines()[-n:])
    except FileNotFoundError:
        return ""


url = None
deadline = time.time() + 150
while time.time() < deadline:
    if URL_FILE.exists():
        url = URL_FILE.read_text(encoding="utf-8").strip()
        if url:
            break
    if proc.poll() is not None:
        print("[driver] WSL process exited before URL", flush=True)
        print(log_tail(DRIVER_LOG), flush=True)
        print(log_tail(CLI_LOG), flush=True)
        raise SystemExit(1)
    time.sleep(2)

if not url:
    print("[driver] no URL file", flush=True)
    print(log_tail(DRIVER_LOG), flush=True)
    raise SystemExit(1)

print("[driver] opening URL in Chrome", flush=True)
requests.put(f"{CDP}/json/new?" + urllib.parse.quote(url, safe=""), timeout=10)
state = urllib.parse.parse_qs(urllib.parse.urlparse(url).query).get("state", [None])[0]
print("[driver] state", state, flush=True)

code = None
deadline = time.time() + 180
while time.time() < deadline:
    for t in tabs():
        u = t.get("url", "")
        if "applicationdefaultauthcode" in u:
            qs = urllib.parse.parse_qs(urllib.parse.urlparse(u).query)
            if qs.get("state", [""])[0] == state and qs.get("code"):
                code = qs["code"][0]
                break
    if code:
        break
    time.sleep(2)

if not code:
    print("[driver] no code found", flush=True)
    for t in tabs():
        print("  tab:", t.get("url", "")[:180], flush=True)
    print(log_tail(CLI_LOG), flush=True)
    raise SystemExit(1)

print("[driver] writing code", flush=True)
CODE_FILE.write_text(code, encoding="utf-8")

deadline = time.time() + 600
while time.time() < deadline:
    txt = log_tail(CLI_LOG, 200)
    if "Session READY" in txt or "Session terminated" in txt or "Traceback" in txt:
        break
    if proc.poll() is not None:
        break
    time.sleep(3)

print("[driver] CLI log tail:", flush=True)
print(log_tail(CLI_LOG, 80), flush=True)
print("[driver] driver log tail:", flush=True)
print(log_tail(DRIVER_LOG, 20), flush=True)
try:
    proc.wait(timeout=20)
except subprocess.TimeoutExpired:
    print("[driver] WSL process still alive", flush=True)
driver.close()
