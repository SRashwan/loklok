"""Create the Colab notebooks for the final thesis upgrade."""
from pathlib import Path
import nbformat as nbf


def md(text):
    return nbf.v4.new_markdown_cell(text)


def code(text):
    return nbf.v4.new_code_cell(text)


def make_full():
    nb = nbf.v4.new_notebook()
    nb.metadata["kernelspec"] = {"display_name": "Python 3", "language": "python", "name": "python3"}
    nb.metadata["language_info"] = {"name": "python", "version": "3.10"}
    nb.metadata["colab"] = {"provenance": []}
    nb.cells = [
        md(
            "# LOKLOK Thesis Final Upgrade — Full Run (T4 GPU)\n\n"
            "This notebook runs the final calibrated in-silico experiment, regenerates the "
            "figures, and packages the outputs. It is deterministic given the seed.\n\n"
            "**Runtime:** Google Colab, T4 GPU (or CPU fallback).\n"
            "**Expected time:** 1–3 minutes for the full 500-persona, 18-session run.\n"
            "**Outputs:** `03_data/model_outputs/`, `04_figures/`, and `loklok_outputs.zip`."
        ),
        md("## 1. Check the runtime"),
        code("!nvidia-smi || echo 'No GPU attached — the pipeline will use the NumPy CPU fallback.'"),
        md("## 2. Install dependencies"),
        code(
            "!pip -q install numpy scipy pandas matplotlib scikit-learn networkx nbformat\n"
            "import numpy, scipy, pandas, matplotlib, sklearn, networkx\n"
            "print('numpy', numpy.__version__)\n"
            "print('scipy', scipy.__version__)\n"
            "print('pandas', pandas.__version__)\n"
            "print('matplotlib', matplotlib.__version__)"
        ),
        md(
            "## 3. Upload or mount the package\n\n"
            "Option A: upload `colab_bundle.zip` from the package root. "
            "Option B: mount Google Drive and point `ROOT` at the synced folder."
        ),
        code(
            "from google.colab import files\n"
            "import os, zipfile, pathlib\n"
            "ROOT = pathlib.Path('/content/loklok-thesis-final-upgrade')\n"
            "if not ROOT.exists():\n"
            "    print('Please upload colab_bundle.zip (or skip and set ROOT to your Drive folder).')\n"
            "    up = files.upload()\n"
            "    for name in up:\n"
            "        with zipfile.ZipFile(name, 'r') as z:\n"
            "            z.extractall('/content')\n"
            "print('ROOT exists:', ROOT.exists())\n"
            "print(sorted(p.name for p in ROOT.iterdir())[:10] if ROOT.exists() else 'missing')"
        ),
        md("## 4. Run the final pipeline"),
        code(
            "import subprocess, sys\n"
            "cmd = [sys.executable, str(ROOT / '02_code' / 'pipeline' / 'loklok_pipeline.py'),\n"
            "       '--root', str(ROOT), '--n-personas', '500', '--sessions', '18', '--seed', '20261105']\n"
            "print(' '.join(cmd))\n"
            "subprocess.run(cmd, check=True)"
        ),
        md("## 5. Regenerate the publication figures"),
        code(
            "subprocess.run([sys.executable, str(ROOT / '02_code' / 'pipeline' / 'generate_figures.py'),\n"
            "                '--root', str(ROOT)], check=True)"
        ),
        md("## 6. Inspect key outputs"),
        code(
            "import json, pandas as pd\n"
            "res = json.loads((ROOT / '03_data' / 'model_outputs' / 'pipeline_results.json').read_text())\n"
            "fa = res['factorial']\n"
            "print('Delta SReval:', round(fa['delta_sr_eval']['mean'], 3), fa['delta_sr_eval']['ci_low'], fa['delta_sr_eval']['ci_high'])\n"
            "print('Delta SRcomp:', round(fa['delta_sr_comp']['mean'], 2))\n"
            "print('Delta engagement:', round(fa['delta_engagement']['mean'], 3))\n"
            "print('Sobol survival:', res['sensitivity']['survival_rate_pct'], '%')\n"
            "pd.DataFrame(fa['cell_means']).head()"
        ),
        md("## 7. Display the main figures"),
        code(
            "from IPython.display import Image, display\n"
            "for name in ['fig6_1_sr_distributions.png', 'fig6_2_factorial_cells.png',\n"
            "             'fig6_5_pareto_hamiltonian.png', 'fig6_7_forest.png',\n"
            "             'fig6_9_misinfo.png', 'fig6_10_sobol.png']:\n"
            "    p = ROOT / '04_figures' / 'png' / name\n"
            "    if p.exists():\n"
            "        display(Image(filename=str(p), width=850))"
        ),
        md("## 8. Package and download the outputs"),
        code(
            "import shutil\n"
            "zip_path = '/content/loklok_outputs'\n"
            "shutil.make_archive(zip_path, 'zip', root_dir=str(ROOT),\n"
            "                    base_dir='03_data/model_outputs')\n"
            "# include figures and generated tables too\n"
            "shutil.make_archive('/content/loklok_figures', 'zip', root_dir=str(ROOT), base_dir='04_figures')\n"
            "from google.colab import files\n"
            "files.download('/content/loklok_outputs.zip')\n"
            "files.download('/content/loklok_figures.zip')"
        ),
        md(
            "### Notes\n\n"
            "- The seed is fixed at **20261105**; rerunning should reproduce the same numbers.\n"
            "- The pipeline prints a hardware line (`PyTorch_CUDA` or `NumPy_CPU_Fallback`).\n"
            "- The Bayesian prior-sensitivity result is part of the output; do not select only the favourable prior.\n"
            "- All results are **model-based**. The measured N=52 wave is an anchor, not a treatment arm."
        ),
    ]
    return nb


def make_quick():
    nb = nbf.v4.new_notebook()
    nb.metadata["kernelspec"] = {"display_name": "Python 3", "language": "python", "name": "python3"}
    nb.metadata["language_info"] = {"name": "python", "version": "3.10"}
    nb.metadata["colab"] = {"provenance": []}
    nb.cells = [
        md(
            "# LOKLOK Thesis — Quick CPU Validation\n\n"
            "A fast smoke test of the final pipeline: 100 personas, 8 sessions, no Sobol sweep. "
            "Use this to confirm the archive runs before launching the full T4 notebook."
        ),
        code("!python --version; !nvidia-smi || true"),
        code(
            "!pip -q install numpy scipy pandas matplotlib scikit-learn networkx\n"
            "import numpy, scipy, pandas, matplotlib\n"
            "print('ok')"
        ),
        code(
            "from google.colab import files\n"
            "import pathlib, zipfile\n"
            "ROOT = pathlib.Path('/content/loklok-thesis-final-upgrade')\n"
            "if not ROOT.exists():\n"
            "    up = files.upload()\n"
            "    for name in up:\n"
            "        with zipfile.ZipFile(name, 'r') as z:\n"
            "            z.extractall('/content')\n"
            "print(ROOT.exists())"
        ),
        code(
            "import subprocess, sys\n"
            "subprocess.run([sys.executable, str(ROOT / '02_code' / 'pipeline' / 'loklok_pipeline.py'),\n"
            "                '--root', str(ROOT), '--n-personas', '100', '--sessions', '8',\n"
            "                '--seed', '20261105', '--skip-sensitivity'], check=True)"
        ),
        code(
            "import json\n"
            "r = json.loads((ROOT / '03_data' / 'model_outputs' / 'pipeline_results.json').read_text())\n"
            "print('Delta SReval', r['factorial']['delta_sr_eval']['mean'])\n"
            "print('Delta comp', r['factorial']['delta_sr_comp']['mean'])\n"
            "print('Delta engagement', r['factorial']['delta_engagement']['mean'])\n"
            "print('OK')"
        ),
    ]
    return nb


if __name__ == "__main__":
    here = Path(__file__).resolve().parent
    nbf.write(make_full(), str(here / "LOKLOK_Thesis_Full_Run_T4.ipynb"))
    nbf.write(make_quick(), str(here / "LOKLOK_Quick_Validate_CPU.ipynb"))
    print("notebooks written")
