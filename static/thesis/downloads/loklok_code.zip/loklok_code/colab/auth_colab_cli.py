"""Authenticate the official Colab CLI through the signed-in Chrome session.

Starts `colab new -s loklok --gpu T4` in WSL, captures the OAuth URL, opens it
in the Chrome instance on port 9222, reads the authorization code from the
resulting Google page, feeds it to the CLI, and waits for the session.
"""
from __future__ import annotations

import os
import re
import subprocess
import time
import urllib.parse
from pathlib import Path

import requests

ROOT = Path(__file__).resolve().parents[2]
LOG = ROOT / "07_validation" / "colab_new.log"
COLAB = "/home/sherifrashwan/.local/bin/colab"
CDP = "http://127.0.0.1:9222"


def read_text() -> str:
    try:
        return LOG.read_text(encoding="utf-8", errors="replace")
    except FileNotFoundError:
        return ""


def cdp_tabs():
    try:
        return requests.get(f"{CDP}/json/list", timeout=5).json()
    except Exception:
        return []


def open_url(url: str) -> None:
    requests.put(f"{CDP}/json/new?" + urllib.parse.quote(url, safe=""), timeout=10)


def main() -> int:
    if LOG.exists():
        LOG.unlink()
    r, w = os.pipe()
    log = open(LOG, "w", encoding="utf-8", buffering=1)
    cmd = [
        "wsl",
        "-d",
        "Ubuntu",
        "--",
        "env",
        "PYTHONUNBUFFERED=1",
        "COLUMNS=200",
        COLAB,
        "--auth=oauth2",
        "new",
        "-s",
        "loklok",
        "--gpu",
        "T4",
    ]
    print("[driver] starting:", " ".join(cmd), flush=True)
    p = subprocess.Popen(cmd, stdin=r, stdout=log, stderr=subprocess.STDOUT)
    os.close(r)

    auth_url = None
    state = None
    deadline = time.time() + 120
    while time.time() < deadline:
        text = read_text()
        m = re.search(r"https://accounts\.google\.com/o/oauth2/auth\?[^\s\r\n]+", text)
        if m:
            auth_url = m.group(0).rstrip('"')
            qs = urllib.parse.parse_qs(urllib.parse.urlparse(auth_url).query)
            state = qs.get("state", [None])[0]
            print("[driver] auth URL captured, state", state, flush=True)
            open_url(auth_url)
            break
        if p.poll() is not None:
            print("[driver] CLI exited before URL; log follows:", flush=True)
            print(read_text(), flush=True)
            return 1
        time.sleep(2)

    if not auth_url or not state:
        print("[driver] no auth URL found", flush=True)
        print(read_text(), flush=True)
        return 1

    code = None
    deadline = time.time() + 120
    while time.time() < deadline:
        for t in cdp_tabs():
            u = t.get("url", "")
            if "applicationdefaultauthcode" in u:
                qs = urllib.parse.parse_qs(urllib.parse.urlparse(u).query)
                if qs.get("state", [""])[0] == state and qs.get("code"):
                    code = qs["code"][0]
                    break
        if code:
            break
        time.sleep(2)

    if not code:
        print("[driver] no authorization code found; checking page state", flush=True)
        for t in cdp_tabs():
            print("  tab:", t.get("url", "")[:200], flush=True)
        print(read_text(), flush=True)
        return 1

    print("[driver] authorization code captured; sending to CLI", flush=True)
    os.write(w, (code + "\n").encode("utf-8"))
    os.close(w)

    deadline = time.time() + 420
    while time.time() < deadline:
        text = read_text()
        if "Session READY" in text or "Session terminated" in text or "Traceback" in text:
            break
        if p.poll() is not None:
            break
        time.sleep(3)

    text = read_text()
    print(text, flush=True)
    try:
        p.wait(timeout=30)
    except subprocess.TimeoutExpired:
        print("[driver] CLI still running; leaving it alive", flush=True)
    log.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
