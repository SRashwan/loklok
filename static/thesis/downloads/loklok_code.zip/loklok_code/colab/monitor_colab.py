"""Poll the running Colab notebook via CDP and log progress."""
import json
import time
from datetime import datetime
from pathlib import Path

import requests
import websocket

CDP = "http://127.0.0.1:9222"
NOTEBOOK_URL = "https://colab.research.google.com/drive/1RSLutqe_bgrx16vC1QPYrkv-TkFVVd_e"
LOG = Path(r"D:\all_aywa\loklok-thesis-final-upgrade\07_validation\colab_monitor.log")
DONE_MARKERS = ["Traceback", "loklok_v8_results.zip"]


def tabs():
    return requests.get(f"{CDP}/json/list", timeout=5).json()


def get_text():
    pages = [x for x in tabs() if x["type"] == "page"]
    if not pages:
        return None
    t = [x for x in pages if "colab.research.google.com" in x["url"]]
    if not t:
        t = [pages[0]]
        ws = websocket.create_connection(t[0]["webSocketDebuggerUrl"], timeout=15)
        ws.send(json.dumps({"id": 1, "method": "Page.navigate",
                            "params": {"url": NOTEBOOK_URL}}))
        ws.close()
        return "navigating"
    t = t[0]
    ws = websocket.create_connection(t["webSocketDebuggerUrl"], timeout=15)
    expr = r"""(() => {
      const outs = [...document.querySelectorAll('colab-static-output-renderer')].map(e => e.innerText || '').filter(x => x.trim());
      const status = (document.querySelector('colab-execution-status') || {}).innerText || '';
      const run = (document.querySelector('colab-runtime-status') || {}).innerText || '';
      return (status ? '[status: ' + status + '] ' : '') + (run ? '[runtime: ' + run + '] ' : '') + outs.join('\n---\n');
    })()"""
    ws.send(json.dumps({"id": 1, "method": "Runtime.evaluate",
                        "params": {"expression": expr, "returnByValue": True}}))
    m = json.loads(ws.recv())
    ws.close()
    return m.get("result", {}).get("result", {}).get("value")


def main():
    start = time.time()
    last = ""
    while time.time() - start < 7200:
        try:
            txt = get_text()
        except Exception as e:
            txt = None
            print(datetime.now().isoformat(timespec="seconds"), "CDP error:", str(e)[:120], flush=True)
        if txt is None:
            time.sleep(30)
            continue
        tail = txt[-2000:].replace("\u00a0", " ")
        if tail != last:
            last = tail
            with open(LOG, "a", encoding="utf-8") as fh:
                fh.write(f"=== {datetime.now().isoformat(timespec='seconds')} ===\n{tail}\n")
            print(datetime.now().isoformat(timespec="seconds"), "updated:", tail[-160:].replace("\n", " | "), flush=True)
        dl = Path(r"D:\all_aywa\loklok-thesis-final-upgrade\colab_downloads")
        zips = list(dl.glob("*.zip")) if dl.exists() else []
        if zips:
            print("DOWNLOADED:", [z.name for z in zips], flush=True)
            break
        if "Traceback" in tail:
            print("TRACEBACK SEEN", flush=True)
        time.sleep(45)
    print("monitor exit", flush=True)


if __name__ == "__main__":
    main()
