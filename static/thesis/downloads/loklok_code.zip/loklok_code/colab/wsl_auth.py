"""Run the official Colab CLI under a PTY, capture the OAuth URL, and feed the code.

This script runs inside WSL. It writes the OAuth URL and the CLI log to the
shared Windows path, then waits for the Windows-side driver to write the
authorization code to oauth_code.txt.
"""
from __future__ import annotations

import os
import pty
import re
import select
import subprocess
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
OUT = Path("/mnt/d/all_aywa/loklok-thesis-final-upgrade/07_validation")
OUT.mkdir(parents=True, exist_ok=True)
DEBUG = OUT / "wsl_auth_debug.log"
def dbg(msg):
    with open(DEBUG, "a", encoding="utf-8") as fh:
        fh.write(str(msg) + "\n")
dbg("start")
URL_FILE = OUT / "oauth_url.txt"
CODE_FILE = OUT / "oauth_code.txt"
LOG_FILE = OUT / "colab_new.log"
for p in (URL_FILE, CODE_FILE):
    p.unlink(missing_ok=True)

COLAB = "/home/sherifrashwan/.local/bin/colab"
args = [
    COLAB,
    "--auth=oauth2",
    "new",
    "-s",
    "loklok",
    "--gpu",
    "T4",
]

dbg("opening pty")
master, slave = pty.openpty()
env = dict(os.environ)
env.update({"PYTHONUNBUFFERED": "1", "COLUMNS": "200", "TERM": "xterm-256color"})
dbg("spawning colab")
proc = subprocess.Popen(
    args,
    stdin=slave,
    stdout=slave,
    stderr=slave,
    close_fds=True,
    env=env,
)
dbg("spawned pid %s" % proc.pid)
os.close(slave)

log = open(LOG_FILE, "wb", buffering=0)
buf = b""
url = None
deadline = time.time() + 120
while time.time() < deadline and url is None:
    r, _, _ = select.select([master], [], [], 1.0)
    if not r:
        if proc.poll() is not None:
            break
        continue
    try:
        chunk = os.read(master, 4096)
    except OSError:
        break
    if not chunk:
        break
    log.write(chunk)
    buf += chunk
    dbg("chunk %d bytes; total %d" % (len(chunk), len(buf)))
    m = re.search(rb"https://accounts\.google\.com/o/oauth2/auth\?[^\s\x1b\r\n]+", buf)
    if m:
        url = m.group(0).decode("utf-8", "replace")
        URL_FILE.write_text(url, encoding="utf-8")
        dbg("url found")
        break

if url is None:
    dbg("no url; proc rc=%s; tail=%r" % (proc.poll(), buf[-500:]))
    log.write(b"\n[driver] no auth URL found\n")
    log.close()
    raise SystemExit(1)

code = None
deadline = time.time() + 240
while time.time() < deadline:
    if CODE_FILE.exists():
        code = CODE_FILE.read_text(encoding="utf-8").strip()
        if code:
            break
    time.sleep(1)
if not code:
    log.write(b"\n[driver] no authorization code file\n")
    log.close()
    raise SystemExit(1)

os.write(master, (code + "\n").encode("utf-8"))

deadline = time.time() + 600
while time.time() < deadline:
    r, _, _ = select.select([master], [], [], 1.0)
    if r:
        try:
            chunk = os.read(master, 4096)
        except OSError:
            break
        if not chunk:
            break
        log.write(chunk)
    if proc.poll() is not None:
        break
    txt = LOG_FILE.read_text(encoding="utf-8", errors="replace") if LOG_FILE.exists() else ""
    if "Session READY" in txt or "Session terminated" in txt or "Traceback" in txt:
        # drain a little and stop
        time.sleep(3)
        break

try:
    proc.wait(timeout=20)
except subprocess.TimeoutExpired:
    log.write(b"\n[driver] CLI still running; leaving session\n")
log.close()
