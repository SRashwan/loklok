#!/usr/bin/env bash
cd /mnt/d/all_aywa/loklok-thesis-final-upgrade/07_validation
python3 -u /mnt/d/all_aywa/loklok-thesis-final-upgrade/02_code/colab/wsl_auth.py > wsl_stdout.log 2>&1
echo "RC=$?" >> wsl_stdout.log
