"""Create the Colab bundle for the v8 original-data / LLM-embedding run."""
from pathlib import Path
import zipfile

root = Path(__file__).resolve().parents[2]
out = root / "colab_bundle_v8.zip"

files = [
    "README_V8.md",
    "02_code/pipeline/loklok_pipeline.py",
    "02_code/pipeline/loklok_pipeline_v8.py",
    "02_code/pipeline/zewail_ablation.py",
    "02_code/pipeline/anchor_bootstrap.py",
    "02_code/pipeline/balance_analysis.py",
    "02_code/pipeline/source_ablation.py",
    "02_code/pipeline/filter_ablation.py",
    "02_code/pipeline/generate_figures.py",
    "02_code/pipeline/make_r_macros.py",
    "02_code/pipeline/requirements_v8.txt",
    "03_data/raw/survey_answers_real.csv",
    "03_data/raw/realsurveydata_inclusive.csv",
    "03_data/raw/FGD_transcription.csv",
    "03_data/raw/topics_25_arabic.txt",
    "03_data/raw/RealStudentsProfiles.txt",
    "03_data/raw/realsurveydata_inclusive.csv",
    "03_data/qualitative/selfreport/selfreport_transcript.json",
    "03_data/qualitative/selfreport/selfreport_transcript.txt",
    "03_data/model_outputs/embeddings/embeddings_0f6c66e54fb6ca2c.npy",
]
dirs = [
    "03_data/qualitative/corpora",
    "03_data/qualitative/selfreport",
    "03_data/measured",
    "01_thesis/src/generated",
]

with zipfile.ZipFile(out, "w", compression=zipfile.ZIP_DEFLATED) as z:
    for rel in files:
        p = root / rel
        if p.exists():
            z.write(p, arcname=f"loklok_v8/{rel}")
        else:
            print("MISSING", rel)
    for rel in dirs:
        p = root / rel
        if p.is_dir():
            for f in p.rglob("*"):
                if f.is_file():
                    z.write(f, arcname=f"loklok_v8/{f.relative_to(root).as_posix()}")
    # ensure empty output dirs exist in the archive
    z.writestr("loklok_v8/01_thesis/src/generated/.keep", "")
    z.writestr("loklok_v8/01_thesis/src/figures/.keep", "")
    z.writestr("loklok_v8/04_figures/png/.keep", "")
    z.writestr("loklok_v8/04_figures/pdf/.keep", "")
    z.writestr("loklok_v8/04_figures/source_data/.keep", "")
    z.writestr("loklok_v8/03_data/measured/.keep", "")
    z.writestr("loklok_v8/03_data/model_outputs/embeddings/.keep", "")
    z.writestr("loklok_v8/03_data/qualitative/selfreport/.keep", "")
print(out, out.stat().st_size)
