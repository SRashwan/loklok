# Master runner: executes 01..05 in isolated R processes and prints the
# measured-statistics report. Each step runs in a fresh session so lavaan and
# psych never share attach-order state, and every output is reproducible.
RS <- file.path(R.home("bin"), "Rscript.exe")
if (!file.exists(RS)) RS <- "Rscript"
SCRIPTS <- c("R/01_descriptives.R",
             "R/02_psychometrics.R",
             "R/03_associations.R",
             "R/04_cfa.R",
             "R/05_report.R",
             "R/06_bayesian.R")
for (s in SCRIPTS) {
  cat("==>", s, "...\n")
  code <- tryCatch(
    system2(RS, c("--vanilla", shQuote(s)), stdout = TRUE, stderr = TRUE),
    warning = function(w) NA,
    error = function(e) sprintf("FAILED: %s", conditionMessage(e))
  )
  if (length(code) && any(grepl("Execution halted|Error", code,
                                ignore.case = TRUE))) {
    cat(paste(code, collapse = "\n"), "\n")
    stop(sprintf("Pipeline aborted at %s", s))
  }
  cat(paste(code[!grepl("Execution halted|Rscript.exe", code)],
            collapse = "\n"), "\n")
}
cat("\n--- R analysis complete. See thesis_data/analysis/ ---\n")