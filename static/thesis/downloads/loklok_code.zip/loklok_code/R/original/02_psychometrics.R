# 02 - Internal-consistency reliability (Cronbach alpha, McDonald omega)
#       and corrected item-total correlations (r.drop).
library(psych)
source("R/00_setup.R")
d <- read_respondents()

scales <- list(
  BRS_total = c("BR1","BR2","BR3","BR4_reversed","SV1","SV2","SV3","SV4",
                "IQ1","IQ2","IQ3"),
  BR_sub    = c("BR1","BR2","BR3","BR4_reversed"),
  SV_sub    = c("SV1","SV2","SV3","SV4"),
  IQ_sub    = c("IQ1","IQ2","IQ3"),
  PB_comp   = c("PB1","PB2","PB3","PB4","PB5")
)

omega1 <- function(dat) {
  # McDonald's omega from a principal-axis single-factor solution.
  fit <- suppressWarnings(factanal(dat, factors = 1, rotation = "none",
                                   scores = "none"))
  l <- as.numeric(fit$loadings[, 1])
  round(sum(l)^2 / (sum(l)^2 + sum(1 - l^2)), 3)
}

alpha_r <- function(dat) {
  a <- psych::alpha(dat, check.keys = FALSE, warnings = FALSE)
  ot <- tryCatch(a$total$omega.tot, error = function(e) NA_real_)
  if (!is.numeric(ot) || length(ot) == 0 || is.na(ot)) ot <- NA_real_
  list(alpha_total = round(a$total$raw_alpha, 3),
       omega_total  = round(ot, 3),
       r_drop_lo    = round(min(a$item$r.drop, na.rm = TRUE), 3),
       r_drop_hi    = round(max(a$item$r.drop, na.rm = TRUE), 3),
       r_drop       = round(a$item$r.drop, 3))
}

res <- list()
for (nm in names(scales)) {
  dat <- as.data.frame(d[scales[[nm]]])
  res[[nm]] <- alpha_r(dat)
  res[[nm]]$omega_bpa <- omega1(dat)
  res[[nm]]$n_items <- length(scales[[nm]])
}
save_json(res, file.path(OUT_DIR, "psychometrics.json"))
df <- do.call(rbind, lapply(names(res), function(nm)
  data.frame(scale = nm, n_items = res[[nm]]$n_items,
             alpha = res[[nm]]$alpha_total,
             omega_tot = res[[nm]]$omega_total,
             omega_bpa = res[[nm]]$omega_bpa,
             r_drop_lo = res[[nm]]$r_drop_lo,
             r_drop_hi = res[[nm]]$r_drop_hi)))
write.csv(df, file.path(OUT_DIR, "psychometrics.csv"), row.names = FALSE)
print(df, row.names = FALSE)