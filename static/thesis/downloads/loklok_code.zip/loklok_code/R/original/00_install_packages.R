# One-time dependency installation. Needs internet. Run once; harmless to re-run.
options(repos = c(CRAN = "https://cloud.r-project.org"))
pkgs <- c("psych", "lavaan", "jsonlite")
need <- pkgs[!pkgs %in% rownames(installed.packages())]
if (length(need) > 0) {
  install.packages(need, Ncpus = 2, quiet = TRUE)
}
invisible(lapply(pkgs, requireNamespace, quietly = TRUE))
cat("Packages ready:", paste(pkgs, collapse = ", "), "\n")