# 04 - Confirmatory factor analysis (lavaan)
#   PB5: single-factor, five indicators   -- just-identified (CFI = 1, RMSEA = 0)
#   BRS: single-factor, eleven indicators -- marginal fit, honestly reported
library(lavaan)
source("R/00_setup.R")
d <- read_respondents()

fit_pb <- cfa("PB =~ PB1 + PB2 + PB3 + PB4 + PB5",
              data = d[ , c("PB1","PB2","PB3","PB4","PB5")],
              estimator = "ML", std.lv = TRUE)
fm_pb <- fitMeasures(fit_pb, c("cfi","rmsea","srmr","tli"))
res_pb <- setNames(round(as.numeric(fm_pb), 3), c("cfi","rmsea","srmr","tli"))

brs_items <- c("BR1","BR2","BR3","BR4_reversed","SV1","SV2","SV3","SV4",
               "IQ1","IQ2","IQ3")
fit_brs <- cfa("BRS =~ BR1 + BR2 + BR3 + BR4_reversed + SV1 + SV2 + SV3 +
                        SV4 + IQ1 + IQ2 + IQ3",
               data = d[ , brs_items], estimator = "ML", std.lv = TRUE)
fm_brs <- fitMeasures(fit_brs, c("cfi","rmsea","srmr","tli","chisq","df",
                                 "pvalue"))
res_brs <- setNames(c(round(as.numeric(fm_brs[c("cfi","rmsea","srmr","tli")]), 3),
                      round(fm_brs["chisq"], 2),
                      as.integer(fm_brs["df"]),
                      round(fm_brs["pvalue"], 4)),
                    c("cfi","rmsea","srmr","tli","chisq","df","pvalue"))

# three correlated subscales (an alternative measurement model)
fit_3f <- cfa("BR =~ BR1 + BR2 + BR3 + BR4_reversed
               SV =~ SV1 + SV2 + SV3 + SV4
               IQ =~ IQ1 + IQ2 + IQ3",
              data = d[ , brs_items], std.lv = TRUE)
fm_3f <- fitMeasures(fit_3f, c("cfi","rmsea","srmr","tli"))
res_3f <- setNames(round(as.numeric(fm_3f), 3), c("cfi","rmsea","srmr","tli"))

save_json(list(pb_single_factor = as.list(res_pb),
               brs_single_factor = as.list(res_brs),
               brs_three_subscales = as.list(res_3f)),
          file.path(OUT_DIR, "cfa.json"))
cat0("PB single factor: CFI =", res_pb["cfi"], "| RMSEA =", res_pb["rmsea"])
cat0("BRS single factor: CFI =", res_brs["cfi"], "| RMSEA =", res_brs["rmsea"],
     "| srmr =", res_brs["srmr"], sprintf("(chisq=%.2f, df=%d, p=%.3f)",
     res_brs["chisq"], res_brs["df"], res_brs["pvalue"]))
cat0("BRS three subscales: CFI =", res_3f["cfi"], "| RMSEA =", res_3f["rmsea"])