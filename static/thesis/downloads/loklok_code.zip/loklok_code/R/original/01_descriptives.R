# 01 - Sample description and descriptive statistics (measured wave, N = 52)
source("R/00_setup.R")
if (!requireNamespace("jsonlite", quietly = TRUE)) stop("jsonlite missing")
d <- read_respondents()

out <- list(
  n_total_collected          = 60L,
  n_refined                  = nrow(d),
  n_duplicate_vectors_removed = 8L,
  gender                     = as.list(table(d$gender_label)),
  n_universities             = length(unique(d$university_label)),
  university_counts          = as.list(table(d$university_label)),
  pb_mean                    = round(mean(d$PB_SCALE), 3),
  pb_sd                      = round(sd(d$PB_SCALE), 3),
  star_mean                  = round(mean(d$star_rating), 2),
  star_distribution          = as.list(table(d$star_rating)),
  duration_min               = min(d$ride_duration_minutes),
  duration_max               = max(d$ride_duration_minutes),
  interaction_ordinal        = as.list(table(d$interaction_ordinal))
)

# dose-response: mean PB by interaction level
grp <- aggregate(PB_SCALE ~ interaction_level + interaction_ordinal, data = d,
                 FUN = function(v) round(mean(v), 2))
grp$n <- as.integer(table(d$interaction_level)[match(grp$interaction_level,
                                                     names(table(d$interaction_level)))])
grp <- grp[order(grp$interaction_ordinal), ]
out$pb_by_interaction <- grp[c("interaction_ordinal","interaction_level",
                               "PB_SCALE","n")]

save_json(out, file.path(OUT_DIR, "descriptives.json"))
write.csv(grp, file.path(OUT_DIR, "pb_by_interaction.csv"), row.names = FALSE)

cat0("N refined =", nrow(d), "| gender:",
     paste(names(out$gender), out$gender, collapse = ", "))
cat0("PB mean (SD) =", out$pb_mean, "(", out$pb_sd, ") | star mean =",
     out$star_mean)
cat0("Interaction gradient:")
print(grp, row.names = FALSE)