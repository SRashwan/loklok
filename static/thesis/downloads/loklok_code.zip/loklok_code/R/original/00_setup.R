# =============================================================================
# LOKLOK thesis -- R statistics pipeline
# Author: Sherif Rashwan (thesis data package)
#
# Run order:
#   Rscript R/00_install_packages.R   (one-time, requires internet)
#   Rscript R/run_all.R               (runs 01..05 and writes all outputs)
#
# All scripts read from thesis_data/ and write into thesis_data/analysis/.
# Every number produced here is the measured number used in the thesis.
# =============================================================================

options(encoding = "UTF-8")
options(warn = 1)
set.seed(42)

DATA_DIR   <- "thesis_data"
OUT_DIR    <- file.path(DATA_DIR, "analysis")
RESP       <- file.path(DATA_DIR, "respondents.csv")

dir.create(OUT_DIR, showWarnings = FALSE, recursive = TRUE)

# --- Load participants -------------------------------------------------------
read_respondents <- function() {
  suppressWarnings(
    x <- read.csv(RESP, header = TRUE, check.names = FALSE,
                  stringsAsFactors = FALSE, fileEncoding = "UTF-8")
  )
  # BR4 is reverse keyed on the raw 0-4 scale; keep both raw and reversed.
  x$BR4_reversed <- 4 - x$BR4
  x$BR_SCALE  <- rowMeans(x[c("BR1","BR2","BR3","BR4_reversed")])
  x$SV_SCALE  <- rowMeans(x[c("SV1","SV2","SV3","SV4")])
  x$IQ_SCALE  <- rowMeans(x[c("IQ1","IQ2","IQ3")])
  x$PB_SCALE  <- rowMeans(x[c("PB1","PB2","PB3","PB4","PB5")])
  x
}

save_json <- function(obj, file) {
  con <- file(file, "w", encoding = "UTF-8")
  writeLines(jsonlite::toJSON(obj, auto_unbox = TRUE, na = "string",
                              pretty = TRUE), con, useBytes = TRUE)
  close(con)
}

cat0 <- function(...) cat(..., "\n")