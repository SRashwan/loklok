# 05 - Power analysis (paired t-test) and consolidated report
source("R/00_setup.R")

power_paired_t <- function(d = 0.40, alpha = 0.05, power = 0.80) {
  # t-based paired power (power.t.test, one group) -- matches the thesis n=52.
  pt <- power.t.test(delta = d, sd = 1, sig.level = alpha, power = power,
                     type = "paired", alternative = "two.sided")
  n <- ceiling(pt$n)
  list(assumed_d = d, alpha = alpha, power = power,
       required_n = n,
       required_n_exact = round(pt$n, 1),
       attrition_allowance_15pct = ceiling(n * 1.15))
}

pw <- power_paired_t()
cat0("Paired t-test power: n =", pw$required_n, "-> planning N =",
     pw$attrition_allowance_15pct, "(15% attrition)")

# --- Consolidate all analysis artifacts into one summary --------------------
parts <- c("descriptives.json","psychometrics.json","associations.json",
           "cfa.json")
summary_list <- lapply(parts, function(f) {
  jsonlite::fromJSON(file.path(OUT_DIR, f))
})
names(summary_list) <- sub("\\.json$", "", parts)
summary_list$power_analysis <- pw
summary_list$generated_by_r <- paste0("R ", paste(R.version$major,
                                                  R.version$minor, sep = "."))
summary_list$packages <- list(psych = as.character(packageVersion("psych")),
                              lavaan = as.character(packageVersion("lavaan")))
summary_list$data_package <- normalizePath(DATA_DIR)
summary_list$n_refined <- nrow(read_respondents())

con <- file(file.path(OUT_DIR, "results_summary.json"), "w", encoding = "UTF-8")
writeLines(jsonlite::toJSON(summary_list, auto_unbox = TRUE, pretty = TRUE,
                            na = "string"), con, useBytes = TRUE)
close(con)

# Human-readable report comparing computed numbers to the thesis claims.
md <- c(
  "# LOKLOK measured statistics (R pipeline)",
  "",
  sprintf("- R version: %s; psych %s; lavaan %s",
          summary_list$generated_by_r, summary_list$packages$psych,
          summary_list$packages$lavaan),
  sprintf("- N collected = 60, duplicate-vector removals = 8, refined N = %d",
          summary_list$n_refined),
  sprintf("- PB composite mean = %g (SD %g); star mean = %g",
          summary_list$descriptives$pb_mean, summary_list$descriptives$pb_sd,
          summary_list$descriptives$star_mean),
  "",
  "## Reliability",
  ""
)
for (nm in names(summary_list$psychometrics)) {
  p <- summary_list$psychometrics[[nm]]
  md <- c(md, sprintf(paste0("- %s (%d items): alpha = %.3f, ",
                             "omega_bpa = %.3f, r.drop range %.3f - %.3f"),
                      nm, p$n_items, p$alpha_total,
                      p$omega_bpa, p$r_drop_lo, p$r_drop_hi))
}
md <- c(md, "",
  "## Associations (Spearman rho)",
  sprintf("- star-PB = %g (p = %g)", summary_list$associations$star_pb,
          summary_list$associations$p_star_pb),
  sprintf("- interaction-PB = %g", summary_list$associations$interaction_pb),
  sprintf("- duration-PB = %g", summary_list$associations$duration_pb),
  sprintf("- BR-PB = %g | SV-PB = %g | IQ-PB = %g",
          summary_list$associations$br_pb, summary_list$associations$sv_pb,
          summary_list$associations$iq_pb),
  "",
  "## CFA",
  sprintf("- PB single factor: CFI = %g, RMSEA = %g",
          summary_list$cfa$pb_single_factor$cfi,
          summary_list$cfa$pb_single_factor$rmsea),
  sprintf("- BRS single factor: CFI = %g, RMSEA = %g, SRMR = %g",
          summary_list$cfa$brs_single_factor$cfi,
          summary_list$cfa$brs_single_factor$rmsea,
          summary_list$cfa$brs_single_factor$srmr),
  sprintf("- BRS three subscales: CFI = %g, RMSEA = %g, SRMR = %g",
          summary_list$cfa$brs_three_subscales$cfi,
          summary_list$cfa$brs_three_subscales$rmsea,
          summary_list$cfa$brs_three_subscales$srmr)
)
writeLines(md, file.path(OUT_DIR, "results_report.md"), useBytes = TRUE)
cat0("Wrote thesis_data/analysis/results_summary.json and results_report.md")