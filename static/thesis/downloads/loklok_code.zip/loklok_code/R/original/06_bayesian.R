# =============================================================================
# LOKLOK thesis -- Bayesian SR' consensus + EST validation (base-R cross-check)
#
# Independent base-R re-implementation of governance/bayes.py's
#   sr_consensus_posterior() + est_validation():
#   * Beta-Binomial posterior for P(SR' >= 0.70) per arm (closed form)
#   * posterior of delta = theta_A - theta_B  (Monte Carlo, fixed seed)
#   * HDI (highest posterior density), ROPE cover, ROPE Bayes factor
#   * posterior predictive check of the binomial success counts
#   * Bayesian (Metropolis-Hastings) regression of SR' on EST diversity DPI
# Uses only base R (+ stats). Outputs are written to thesis_data/analysis/.
# =============================================================================

options(encoding = "UTF-8")
options(warn = 1)
set.seed(20260910)

METRICS <- "data/engine/session_metrics.csv"
OUT_DIR <- "thesis_data/analysis"
dir.create(OUT_DIR, showWarnings = FALSE, recursive = TRUE)

sessions <- read.csv(METRICS, check.names = FALSE, stringsAsFactors = FALSE)

agg <- aggregate(list(att = sessions$Att_composite,
                      dpi = sessions$DPI),
                 by = list(uid = sessions$participant_id), FUN = mean)
agg$arm <- vapply(agg$uid, function(u) {
  unique(sessions$arm[sessions$participant_id == u])[1]
}, character(1))
agg$sr <- agg$att
agg$hit70 <- as.integer(agg$sr >= 0.70)
agg$hit50 <- as.integer(agg$sr >= 0.50)

armA <- agg[agg$arm == "A", ]
armB <- agg[agg$arm == "B", ]

hdi <- function(x, prob = 0.95) {
  x <- sort(x)
  n <- length(x)
  k <- floor(prob * n)
  w <- x[(k + 1):n] - x[1:(n - k)]
  i <- which.min(w)
  c(low = x[i], high = x[i + k])
}

posterior_draws <- function(y, n, a0 = 2, b0 = 2, draws = 40000) {
  rbeta(draws, a0 + y, b0 + n - y)
}

summarize_posterior <- function(th) {
  c(mean = mean(th), sd = sd(th),
    p_above70 = mean(th >= 0.70), p_above50 = mean(th >= 0.50))
}

thA <- posterior_draws(sum(armA$hit70), nrow(armA))
thB <- posterior_draws(sum(armB$hit70), nrow(armB))
postA <- summarize_posterior(thA)
postB <- summarize_posterior(thB)
hdiA <- hdi(thA)
hdiB <- hdi(thB)

delta <- thA - thB
rho <- 0.05
rope_cover <- mean(abs(delta) <= rho)
prior_delta <- rbeta(40000, 2, 2) - rbeta(40000, 2, 2)
bf01 <- (mean(abs(delta) <= rho) / (1 - mean(abs(delta) <= rho) + 1e-9)) /
        (mean(abs(prior_delta) <= rho) / (1 - mean(abs(prior_delta) <= rho) + 1e-9))
bf10 <- 1 / bf01
hdiDelta <- hdi(delta)
p_pos <- mean(delta > 0)

verdict <- if (hdiDelta[1] > 0 && rope_cover < 0.05 && p_pos >= 0.95 && bf10 >= 3) {
  "SUPPORTED"
} else if ((hdiDelta[1] > 0 || hdiDelta[2] < 0) && p_pos >= 0.8 && bf10 >= 3) {
  "MODERATE"
} else if (rope_cover >= 0.5) {
  "PENDING"
} else if (!is.na(bf10) && bf10 >= 10) {
  "MODERATE"
} else if (!is.na(bf10) && bf10 >= 3) {
  "ANECDOTAL"
} else {
  "ANECDOTAL"
}

# PPC: replications of binomial success counts under the posteriors
set.seed(20260911)
ppcA <- rbinom(40000, nrow(armA), rbeta(40000, 2 + sum(armA$hit70),
                                        2 + nrow(armA) - sum(armA$hit70)))
ppcB <- rbinom(40000, nrow(armB), rbeta(40000, 2 + sum(armB$hit70),
                                        2 + nrow(armB) - sum(armB$hit70)))
pval <- function(yrep, y) min(mean(yrep >= y), mean(yrep <= y)) * 2

# Bayesian regression SR' ~ DPI  (random-walk Metropolis-Hastings)
x <- agg$dpi - mean(agg$dpi)
y <- agg$sr
n <- length(y)
lm0 <- lm(y ~ x)
b0 <- coef(lm0)[["x"]]; m0 <- coef(lm0)[["(Intercept)"]] + mean(agg$dpi) * b0
init <- c(b0, m0, log(ifelse(is.na(sd(resid(lm0))), 1, sd(resid(lm0)))))
loglike <- function(p) {
  b <- p[1]; mu <- p[2]; ls <- p[3]
  sig <- exp(ls)
  ll <- -n * log(sig) - 0.5 * sum(((y - mu - b * x) / sig)^2)
  ll - 0.5 * (b / 1.0)^2 - 0.5 * ((mu - mean(y)) / 5)^2 - 0.5 * ls^2
}
set.seed(20260912)
par <- init; ll <- loglike(par)
step <- c(0.02, 0.02, 0.05)
chain <- numeric(30000)
accept <- 0
for (i in 1:(500 + 30000)) {
  prop <- par + rnorm(3, 0, step)
  llp <- loglike(prop)
  if (runif(1) < exp(llp - ll)) {
    par <- prop; ll <- llp; accept <- accept + 1
  }
  if (i > 500) chain[i - 500] <- par[1]
}
b_hdi <- hdi(chain)
b_p_pos <- mean(chain > 0)
b_rope <- mean(abs(chain) <= 0.05)
prior_b <- rnorm(40000, 0, 1)
bf01b <- (mean(abs(chain) <= 0.05) / (1 - mean(abs(chain) <= 0.05) + 1e-9)) /
         (mean(abs(prior_b) <= 0.05) / (1 - mean(abs(prior_b) <= 0.05) + 1e-9))
bf10b <- 1 / bf01b

cat("=============================================================\n")
cat("BAYESIAN SR' CONSENSUS (base-R cross-check)  n =", nrow(agg), "\n")
cat("-------------------------------------------------------------\n")
cat(sprintf("Arm A: n=%d hit@0.70=%d srMean=%.4f | post mean=%.3f HDI95=[%.3f, %.3f] p(>=0.70)=%.3f\n",
            nrow(armA), sum(armA$hit70), mean(armA$sr),
            postA["mean"], hdiA[1], hdiA[2], postA["p_above70"]))
cat(sprintf("Arm B: n=%d hit@0.70=%d srMean=%.4f | post mean=%.3f HDI95=[%.3f, %.3f] p(>=0.70)=%.3f\n",
            nrow(armB), sum(armB$hit70), mean(armB$sr),
            postB["mean"], hdiB[1], hdiB[2], postB["p_above70"]))
cat(sprintf("delta A-B: mean=%.4f HDI95=[%.4f, %.4f] P(delta>0)=%.3f ROPE=%.3f BF10=%.3f -> %s\n",
            mean(delta), hdiDelta[1], hdiDelta[2], p_pos, rope_cover,
            bf10, verdict))
cat(sprintf("PPC two-sided p: ArmA=%.3f ArmB=%.3f\n",
            pval(ppcA, sum(armA$hit70)), pval(ppcB, sum(armB$hit70))))
cat("-------------------------------------------------------------\n")
cat("EST VALIDATION (SR' ~ DPI, MH regression)\n")
cat(sprintf("slope mean=%.4f HDI95=[%.4f, %.4f] P(b>0)=%.3f ROPE=%.3f BF10=%.3f acept=%.3f\n",
            mean(chain), b_hdi[1], b_hdi[2], b_p_pos, b_rope, bf10b,
            accept / (500 + 30000)))
cat("=============================================================\n")

# --- portable JSON portrait (hand-rolled, base R only) ---------------------
q <- function(s) {
  paste0('"', gsub('"', '\\"', s, fixed = TRUE), '"')
}
json_vec <- function(v) paste0("[", v[1], ", ", v[2], "]")
rows <- c(
  paste0(q("nParticipants"), ":", nrow(agg)),
  paste0(q("armA"), ':', paste0('{"n":', nrow(armA), ',"y70":', sum(armA$hit70),
    ',"posteriorMean":', round(postA["mean"], 4),
    ',"hdi95":', json_vec(hdiA), ',"pAbove70":', round(postA["p_above70"], 4), "}")),
  paste0(q("armB"), ':', paste0('{"n":', nrow(armB), ',"y70":', sum(armB$hit70),
    ',"posteriorMean":', round(postB["mean"], 4),
    ',"hdi95":', json_vec(hdiB), ',"pAbove70":', round(postB["p_above70"], 4), "}")),
  paste0(q("deltaA_B"), ':', paste0('{"mean":', round(mean(delta), 4),
    ',"hdi95":', json_vec(hdiDelta), ',"pPositive":', round(p_pos, 4),
    ',"ropeCover":', round(rope_cover, 4), ',"bf10":', round(bf10, 3),
    ',"verdict":', q(verdict), "}")),
  paste0(q("ppc"), ':', paste0('{"armA_p":', round(pval(ppcA, sum(armA$hit70)), 3),
    ',"armB_p":', round(pval(ppcB, sum(armB$hit70)), 3), "}")),
  paste0(q("estSlope"), ':', paste0('{"mean":', round(mean(chain), 4),
    ',"hdi95":', json_vec(b_hdi), ',"pPositive":', round(b_p_pos, 4),
    ',"ropeCover":', round(b_rope, 4), ',"bf10":', round(bf10b, 3), "}"))
)
json_out <- paste0("{\n  ", paste(rows, collapse = ",\n  "), "\n}\n")
writeLines(json_out, file.path(OUT_DIR, "bayes_sr_results_R.json"))
cat("wrote", file.path(OUT_DIR, "bayes_sr_results_R.json"), "\n")