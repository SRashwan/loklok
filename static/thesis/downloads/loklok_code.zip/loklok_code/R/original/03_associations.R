# 03 - Convergent and behavioural associations (Spearman rho)
library(psych)
source("R/00_setup.R")
d <- read_respondents()

rho <- function(a, b) {
  round(suppressWarnings(cor(a, b, method = "spearman", use = "complete.obs")), 3)
}

stats <- list(
  star_pb              = rho(d$star_rating, d$PB_SCALE),
  interaction_pb       = rho(d$interaction_ordinal, d$PB_SCALE),
  duration_pb          = rho(d$ride_duration_minutes, d$PB_SCALE),
  br_pb                = rho(d$BR_SCALE, d$PB_SCALE),
  sv_pb                = rho(d$SV_SCALE, d$PB_SCALE),
  iq_pb                = rho(d$IQ_SCALE, d$PB_SCALE),
  duration_star        = rho(d$ride_duration_minutes, d$star_rating),
  n_female             = sum(d$gender == "F"),
  n_male               = sum(d$gender == "M")
)
stats$p_star_pb <- round(suppressWarnings(
  cor.test(d$star_rating, d$PB_SCALE, method = "spearman")$p.value), 4)

# Per-item correlations with the PB composite (used for evidence loads).
item_pb <- sapply(c("BR1","BR2","BR3","BR4_reversed","SV1","SV2","SV3","SV4",
                    "IQ1","IQ2","IQ3"),
                  function(it) rho(d[[it]], d$PB_SCALE))
stats$item_pb_correlations <- as.list(item_pb)

save_json(stats, file.path(OUT_DIR, "associations.json"))
cat0("star-PB rho =", stats$star_pb, "| interaction-PB =", stats$interaction_pb,
     "| duration-PB =", stats$duration_pb, "| BR-PB =", stats$br_pb)
print(item_pb)